"""Прорисовка аппаратов на монтажных схемах (лист «установка в сборе»): реактор с рубашкой — стенка в две линии,
рубашка с заливкой, фланцы разъёма со шпильками и гайками, лапы с рёбрами, привод (стойка с окном, муфта, редуктор, мотор
с рёбрами и кожухом вентилятора), штуцеры крышки — патрубок по Ду, воротниковый фланец, ответный фланец / заглушка, шпильки.
Рисует в объект с методами line/poly/rect/circle (Sheet или запись Rec). Размеры — мм листа (схематично, по Ду)."""
import math

OUT = '#1a1a1a'
INK = '#222222'
FL = '#ffffff'          # фланцы — белые с чёрным контуром (как в Тефкоте)
WALL = '#ffffff'
JACK = '#f4f4f4'        # рубашка — светло-серая, как плита крышки в Тефкоте
DRV = '#eeeeee'

# ширина патрубка и фланца на листе, толщина фланца — по Ду (схематично, чтобы штуцеры крышки не сливались)
_WN = {15: 1.6, 20: 1.8, 25: 2.0, 32: 2.2, 40: 2.4, 50: 2.6, 65: 2.8, 80: 3.0, 100: 3.4, 125: 3.8, 150: 4.2, 200: 5.0, 250: 5.6, 300: 6.2, 450: 8.0}


def _wn(dn):
    return 0.75 * (_WN.get(dn) or _WN[min(_WN, key=lambda k: abs(k - dn))])     # штуцеры мельче корпуса (замечание 01.11)


def head_y(xc, y_tan, r, depth, x, up=True):
    """Отметка (лист) на эллиптическом днище над точкой x: up — днище вверх (крышка)."""
    u = max(0.0, 1.0 - ((x - xc) / r) ** 2)
    return y_tan - depth * math.sqrt(u) if up else y_tan + depth * math.sqrt(u)


def ellipse_pts(xc, y0, r, depth, up=True, n=24):
    s = -1 if up else 1
    return [(xc - r * math.cos(math.pi * k / n), y0 + s * depth * math.sin(math.pi * k / n)) for k in range(n + 1)]


def flanec(sh, x, y, w, t, bolts=True, fill=FL, lw=0.35):
    """Фланец (вид сбоку) — прямоугольник w×t, верх на y; шпильки — у краёв."""
    sh.rect(x - w / 2, y, w, t, lw=lw, color=OUT, fill=fill)


def shpilki(sh, x, y0, y1, w):
    """Пара шпилек с гайками через пакет фланцев от y0 (верх) до y1 (низ)."""
    for sx in (-1, 1):
        xb = x + sx * (w / 2 - 0.6)
        sh.line(xb, y0 - 0.7, xb, y1 + 0.7, lw=0.18, color=INK)
        sh.rect(xb - 0.55, y0 - 1.2, 1.1, 0.55, lw=0.12, color=INK, fill='#7c858c')
        sh.rect(xb - 0.55, y1 + 0.65, 1.1, 0.55, lw=0.12, color=INK, fill='#7c858c')


def _tef(dn):
    """Толщина линии патрубка и ширина фланцев (лист, мм) — как на листах Тефкота."""
    if dn <= 50:
        return 0.9, 3.6
    if dn <= 100:
        return 1.2, 4.0
    if dn <= 200:
        return 1.6, 5.2
    return 2.0, 6.2


def _para(sh, q, wf, vid):
    """Пара фланцев у плоскости стыка (s = 0 — плоскость; s > 0 — наружу): нижний (штуцера) и верхний (ответный / заглушка),
    белые с чёрным контуром, по бокам — стяжные шпильки (вертикальные планки), как клампы на листах Тефкота."""
    t, g = 0.95, 0.45
    box = lambda s0, s1, a, b: [q(s0, a), q(s1, a), q(s1, b), q(s0, b)]
    sh.poly(box(-g / 2 - t, -g / 2, -wf / 2, wf / 2), lw=0.4, color=INK, closed=True, fill='#ffffff')
    if vid == 'net':
        return
    sh.poly(box(g / 2, g / 2 + t, -wf / 2, wf / 2), lw=0.4, color=INK, closed=True, fill=INK if vid == 'zaglushka' else '#ffffff')
    for sx in (-1, 1):
        a, b = q(-g / 2 - t - 0.35, sx * (wf / 2 + 0.55)), q(g / 2 + t + 0.35, sx * (wf / 2 + 0.55))
        sh.line(a[0], a[1], b[0], b[1], lw=0.7, color=INK)


def shtucer(sh, pb, pf, dn, vid='otvet'):
    """Штуцер любого направления: pb — точка на стенке аппарата, pf — плоскость стыка фланцев. Патрубок — толстая линия
    (по Ду), заходит в стенку; на конце — пара фланцев со шпильками. vid: 'otvet' | 'zaglushka' | 'net'."""
    (xb, yb), (xf, yf) = pb, pf
    L = math.hypot(xf - xb, yf - yb) or 1.0
    ux, uy = (xf - xb) / L, (yf - yb) / L
    nx, ny = -uy, ux
    lw, wf = _tef(dn)
    a = (xb - ux * 0.4, yb - uy * 0.4)
    b = (xf - ux * 1.4, yf - uy * 1.4)
    sh.line(a[0], a[1], b[0], b[1], lw=lw, color=INK)
    _para(sh, lambda s_, t_: (xf + ux * s_ + nx * t_, yf + uy * s_ + ny * t_), wf, vid)
    return wf


def shtucer_verh(sh, x, y_base, y_face, dn, vid='otvet'):
    """Штуцер вверх от поверхности крышки (y_base) до плоскости стыка (y_face)."""
    return shtucer(sh, (x, y_base), (x, y_face), dn, vid)


def shtucer_vniz(sh, x, y_base, y_face, dn, vid='net'):
    """Донный штуцер вниз до плоскости стыка (фланец штуцера; ответный — у арматуры)."""
    return shtucer(sh, (x, y_base), (x, y_face), dn, vid)


def korpus(sh, xc, r, y_fl, y_tan, depth_bot, y_lid_tan, depth_lid, t=0.7, jacket=None, fl_ext=6.0, fl_t=(5.0, 5.0)):
    """Корпус в стиле Тефкота: жирный чёрный контур обечайки и днища, рубашка — контур со светлой заливкой, фланцы разъёма —
    две белые плиты с чёрным контуром и стяжками по краям, крышка эллиптическая. y_fl — плоскость разъёма."""
    t_low, t_up = fl_t
    if jacket:
        rj, y_jt = jacket
        jo = [(xc - rj, y_jt), (xc - rj, y_tan)] + ellipse_pts(xc, y_tan, rj, depth_bot + (rj - r), up=False)[1:-1] + [(xc + rj, y_tan), (xc + rj, y_jt)]
        sh.poly(jo, lw=0.7, color=INK, closed=True, fill=JACK)
    body = [(xc - r, y_fl + t_low), (xc - r, y_tan)] + ellipse_pts(xc, y_tan, r, depth_bot, up=False)[1:-1] + [(xc + r, y_tan), (xc + r, y_fl + t_low)]
    sh.poly(body, lw=0.9, color=INK, closed=True, fill=WALL)
    lid = [(xc - r, y_fl - t_up), (xc - r, y_lid_tan)] + ellipse_pts(xc, y_lid_tan, r, depth_lid, up=True)[1:-1] + [(xc + r, y_lid_tan), (xc + r, y_fl - t_up)]
    sh.poly(lid, lw=0.9, color=INK, closed=True, fill=WALL)
    w = 2 * r + 2 * fl_ext
    sh.rect(xc - w / 2, y_fl - t_up, w, t_up - 0.25, lw=0.7, color=INK, fill=JACK)
    sh.rect(xc - w / 2, y_fl + 0.25, w, t_low - 0.25, lw=0.7, color=INK, fill=JACK)
    for sx in (-1, 1):                                                  # стяжки разъёма — вертикальные планки по краям, как в Тефкоте
        xb = xc + sx * (w / 2 + 0.9)
        sh.line(xb, y_fl - t_up - 0.6, xb, y_fl + t_low + 0.6, lw=1.0, color=INK)


def lapa(sh, x0, side, y_top, y_bot, L=12.0):
    """Опорная лапа: косынка и опорная плита на отметке площадки (y_bot)."""
    s = side
    sh.poly([(x0, y_top), (x0 + s * L, y_bot - 1.2), (x0, y_bot - 1.2)], lw=0.6, color=INK, closed=True, fill=WALL)
    sh.rect(min(x0, x0 + s * (L + 1.5)), y_bot - 1.2, L + 1.5, 1.2, lw=0.6, color=INK, fill=JACK)


def privod(sh, xc, y_g, y_st, y_red, y_mot, w=25.0, y_lid=None):
    """Привод мешалки в стиле Тефкота: штуцер G (толстый патрубок от крышки до фланцев), стойка (белый прямоугольник),
    редуктор и двигатель «M» (серый блок) — жирные чёрные контуры."""
    if y_lid is not None:
        sh.line(xc, y_lid + 0.5, xc, y_g + 1.5, lw=2.4, color=INK)                                    # патрубок G
        _para(sh, lambda s_, t_: (xc + t_, y_g - s_), w * 0.6, 'otvet')                              # фланцы G / стойки
    sh.rect(xc - w * 0.32, y_st, w * 0.64, y_g - 1.5 - y_st, lw=0.8, color=INK, fill=WALL)           # стойка
    sh.rect(xc - w * 0.45, y_red, w * 0.9, y_st - y_red, lw=0.8, color=INK, fill=JACK)               # редуктор
    sh.rect(xc - w * 0.45, y_mot, w * 0.9, y_red - y_mot, lw=0.9, color=INK, fill=DRV)               # двигатель


def meshalka(sh, xc, y_top, y_bot, levels, half):
    """Вал (штрихпунктир) и мешалки — лопасти штрихом (вид сбоку): levels — отметки ступиц (лист), half — полуразмах."""
    sh.line(xc, y_top, xc, y_bot, lw=0.35, color=INK, dash='dash')
    for y in levels:
        sh.rect(xc - 1.4, y - 1.4, 2.8, 2.8, lw=0.25, color=OUT, dash='dash')
        sh.poly([(xc - half, y - 1.6), (xc - 1.4, y - 0.6), (xc - 1.4, y + 0.6), (xc - half, y + 2.6), (xc - half, y - 1.6)], lw=0.22, color=OUT, dash='dash')
        sh.poly([(xc + half, y - 2.6), (xc + 1.4, y - 0.6), (xc + 1.4, y + 0.6), (xc + half, y + 1.6), (xc + half, y - 2.6)], lw=0.22, color=OUT, dash='dash')


def lyuk(sh, xb, yb, ang_deg=-118.0, L=12.0, w2=3.6):
    """Люк загрузочный: патрубок (белый, жирный контур) по нормали к крышке, фланец и крышка люка (чёрная), стяжки."""
    a = math.radians(ang_deg)
    ux, uy = math.cos(a), math.sin(a)
    nx, ny = -uy, ux
    q = lambda s_, t_: (xb + ux * s_ + nx * t_, yb + uy * s_ + ny * t_)
    sh.poly([q(-0.5, -w2), q(L - 1.4, -w2), q(L - 1.4, w2), q(-0.5, w2)], lw=0.8, color=INK, closed=True, fill=WALL)
    _para(sh, lambda s_, t_: q(L + s_, t_), 2 * w2 + 2.4, 'zaglushka')


def head_normal_deg(xc, r, depth, x):
    """Угол (град, лист: y вниз) внешней нормали к эллиптической крышке в точке над x — для люка, врезанного по нормали."""
    c = max(-0.999, min(0.999, (x - xc) / r))
    sn = math.sqrt(1 - c * c)
    return math.degrees(math.atan2(-sn / depth, c / r))
