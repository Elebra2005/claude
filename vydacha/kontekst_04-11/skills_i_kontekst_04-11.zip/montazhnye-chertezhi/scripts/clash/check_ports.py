"""Проверка «висящих концов» и логики соединений модели, собранной lib3d (по <модель>-parts.json).

Запуск: python3 check_ports.py модель-parts.json [--tochki tochki.csv] [--step модель-utf8.step] [--out отчёт.md]
Проверяет:
 1. каждый порт трубы/арматуры/прибора соединён с соседним портом, либо помечен терминалом
    (tochka — точка стыка с трассой, plug — заглушка, vent — воздушник, drain — дренаж, boundary — граница узла);
 2. соединённые порты совпадают: точка (зазор только на прокладку ≤ 3,5 мм у фланцев, 0 у сварных/резьбовых), направления встречные,
    DN и тип одинаковы, у фланцев — одинаковые D, K, число и размер болтов;
 3. терминалы tochka стоят точно в точках из tochki.csv (±1 мм), все точки csv использованы;
 4. (с --step) каждая опора касается и своей трубы, и конструкции (зазор ≤ 1 мм) — тяга не висит в воздухе.
Итог: «ВИСЯЩИХ КОНЦОВ: N; ОШИБОК СОЕДИНЕНИЙ: M; ОПОР БЕЗ КАСАНИЯ: K».
"""
import sys, json, argparse, math, re


def dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('parts'); ap.add_argument('--tochki'); ap.add_argument('--step'); ap.add_argument('--out')
    a = ap.parse_args()
    js = json.load(open(a.parts, encoding='utf-8'))
    parts = {p['id']: p for p in js['parts']}
    dangling, bad, rep = [], [], []
    nports = 0
    terms = []
    for p in js['parts']:
        for q in p['ports']:
            if q['kind'] in ('contact', 'info'):
                continue
            nports += 1
            ln = q['link']
            if ln is None:
                dangling.append(f"{p['name']} — порт {q['name']} DN{q['dn']} ({q['kind']}) в {tuple(q['pos'])}")
            elif 'terminal' in ln:
                terms.append((p, q, ln))
    seen = set()
    for pa_id, na, pb_id, nb, kind in js['links']:
        if pa_id is None or pb_id is None:
            continue
        pa, pb = parts[pa_id], parts[pb_id]
        qa = next(q for q in pa['ports'] if q['name'] == na)
        qb = next(q for q in pb['ports'] if q['name'] == nb)
        d = dist(qa['pos'], qb['pos'])
        dot = sum(x * y for x, y in zip(qa['dir'], qb['dir']))
        lim = 3.5 if qa['kind'] in ('flange', 'clamp') else (60.0 if qa['kind'] == 'insert' else 0.6)
        errs = []
        if d > lim:
            errs.append(f'зазор {d:.1f} мм')
        if dot > -0.999:
            errs.append(f'не соосны (cos={dot:.4f})')
        if qa['kind'] != qb['kind'] and not ({qa['kind'], qb['kind']} <= {'butt', 'thread'} or 'insert' in (qa['kind'], qb['kind'])):
            errs.append(f"тип {qa['kind']}/{qb['kind']}")
        if qa['dn'] and qb['dn'] and qa['dn'] != qb['dn'] and 'insert' not in (qa['kind'], qb['kind']):
            errs.append(f"DN{qa['dn']}/DN{qb['dn']}")
        if qa.get('fl') and qb.get('fl') and qa['fl'] != qb['fl']:
            errs.append(f"фланцы {qa['fl']} / {qb['fl']}")
        if errs:
            bad.append(f"{pa['name']}:{na} ⟷ {pb['name']}:{nb}: " + ', '.join(errs))
    # точки стыка
    tochki = []
    if a.tochki:
        for i, l in enumerate(open(a.tochki, encoding='utf-8')):
            if i == 0 or not l.strip():
                continue
            t, x, y, z = l.strip().split(';')
            tochki.append((t, (float(x), float(y), float(z))))
    used = set()
    tlines = []
    for p, q, ln in terms:
        if ln['terminal'] == 'tochka':
            best = min(tochki, key=lambda t: dist(t[1], q['pos'])) if tochki else None
            if best and dist(best[1], q['pos']) <= 1.0:
                used.add(best[0])
                tlines.append(f"- точка «{best[0].split(' — ')[0]}»: конец {p['name']} ({q['kind']} DN{q['dn']}) — совпадает (±{dist(best[1], q['pos']):.1f} мм)")
            else:
                bad.append(f"терминал tochka не в точке csv: {p['name']}:{q['name']} {tuple(q['pos'])}" + (f" (ближайшая {best[0]} в {dist(best[1], q['pos']):.0f} мм)" if best else ''))
        else:
            tlines.append(f"- {ln['terminal']}: {p['name']} — {ln['text']}")
    for t, xyz in tochki:
        if t not in used:
            bad.append(f'точка стыка из csv не использована: {t} {xyz}')
    # опоры: касание
    sup_bad, sup_lines = [], []
    if a.step:
        sys.path.insert(0, __file__.rsplit('/', 1)[0])
        from clash3d import read
        from OCP.BRepExtrema import BRepExtrema_DistShapeShape
        from OCP.BRep import BRep_Builder
        from OCP.TopoDS import TopoDS_Compound
        solids = read(a.step, full=True)
        bypath = {}
        sys.path.insert(0, __file__.rsplit('/', 2)[0])
        from lib3d.export import ASCII_FIX

        def asc(t):                                   # имена в STEP — после замены символов (fix_step), в parts.json — исходные
            if t is None:
                return t
            for k_, v_ in ASCII_FIX.items():
                t = t.replace(k_, v_)
            return t
        for nm, s in solids:
            chain = re.sub(r'#\d+$', '', nm).split(' / ')
            bypath.setdefault(tuple(chain[:2]), []).append(s)

        def comp(pid):
            p = parts[pid]
            key = (asc(p.get('step_group')), asc(p.get('step_name')))
            ss = list(bypath.get(key, []))
            pre = key[1] + ' - ' if key[1] else None          # «деталь — элемент» (после замены «—» на «-»)
            if pre:
                for k2, v2 in bypath.items():
                    if k2[0] == key[0] and k2[1].startswith(pre):
                        ss += v2
            b = BRep_Builder(); c = TopoDS_Compound(); b.MakeCompound(c)
            for s in ss:
                b.Add(c, s)
            return c, len(ss)

        for p in js['parts']:
            if not p.get('touch'):
                continue
            cs, n0 = comp(p['id'])
            if not n0:
                sup_bad.append(f"{p['name']}: тела не найдены в STEP")
                continue
            for tid in p['touch']:
                ct, n1 = comp(tid)
                if not n1:
                    sup_bad.append(f"{p['name']}: тела {parts[tid]['name']} не найдены в STEP"); continue
                e = BRepExtrema_DistShapeShape(cs, ct); e.Perform()
                dd = e.Value()
                (sup_bad if dd > 1.0 else sup_lines).append(f"{p['name']} ↔ {parts[tid]['name']}: зазор {dd:.2f} мм")
    head = f'ВИСЯЩИХ КОНЦОВ: {len(dangling)}; ОШИБОК СОЕДИНЕНИЙ: {len(bad)}; ОПОР БЕЗ КАСАНИЯ: {len(sup_bad)}'
    out = [head, f'(портов проверено {nports}, связей {len(js["links"])}, терминалов {len(terms)}, опор с проверкой касания {len(sup_lines) + len(sup_bad)})', '']
    if dangling:
        out += ['## Висящие концы'] + ['- ' + x for x in dangling] + ['']
    if bad:
        out += ['## Ошибки соединений'] + ['- ' + x for x in bad] + ['']
    if sup_bad:
        out += ['## Опоры без касания'] + ['- ' + x for x in sup_bad] + ['']
    out += ['## Концы линий (терминалы)'] + tlines + ['']
    if sup_lines:
        out += ['## Опоры — касание трубы и конструкции'] + ['- ' + x for x in sup_lines]
    txt = '\n'.join(out) + '\n'
    print('\n'.join(out[:60]))
    if a.out:
        open(a.out, 'w', encoding='utf-8').write(txt)
    sys.exit(1 if (dangling or bad or sup_bad) else 0)


if __name__ == '__main__':
    main()
