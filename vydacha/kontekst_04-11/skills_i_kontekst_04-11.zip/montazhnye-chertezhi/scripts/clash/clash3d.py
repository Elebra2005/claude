"""Проверка 3D-модели на коллизии (пересечения деталей).

Запуск:  python3 clash3d.py модель.step [--min 1000] [--allow allow.txt] [--out отчёт.md] [--strict] [--jobs 4] [--foreign РЕГВЫР …]
- --foreign: тела здания/трасс/соседей, вставленные в модель для проверки: пары «чужое–чужое» пропускаются;
- читает STEP (UTF-8 версию), берёт все тела с именами;
- сначала грубо по габаритным коробкам, затем точно — объём булева пересечения;
- пересечение объёмом больше --min мм³ (по умолчанию 1000 мм³ = 1 см³) — коллизия;
- допустимые касания/вставки (труба в штуцер, кламп на фланец) — в allow.txt строками «имя1 | имя2» (подстроки).
- обычный режим пропускает элементы одной детали, трубу и фитинги одной линии, тройники/врезки;
- --strict: проверяются ВСЕ пары тел — несмежные детали одной линии, детали одного прибора, элементы одной детали
  (гайка в шпильке, крышка в корпусе и т. п.); порог по умолчанию 20 мм³. Пропускаются только строки allow.txt.
  Модели, собранные библиотекой lib3d «порт-в-порт», строятся без проникновений и проходят --strict.
Итог: «КОЛЛИЗИЙ: N». Сдавать узел можно только при N = 0.
"""
import sys, argparse, itertools, os
import cadquery as cq
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence
from OCP.TDataStd import TDataStd_Name
from OCP.TCollection import TCollection_ExtendedString
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib


def read(path, full=False):
    """Список (имя, solid). full=True — имя = полный путь меток через ' / '."""
    doc = TDocStd_Document(TCollection_ExtendedString('d'))
    r = STEPCAFControl_Reader(); r.SetNameMode(True)
    r.ReadFile(path); r.Transfer(doc)
    st = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    labs = TDF_LabelSequence(); st.GetFreeShapes(labs)
    out = []

    def name(l):
        a = TDataStd_Name()
        return a.Get().ToExtString() if l.FindAttribute(TDataStd_Name.GetID_s(), a) else '?'

    def walk(l, loc, pre, chain):
        if st.IsReference_s(l):
            r2 = l.__class__(); st.GetReferredShape_s(l, r2)
            nm = name(l)
            if not nm or nm == '?' or nm.startswith('=>'):      # exportStepMeta: имя — у формы, а не у вхождения
                nm = name(r2)
            walk(r2, loc.Multiplied(st.GetLocation_s(l)), nm or pre, chain + [nm]); return
        ch = TDF_LabelSequence(); st.GetComponents_s(l, ch)
        if ch.Length():
            for i in range(1, ch.Length() + 1): walk(ch.Value(i), loc, name(l), chain)
            return
        shp = st.GetShape_s(l).Moved(loc)
        ex = TopExp_Explorer(shp, TopAbs_SOLID); k = 0
        while ex.More():
            nm = (' / '.join(c for c in chain if c and c != '?') if full else f'{pre}/{name(l)}') + (f'#{k}' if k else '')
            out.append((nm, TopoDS.Solid_s(ex.Current()))); k += 1; ex.Next()

    from OCP.TopLoc import TopLoc_Location
    for i in range(1, labs.Length() + 1): walk(labs.Value(i), TopLoc_Location(), '', [])
    return out


import re as _re
def base(n):
    return _re.sub(r'#\d+$', '', n.split('/')[-1]).split(':')[0].strip()


def line_no(n):
    m = _re.search(r'\b(\d{3})-\d{2,3}-[A-ZА-Я]+', n)
    return m.group(1) if m else None


def box(s):
    b = Bnd_Box(); BRepBndLib.Add_s(s, b); return b


def vol(s):
    p = GProp_GProps(); BRepGProp.VolumeProperties_s(s, p); return p.Mass()


PARTS, ARGS = None, None


def _check(pair):
    i, j = pair
    c = BRepAlgoAPI_Common(PARTS[i][1], PARTS[j][1])
    if not c.IsDone():
        return None
    v = vol(c.Shape())
    return (v, PARTS[i][0], PARTS[j][0]) if v > ARGS.min else None


def main():
    global PARTS, ARGS
    ap = argparse.ArgumentParser(); ap.add_argument('step'); ap.add_argument('--min', type=float, default=None)
    ap.add_argument('--allow'); ap.add_argument('--out'); ap.add_argument('--strict', action='store_true')
    ap.add_argument('--jobs', type=int, default=os.cpu_count() or 1)
    ap.add_argument('--foreign', action='append', default=[],
                    help='регулярное выражение по имени: «чужие» тела (здание, трассы, соседи) — пары «чужое–чужое» не проверяются, «наше–чужое» — проверяются')
    a = ap.parse_args()
    if a.min is None:
        a.min = 20.0 if a.strict else 1000.0
    ARGS = a
    allow = []
    if a.allow:
        for l in open(a.allow, encoding='utf-8'):
            l = l.split('#')[0]
            if '|' in l:
                allow.append([x.strip() for x in l.split('|')[:2]])
    parts = read(a.step, full=a.strict); boxes = [box(s) for _, s in parts]
    PARTS = parts
    print(f'тел: {len(parts)}' + (' (строгий режим)' if a.strict else ''))
    import re as _re
    frx = [_re.compile(x) for x in a.foreign]
    fr = [any(r.search(n) for r in frx) for n, _ in parts]
    if frx:
        print(f'чужих тел (здание, трассы): {sum(fr)} — пары между ними не проверяются')
    todo = []
    for i, j in itertools.combinations(range(len(parts)), 2):
        if fr[i] and fr[j]: continue
        if boxes[i].IsOut(boxes[j]): continue
        n1, n2 = parts[i][0], parts[j][0]
        if not a.strict:
            b1, b2 = base(n1), base(n2)
            if b1 == b2: continue                      # элементы одной детали (стыки балок рамы и т.п.)
            l1, l2 = line_no(n1), line_no(n2)
            if l1 and l1 == l2: continue               # труба и её изоляция/фитинги одной линии
            if ('тройник' in n1.lower() or 'тройник' in n2.lower() or 'врезк' in n1.lower() or 'врезк' in n2.lower()) and (l1 or l2): continue
        if any((x in n1 and y in n2) or (x in n2 and y in n1) for x, y in allow): continue
        todo.append((i, j))
    print(f'пар для точной проверки: {len(todo)}')
    if a.jobs > 1 and len(todo) > 200:
        import multiprocessing as mp
        with mp.get_context('fork').Pool(a.jobs) as pool:
            res = pool.map(_check, todo, chunksize=32)
    else:
        res = [_check(p) for p in todo]
    hits = sorted([r for r in res if r], reverse=True)
    mode = ('строгий: все пары тел, в т.ч. внутри линии, прибора и детали' if a.strict else 'обычный') + \
           (f'; вместе со зданием и трассами ({sum(fr)} чужих тел, пары «чужое–чужое» не проверяются)' if frx else '')
    lines = [f'КОЛЛИЗИЙ: {len(hits)} (порог {a.min:.0f} мм³; режим — {mode}; тел {len(parts)}, пар проверено точно {len(todo)})'] + \
            [f'- {v:.0f} мм³ | {n1} ⟷ {n2}' for v, n1, n2 in hits]
    print('\n'.join(lines[:80]))
    if a.out: open(a.out, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    sys.exit(1 if hits else 0)


if __name__ == '__main__':
    main()
