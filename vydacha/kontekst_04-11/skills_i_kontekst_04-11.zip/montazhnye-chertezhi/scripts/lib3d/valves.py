"""lib3d.valves — арматура и линейные изделия с фланцами (размеры: EN 558, EN 1092-1, каталоги производителей).

Локальная система: вход 'a' — в начале координат, смотрит в −X; выход 'b' — в +X; привод/шток — вверх (+Z).
У всех фланцевых концов — отверстия под шпильки (вразбежку от +Z), за тарелкой — шейка, не мешающая гайкам.
"""
import math
from cadquery import Vector as V
from .core import (Part, cyl, tube, cone, revolve_profile, hexagon, fuse_all, sph, torus, box, cbox, obox, extrude_poly, unit, vec)
from .piping import bolt_holes, nut_clear_r, MAT_NAME
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def _ends_profile(fl, L, body_r, neck_len=None):
    """Профиль (r, x) корпуса с фланцами на обоих концах: выступ, тарелка, шейка под гайки, далее — корпус радиуса body_r."""
    d, s, m = std.BOLT[fl['bolt']]
    rn = nut_clear_r(fl)
    f1, C, D, d1 = fl['f1'], fl['C'], fl['D'], fl['d1']
    nl = neck_len if neck_len is not None else m + 8
    x1 = f1
    x2 = f1 + C
    x3 = x2 + nl
    pts = [(0, 0), (d1 / 2, 0), (d1 / 2, x1), (D / 2, x1), (D / 2, x2), (rn, x2), (rn, x3)]
    xb = L - x3
    if body_r > rn:
        ramp = min((body_r - rn) * 0.8, (xb - x3) * 0.25)
        pts += [(body_r, x3 + ramp), (body_r, xb - ramp)]
    else:
        pts += [(rn, xb)]
    pts += [(rn, xb), (rn, L - x2), (D / 2, L - x2), (D / 2, L - x1), (d1 / 2, L - x1), (d1 / 2, L), (0, L)]
    return pts


def flanged_body(fl, L, body_r, bore, neck_len=None):
    s = revolve_profile(_ends_profile(fl, L, body_r, neck_len), (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, fl['f1'] + fl['C'] + 0.5) + bolt_holes(fl, L - fl['f1'] - fl['C'] - 0.5, L + 1):
        s = s.cut(h)
    if bore > 0:
        s = s.cut(cyl((-1, 0, 0), (L + 1, 0, 0), bore))
    return s


def _ports(p, fl, L, dn):
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (L, 0, 0), X, Z, dn, 'flange', fl=fl)


def lever(c, stem_d, Llev, along=X, up=Z, grip='lever', w=None):
    """Рукоятка крана: плоская полоса от штока вдоль along, с пластиковой накладкой на конце."""
    c = vec(c)
    w = w or max(16, Llev * 0.11)
    t = max(5, w * 0.28)
    along, up = unit(along), unit(up)
    side = up.cross(along).normalized()
    bar = obox(c + along * (Llev * 0.32) + up * (t / 2), along, side, Llev * 0.64 + stem_d, w, t)
    # отогнутая часть под углом 10° вверх
    a10 = math.radians(10)
    d2 = (along * math.cos(a10) + up * math.sin(a10)).normalized()
    p0 = c + along * (Llev * 0.64) + up * (t / 2)
    bar2 = obox(p0 + d2 * (Llev * 0.18), d2, side, Llev * 0.36, w, t)
    steel = bar.fuse(bar2).cut(cyl(c - up * 1, c + up * (t + 1), stem_d * 0.7))
    g0 = p0 + d2 * (Llev * 0.08)
    gr = obox(g0 + d2 * (Llev * 0.14) + up * 0, d2, side, Llev * 0.30, w + 6, t + 6)
    steel = steel.cut(obox(g0 + d2 * (Llev * 0.14), d2, side, Llev * 0.30 + 0.2, w + 6.2, t + 6.2))
    return steel, gr


def handwheel(c, axis, Dw, ref=None, n_spokes=3, rim=None):
    """Маховик: обод (тор), спицы, ступица. c — центр, axis — ось штока."""
    axis = unit(axis)
    ref = unit(ref) if ref is not None else (X if abs(axis.dot(X)) < 0.9 else Y)
    ref = (ref - axis * ref.dot(axis)).normalized()
    side = axis.cross(ref)
    rim = rim or max(6, Dw * 0.045)
    R = Dw / 2 - rim
    s = torus(c, axis, R, rim)
    hub = cyl(vec(c) - axis * (rim * 1.6), vec(c) + axis * (rim * 1.6), rim * 4.2)
    parts = [s, hub]
    for k in range(n_spokes):
        a = 2 * math.pi * k / n_spokes
        d = ref * math.cos(a) + side * math.sin(a)
        parts.append(cyl(vec(c) + d * (rim * 1.8), vec(c) + d * (R + rim * 0.3), rim * 1.25))
    # ручка на ободе
    return fuse_all(parts)


# ------------------------------------------------------------------ кран шаровой фланцевый
def ball_valve(dn, pn='PN16', mat='SS', name=None, lever_dir=X, gear=False, tag=''):
    fl = std.flange(dn, pn)
    L = std.BALL_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 4, D * 0.40)
    body = flanged_body(fl, L, br, 0)
    # разъём двухсоставного корпуса: кольцо с винтами
    xj = L * 0.36
    ring = cyl((xj - 7, 0, 0), (xj + 7, 0, 0), 2 * br + 24)
    body = body.fuse(ring)
    bore = cyl((-1, 0, 0), (L + 1, 0, 0), std.pipe('SS', dn)[0] - 2 * std.pipe('SS', dn)[1])
    # горловина штока и площадка ISO 5211
    hb = br + D * 0.12
    neck = cyl((L / 2, 0, 0), (L / 2, 0, hb), br * 0.62)
    pad = cbox((L / 2, 0, hb + 5), br * 1.15, br * 1.15, 10)
    body = fuse_all([body, neck, pad]).cut(bore)
    # винты разъёма (головки)
    screws = []
    for k in range(6):
        a = math.radians(30 + 60 * k)
        y, z = (br + 7) * math.sin(a), (br + 7) * math.cos(a)
        if z > br * 0.5:
            continue
        screws.append(hexagon((xj + 7, y, z), X, 8, 5))
    stem_d = max(12, dn * 0.28)
    zt = hb + 10
    stem = cyl((L / 2, 0, zt), (L / 2, 0, zt + 22), stem_d)
    gland = hexagon((L / 2, 0, zt), Z, stem_d * 1.9, 8, hole=stem_d + 0.2)
    p = Part(name or f'кран шаровой фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)}/PTFE, полнопроходной (EN 558 сер.27)' + (f' {tag}' if tag else ''), 'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    p.add(screws, 'bolt', 'винты корпуса')
    p.add([stem.fuse(gland)], 'ss_dark', 'шток')
    if gear or dn >= 100:
        gb = cbox((L / 2, 0, zt + 22 + 45), br * 1.4, br * 1.1, 90)
        gb = gb.fuse(cyl((L / 2, br * 0.55, zt + 22 + 45), (L / 2, br * 0.55 + 60, zt + 22 + 45), 50))
        p.add(gb, 'gear', 'редуктор червячный')
        hw = handwheel(V(L / 2, br * 0.55 + 60 + 20, zt + 22 + 45), Y, std.HANDWHEEL_D.get(dn, 250) * 1.0)
        p.add(hw, 'wheel', 'маховик')
        p.anchor('top', (L / 2, 0, zt + 22 + 90))
    else:
        Llev = std.LEVER_L[dn]
        st, gr = lever(V(L / 2, 0, zt + 22), stem_d, Llev, along=unit(lever_dir))
        nut = hexagon((L / 2, 0, zt + 22 + max(5, Llev * 0.11 * 0.28)), Z, stem_d * 1.6, 7, hole=0)
        p.add([st.fuse(nut)], 'ss_dark', 'рукоятка')
        p.add(gr, 'lever', 'накладка рукоятки')
        p.anchor('top', (L / 2, 0, zt + 40))
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    return p


# ------------------------------------------------------------------ вентиль (клапан запорный) с маховиком
def globe_valve(dn, pn='PN16', mat='SS', name=None, check=False, tag=''):
    fl = std.flange(dn, pn)
    L = std.GLOBE_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 2, D * 0.32)
    body = flanged_body(fl, L, br, 0)
    glob = sph((L / 2, 0, 0), D * 0.82)
    body = body.fuse(glob)
    hb = D * 0.48
    bon_fl = cyl((L / 2, 0, hb - 14), (L / 2, 0, hb), D * 0.62)
    neck = cyl((L / 2, 0, D * 0.25), (L / 2, 0, hb - 14), D * 0.4)
    body = fuse_all([body, neck, bon_fl]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), std.pipe('SS', dn)[0] - 2 * std.pipe('SS', dn)[1]))
    p = Part(name or (f'клапан обратный подъёмный фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)} (EN 558 сер.1)' if check else
                      f'клапан запорный (вентиль) фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)}, сильфонное уплотнение штока (EN 558 сер.1)') + (f' {tag}' if tag else ''),
             'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    # болты крышки
    bb = []
    for k in range(6):
        a = math.radians(30 + 60 * k)
        bb.append(hexagon((L / 2 + D * 0.25 * math.cos(a), D * 0.25 * math.sin(a), hb), Z, max(10, D * 0.07), max(6, D * 0.04)))
    p.add(bb, 'bolt', 'гайки крышки')
    hbz = hb + max(6, D * 0.04)
    if check:
        cover = cyl((L / 2, 0, hb), (L / 2, 0, hb + D * 0.05), D * 0.42).fuse(sph((L / 2, 0, hb + D * 0.05), D * 0.30).cut(box(-1e4, -1e4, -1e4, 1e4, 1e4, hb + D * 0.05)))
        p.add(cover, 'ss_cast', 'крышка')
        p.anchor('top', (L / 2, 0, hb + D * 0.2))
    else:
        bon = cyl((L / 2, 0, hb), (L / 2, 0, hb + D * 0.42), D * 0.36)
        yoke_h = D * 0.55
        z0 = hb + D * 0.42
        yk = [cyl((L / 2, -D * 0.14, z0), (L / 2, -D * 0.14, z0 + yoke_h), max(10, D * 0.07)), cyl((L / 2, D * 0.14, z0), (L / 2, D * 0.14, z0 + yoke_h), max(10, D * 0.07)),
              cyl((L / 2, 0, z0 + yoke_h), (L / 2, 0, z0 + yoke_h + 16), D * 0.42)]
        sd = max(10, dn * 0.22)
        p.add(fuse_all([bon] + yk).cut(cyl((L / 2, 0, z0 - 1), (L / 2, 0, z0 + yoke_h + 17), sd + 1.0)), 'ss_cast', 'крышка и бугель')
        zt = z0 + yoke_h + 16
        stem = cyl((L / 2, 0, z0), (L / 2, 0, zt + 30), sd)
        p.add(stem, 'ss_dark', 'шпиндель')
        Dw = std.HANDWHEEL_D[dn]
        hw = handwheel(V(L / 2, 0, zt + 30 + 0.1 + max(6, Dw * 0.045) * 1.6), Z, Dw)
        p.add(hw, 'wheel', 'маховик')
        p.anchor('top', (L / 2, 0, zt + 40))
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    return p


def check_valve(dn, pn='PN16', mat='SS', name=None, tag=''):
    return globe_valve(dn, pn, mat, name, check=True, tag=tag)


# ------------------------------------------------------------------ кран шаровой трёхходовой
def threeway_valve(dn, pn='PN16', mat='SS', name=None, branch_dir=Y, tag=''):
    """Трёхходовой L-кран: прогон a(−X)…b(+X), боковой выход c (+Y). Привод — редуктор с маховиком (DN≥80) или рукоятка."""
    fl = std.flange(dn, pn)
    L = int(std.BALL_L[dn] * 1.65)
    D = fl['D']
    br = max(nut_clear_r(fl) + 4, D * 0.40)
    C = L / 2
    body = flanged_body(fl, L, br, 0)
    # боковой патрубок с фланцем
    rn = nut_clear_r(fl)
    d, s_, m = std.BOLT[fl['bolt']]
    side = revolve_profile([(0, 0), (br, 0), (br, C - fl['f1'] - fl['C'] - m - 8 - 10), (rn, C - fl['f1'] - fl['C'] - m - 8), (rn, C - fl['f1'] - fl['C']),
                            (D / 2, C - fl['f1'] - fl['C']), (D / 2, C - fl['f1']), (fl['d1'] / 2, C - fl['f1']), (fl['d1'] / 2, C), (0, C)], (C, 0, 0), Y, Z)
    for k in range(fl['n']):
        a = math.radians((k + 0.5) * 360 / fl['n'])
        x, z = fl['K'] / 2 * math.sin(a), fl['K'] / 2 * math.cos(a)
        side = side.cut(cyl((C + x, C - fl['f1'] - fl['C'] - 0.5, z), (C + x, C + 1, z), fl['L']))
    body = body.fuse(side).fuse(sph((C, 0, 0), 2 * br * 1.05))
    hb = br * 1.05 + 20
    neck = cyl((C, 0, 0), (C, 0, hb), br * 0.7)
    pad = cbox((C, 0, hb + 6), br * 1.2, br * 1.2, 12)
    bore = std.pipe('SS', dn)[0] - 2 * std.pipe('SS', dn)[1]
    body = fuse_all([body, neck, pad]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), bore)).cut(cyl((C, 0, 0), (C, C + 1, 0), bore))
    p = Part(name or f'кран шаровой трёхходовой фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)}/PTFE, L-проход, редуктор с маховиком' + (f' {tag}' if tag else ''), 'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    zt = hb + 12
    stem = cyl((C, 0, zt), (C, 0, zt + 20), max(16, dn * 0.25))
    p.add(stem, 'ss_dark', 'шток')
    zg = zt + 20 + 45
    # редуктор червячный (четвертьоборотный, ISO 5211): фланец крепления, корпус колеса (вертикальный цилиндр),
    # корпус червяка (горизонтальный цилиндр поперёк), крышка; сверху — указатель положения под прозрачным колпаком
    Rw = br * 0.55
    flg = cyl((C, 0, zg - 45), (C, 0, zg - 35), br * 1.0)
    whl = cyl((C, 0, zg - 35), (C, 0, zg + 35), 2 * Rw)
    cov = cyl((C, 0, zg + 35), (C, 0, zg + 45), 2 * Rw * 0.92)
    shaft_y0 = -br * 0.475
    worm = cyl((C, Rw * 0.6, zg - 10), (C, shaft_y0 - 40, zg - 10), 58)
    boss = cyl((C, Rw * 0.6, zg - 10), (C, Rw * 0.6 + 14, zg - 10), 44)
    gb = fuse_all([flg, whl, cov, worm, boss])
    p.add(gb, 'gear', 'редуктор червячный ручной (ISO 5211)')
    dome_r = Rw * 0.62
    dome = sph((C, 0, zg + 45), 2 * dome_r).cut(sph((C, 0, zg + 45), 2 * dome_r - 6)).cut(cyl((C, 0, zg + 45 - dome_r - 1), (C, 0, zg + 45), 2 * dome_r + 2))
    p.add(dome, 'glass', 'колпак указателя')
    Dw = std.HANDWHEEL_D.get(dn, 250)
    shaft = cyl((C, shaft_y0 - 40, zg - 10), (C, shaft_y0 - 95, zg - 10), 24)
    p.add(shaft, 'ss_dark', 'входной вал редуктора')
    rim = max(6, Dw * 0.045)
    p.add(handwheel(V(C, shaft_y0 - 95 - rim * 1.6, zg - 10), -Y, Dw), 'wheel', 'маховик')
    w1, w2 = min(6.0, 0.11 * dome_r), min(14.0, 0.26 * dome_r)          # стрелка внутри колпака и при малых DN (исправлено 26.10)
    arrow = extrude_poly([(-dome_r * 0.6, -w1), (dome_r * 0.3, -w1), (dome_r * 0.3, -w2), (dome_r * 0.65, 0), (dome_r * 0.3, w2), (dome_r * 0.3, w1), (-dome_r * 0.6, w1)],
                         V(C, 0, zg + 45), X, Z, 5)
    p.add(arrow, 'yellow', 'указатель положения (стрелка L-прохода)')
    _ports(p, fl, L, dn)
    p.port('c', (C, C, 0), Y, Z, dn, 'flange', fl=fl)
    p.anchor('top', (C, 0, zt + 20 + 45 + 64))
    p.meta.update(L=L, C=C)
    return p


# ------------------------------------------------------------------ компенсатор сильфонный осевой со стяжками
def bellows(dn, pn='PN16', mat='SS', L=None, n_rods=2, name=None, n_conv=None, rod_ang0=90.0, tag=''):
    """Компенсатор сильфонный фланцевый: патрубки, многослойный гофр (2 слоя), фланцы с проушинами,
    стяжные шпильки через проушины, по две гайки на каждой проушине (стяжки — транспортные/ограничительные)."""
    fl = std.flange(dn, pn)
    o, w = std.pipe('SS', dn)
    D, C, f1 = fl['D'], fl['C'], fl['f1']
    d, s_, m = std.BOLT[fl['bolt']]
    L = L or {25: 160, 32: 170, 40: 180, 50: 190, 65: 200, 80: 220, 100: 240, 125: 260, 150: 280, 200: 320}[dn]
    rn = nut_clear_r(fl)
    T = f1 + C                          # тарелка фланца
    nl = m + 8                          # шейка под гайки
    # патрубки (концы сильфона) — приварены к фланцам
    xs0, xs1 = T + nl + 10, L - T - nl - 10        # гофр
    flA = revolve_profile([(o / 2 - w, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, f1), (D / 2, f1), (D / 2, T), (rn, T), (rn, T + nl), (o / 2 + 3, T + nl), (o / 2 + 3, xs0), (o / 2 - w, xs0)], (0, 0, 0), X, Z)
    flB = revolve_profile([(o / 2 - w, L), (fl['d1'] / 2, L), (fl['d1'] / 2, L - f1), (D / 2, L - f1), (D / 2, L - T), (rn, L - T), (rn, L - T - nl), (o / 2 + 3, L - T - nl), (o / 2 + 3, xs1), (o / 2 - w, xs1)], (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, T + 0.5):
        flA = flA.cut(h)
    for h in bolt_holes(fl, L - T - 0.5, L + 1):
        flB = flB.cut(h)
    # гофр: n волн, наружный Dg, внутренний — по патрубку
    n_conv = n_conv or max(5, int((xs1 - xs0) / max(9, o * 0.11)))
    pitch = (xs1 - xs0) / n_conv
    r_in, r_out = o / 2 + 3, o / 2 + 3 + max(10, o * 0.17)
    rn_max = rn - 4
    if r_out > rn_max + 30:
        r_out = rn_max + 30
    def wave(r0, r1, t):
        pts = []
        steps = 10
        for k in range(n_conv):
            for j in range(steps + 1):
                u = j / steps
                x = xs0 + (k + u) * pitch
                r = r0 + (r1 - r0) * (0.5 - 0.5 * math.cos(2 * math.pi * u))
                pts.append((r, x))
        outer = [(r + t, x) for r, x in pts]
        inner = [(r, x) for r, x in pts][::-1]
        return revolve_profile(outer + inner, (0, 0, 0), X, Z)
    ply1 = wave(r_in, r_out - 1.6, 0.8)
    ply2 = wave(r_in + 1.0, r_out - 0.6, 0.6)
    # проушины на ободе фланцев + стяжки
    lug_t = C
    rh = D / 2 + max(16, d * 1.2)               # радиус отверстия проушины
    lw = max(36, 2.6 * d)
    lugs, rods = [], []
    rod_d = d
    ang0 = rod_ang0
    angs = [ang0 + k * 360.0 / n_rods for k in range(n_rods)]
    for a_ in angs:
        a = math.radians(a_)
        u = V(0, math.sin(a), math.cos(a))
        side = X.cross(u)
        for x0 in (f1, L - T):
            c = V(x0 + lug_t / 2, 0, 0) + u * ((D / 2 - 4 + rh + lw / 2) / 2)
            ln = (rh + lw / 2) - (D / 2 - 4)
            lg = obox(c, u, side, ln, lw, lug_t)
            # обрезка по скруглению и отверстие
            lg = lg.cut(cyl(V(x0 - 1, 0, 0) + u * rh, V(x0 + lug_t + 1, 0, 0) + u * rh, rod_d + 2))
            lg = lg.cut(cyl(V(x0 - 1, 0, 0), V(x0 + lug_t + 1, 0, 0), D - 8))
            lugs += [lg]
        # стяжка: от наружной гайки A до наружной гайки B
        xa0, xb1 = f1 - m - 8, L - f1 + m + 8
        rod = cyl(V(xa0 - 6, 0, 0) + u * rh, V(xb1 + 6, 0, 0) + u * rh, rod_d)
        nuts = []
        for xx, dd in ((f1, -X), (f1 + lug_t, X), (L - T, -X), (L - f1, X)):
            nuts.append(hexagon(V(xx, 0, 0) + u * rh, dd, s_, m, ref=u))
        rods.append(fuse_all([rod] + nuts))
    p = Part(name or f'компенсатор сильфонный осевой DN{dn} {pn} (гофр 2-слойный AISI 321/316L, фланцы с проушинами, {n_rods} стяжки M{d:.0f} с гайками)' + (f' {tag}' if tag else ''),
             'bellows', dn, material=mat)
    # проушины: каждая к своему фланцу
    la = [lg for i, lg in enumerate(lugs) if i % 2 == 0]
    lb = [lg for i, lg in enumerate(lugs) if i % 2 == 1]
    p.add(fuse_all([flA] + la), 'ss', 'фланец A с проушинами')
    p.add(fuse_all([flB] + lb), 'ss', 'фланец B с проушинами')
    p.add(ply1, 'ss_polish', 'гофр, слой наружный')
    p.add(ply2, 'ss_dark', 'гофр, слой внутренний')
    p.add(rods, 'bolt', 'стяжки с гайками')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('mid', (L / 2, 0, r_out))
    return p


# ------------------------------------------------------------------ фонарь смотровой проточный
def sight_glass(dn, pn='PN16', mat='SS', name=None, L=None, tag=''):
    fl = std.flange(dn, pn)
    D = fl['D']
    o, w = std.pipe('SS', dn)
    L = L or int(max(2.0 * D * 0.6 + 90, D * 1.15))
    br = max(nut_clear_r(fl) + 2, o / 2 + 12)
    body = flanged_body(fl, L, br, 0)
    # корпус-«барабан» и два окна напротив (±Y)
    d_, s_n, m_n = std.BOLT[fl['bolt']]
    drum_d = min(D * 0.95, 2 * (L / 2 - fl['f1'] - fl['C'] - m_n - 14))
    win_d = drum_d * 0.62
    drum = cyl((L / 2, -(o / 2 + 30), 0), (L / 2, o / 2 + 30, 0), drum_d)
    body = body.fuse(drum)
    body = body.cut(cyl((-1, 0, 0), (L + 1, 0, 0), o - 2 * w)).cut(cyl((L / 2, -(o / 2 + 31), 0), (L / 2, o / 2 + 31, 0), win_d))
    p = Part(name or f'фонарь смотровой проточный DN{dn} {pn} {MAT_NAME.get(mat, mat)}, 2 окна (стекло боросиликатное)' + (f' {tag}' if tag else ''), 'sight', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    glass, rings, nuts = [], [], []
    for sg in (-1, 1):
        y0 = sg * (o / 2 + 30)
        gl = cyl((L / 2, y0, 0), (L / 2, y0 + sg * 12, 0), win_d + 16)
        glass.append(gl)
        ring = cyl((L / 2, y0 + sg * 12, 0), (L / 2, y0 + sg * 26, 0), drum_d).cut(cyl((L / 2, y0, 0), (L / 2, y0 + sg * 27, 0), win_d * 0.92))
        for k in range(6):
            a = math.radians(30 + 60 * k)
            rr = (drum_d / 2 + win_d / 2 * 1.04) / 2 + 2
            cx, cz = L / 2 + rr * math.sin(a), rr * math.cos(a)
            ring = ring.cut(cyl((cx, y0 + sg * 11, cz), (cx, y0 + sg * 27, cz), 11))
            nuts.append(fuse_all([cyl((cx, y0 + sg * 26, cz), (cx, y0 + sg * 26 + sg * 16, cz), 9.6), hexagon((cx, y0 + sg * 26, cz), Y * sg, 15, 8)]))
        rings.append(ring)
    p.add(glass, 'glass', 'стёкла')
    p.add(rings, 'ss', 'кольца прижимные')
    p.add(nuts, 'bolt', 'шпильки и гайки окон')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    return p


# ------------------------------------------------------------------ огнепреградитель
def flame_arrester(dn, pn='PN16', mat='SS', name=None, tag=''):
    fl = std.flange(dn, pn)
    D = fl['D']
    L = int(D * 1.9)
    Dh = D * 1.35
    body = flanged_body(fl, L, nut_clear_r(fl), 0)
    xa, xb = L * 0.3, L * 0.7
    hous = revolve_profile([(0, xa - 30), (nut_clear_r(fl), xa - 30), (Dh / 2 - 8, xa), (Dh / 2 - 8, xb), (nut_clear_r(fl), xb + 30), (0, xb + 30)], (0, 0, 0), X, Z)
    body = body.fuse(hous)
    # фланцы корпуса (стяжка кассеты)
    fA = cyl((xa - 4, 0, 0), (xa + 12, 0, 0), Dh + 30)
    fB = cyl((xb - 12, 0, 0), (xb + 4, 0, 0), Dh + 30)
    body = fuse_all([body, fA, fB]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), std.pipe('SS', dn)[0] - 2 * std.pipe('SS', dn)[1]))
    rods = []
    for k in range(8):
        a = math.radians(22.5 + 45 * k)
        y, z = (Dh / 2 + 8) * math.sin(a), (Dh / 2 + 8) * math.cos(a)
        body = body.cut(cyl((xa - 5, y, z), (xa + 13, y, z), 11)).cut(cyl((xb - 13, y, z), (xb + 5, y, z), 11))
        rods.append(fuse_all([cyl((xa - 4 - 10, y, z), (xb + 4 + 10, y, z), 10), hexagon((xa - 4, y, z), -X, 16, 8), hexagon((xb + 4, y, z), X, 16, 8)]))
    p = Part(name or f'огнепреградитель DN{dn} {pn} {MAT_NAME.get(mat, mat)}, кассета ленточная (ГОСТ Р 53323)' + (f' {tag}' if tag else ''), 'arrester', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    p.add(rods, 'bolt', 'стяжные шпильки кассеты')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    return p


# ------------------------------------------------------------------ разрывная мембрана в держателе (вставка между фланцами)
def rupture_disc(dn, fl_in, fl_out=None, name=None, tag=''):
    """Держатель мембраны (вставной, внутри окружности болтов) + мембрана + бирка + датчик разрыва.
    Порты 'a' и 'b' — тип 'insert': шпильки соединения проходят снаружи держателя от фланца до фланца."""
    fl_out = fl_out or fl_in
    o, w = std.pipe('SS', dn)
    d, s_, m = std.BOLT[fl_in['bolt']]
    Dh = fl_in['K'] - fl_in['L'] - 6
    h_in, h_out = 28, 24
    g = 2.0
    H = g + h_in + 1.0 + h_out + g
    p = Part(name or f'мембрана разрывная в держателе DN{dn} (вставной держатель 316L, мембрана F46/316L, датчик разрыва)' + (f' {tag}' if tag else ''), 'rupture', dn)
    gk1 = tube((0, 0, 0), (g, 0, 0), fl_in['d1'], o - 2 * w)
    hin = tube((g, 0, 0), (g + h_in, 0, 0), Dh, o - 2 * w)
    disc = tube((g + h_in, 0, 0), (g + h_in + 1.0, 0, 0), Dh - 10, 0.0001)
    disc = cyl((g + h_in, 0, 0), (g + h_in + 1.0, 0, 0), Dh - 10)
    hout = tube((g + h_in + 1.0, 0, 0), (g + h_in + 1.0 + h_out, 0, 0), Dh, o - 2 * w)
    gk2 = tube((H - g, 0, 0), (H, 0, 0), fl_out['d1'], o - 2 * w)
    # купол мембраны (выпуклость в сторону выхода)
    rd_ = (o - 2 * w) / 2 - 2
    dome = revolve_profile([(0, 0)] + [(rd_ * math.cos(math.radians(t)), 14 * math.sin(math.radians(t))) for t in range(0, 91, 10)], (g + h_in + 1.0, 0, 0), X, Z)
    dome = dome.cut(revolve_profile([(0, -0.5)] + [((rd_ - 1.2) * math.cos(math.radians(t)), 12.8 * math.sin(math.radians(t))) for t in range(0, 91, 10)], (g + h_in + 1.0, 0, 0), X, Z))
    p.add([gk1, gk2], 'ptfe', 'прокладки')
    p.add([hin, hout], 'ss', 'держатель (вход/выход)')
    tag_w = 40
    tab = obox((g + h_in + 0.5, 0, Dh / 2 + 26), Z, Y, 72, tag_w, 1.0)
    p.add(fuse_all([disc, dome, tab]), 'red', 'мембрана с биркой')
    # датчик разрыва: перемычка от держателя между шпильками, клеммная коробка за наружным диаметром фланцев
    Dfl = max(fl_in['D'], fl_out['D'])
    u = V(0, 1, 0)
    xm = g + h_in / 2
    arm = obox(V(xm, 0, 0) + u * ((Dh / 2 + Dfl / 2 + 12) / 2), u, X, (Dfl / 2 + 12) - (Dh / 2), 14, h_in - 6)
    bx = obox(V(xm, 0, 0) + u * (Dfl / 2 + 12 + 30), u, X, 60, 52, 46)
    gland = cyl(V(xm, 0, 0) + u * (Dfl / 2 + 42) + Z * 23, V(xm, 0, 0) + u * (Dfl / 2 + 42) + Z * 45, 22)
    cable = cyl(V(xm, 0, 0) + u * (Dfl / 2 + 42) + Z * 45, V(xm, 0, 0) + u * (Dfl / 2 + 42) + Z * 170, 9)
    p.add(fuse_all([arm, bx, gland]), 'instr', 'датчик разрыва (клеммная коробка Ex, перемычка)')
    p.add(cable, 'cable', 'кабель датчика')
    p.port('a', (0, 0, 0), -X, Z, dn, 'insert', fl=fl_in)
    p.port('b', (H, 0, 0), X, Z, dn, 'insert', fl=fl_out)
    p.meta['H'] = H
    p.anchor('tag', (g + h_in, 0, Dh / 2 + 50))
    return p


# ------------------------------------------------------------------ клапан игольчатый / кран манометровый (малые)
def needle_valve(dn=15, name=None, L=80, thread=True, tag=''):
    """Клапан игольчатый муфтовый (G1/2): шестигранный корпус, шток с Т-рукояткой."""
    o = 21.3
    body = hexagon((0, 0, 0), X, 32, 22).fuse(cyl((22, 0, 0), (L - 22, 0, 0), 30)).fuse(hexagon((L - 22, 0, 0), X, 32, 22))
    body = body.cut(cyl((-1, 0, 0), (L + 1, 0, 0), 10))
    bon = cyl((L / 2, 0, 15), (L / 2, 0, 48), 22).fuse(hexagon((L / 2, 0, 48), Z, 24, 10))
    stem = cyl((L / 2, 0, 58), (L / 2, 0, 80), 8)
    th = cyl((L / 2 - 30, 0, 86), (L / 2 + 30, 0, 86), 8).fuse(cyl((L / 2, 0, 80), (L / 2, 0, 90), 12))
    p = Part(name or f'клапан игольчатый муфтовый G1/2 AISI 316, PN160' + (f' {tag}' if tag else ''), 'valve', dn)
    p.add(fuse_all([body, bon]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), 10)), 'ss_cast', 'корпус')
    p.add(stem.fuse(th), 'ss_dark', 'шток с рукояткой')
    p.port('a', (0, 0, 0), -X, Z, dn, 'thread', od=o)
    p.port('b', (L, 0, 0), X, Z, dn, 'thread', od=o)
    return p


# ------------------------------------------------------------------ кламповое соединение (Tri-Clamp)
def clamp_joint(size=64.0, gasket='FFKM', name=None, dn=50, od=51.0, gap=3.0):
    """Хомут кламповый с прокладкой (DIN 32676): кольцо с клиновым пазом по заплечикам ферул, шарнир, болт с барашком.
    Начало координат — середина зазора между ферулами (ось — X); ферулы: торцы в ±gap/2, заплечик 3 мм, далее конус 4 мм."""
    Df = size
    h = gap / 2
    p = Part(name or f'соединение кламповое Ø{Df:g} (хомут AISI 304 с барашковой гайкой, прокладка {gasket})', 'clamp', dn)
    gk = tube((-h, 0, 0), (h, 0, 0), Df - 6, od - 2 * 1.5 - 1)
    xi = h + 3.0 + 1.6                    # за заплечиком и началом конуса
    rin = Df / 2 - 1.5
    ro = Df / 2 + 9
    w = h + 10
    ring = revolve_profile([(Df / 2 + 0.5, -xi), (Df / 2 + 0.5, xi), (rin, xi + 1.2), (rin, w), (ro, w), (ro, -w), (rin, -w), (rin, -xi - 1.2)], (0, 0, 0), X, Z)
    ear_z = -(ro + 11)
    lugs = [obox((0, sg * 9, ear_z), Z, Y, 24, 10, 2 * w).cut(cyl((0, -20, ear_z - 4), (0, 20, ear_z - 4), 9)) for sg in (-1, 1)]
    hinge = cyl((-w, 0, ro + 5), (w, 0, ro + 5), 10)
    bolt = cyl((0, -26, ear_z - 4), (0, 26, ear_z - 4), 8)
    wing = obox((0, 32, ear_z - 4), Y, Z, 8, 30, 6).fuse(cyl((0, 26, ear_z - 4), (0, 36, ear_z - 4), 13))
    p.add(fuse_all([ring] + lugs + [hinge]), 'ss', 'хомут')
    p.add(fuse_all([bolt, wing]), 'ss_dark', 'болт с барашком')
    p.add(gk, 'ffkm' if gasket == 'FFKM' else 'ptfe', 'прокладка')
    p.meta['gap'] = gap
    return p


def _ferrule_prof(od, Df, L, x0=0.0, sgn=1):
    """Профиль ферулы: от x0 (сварка) до x0+sgn·L (плоскость); заплечик 3 мм, конус 4 мм."""
    pts = [(od / 2 - 1.5, 0), (od / 2, 0), (od / 2, L - 7), (Df / 2, L - 3), (Df / 2, L), (od / 2 - 1.5, L)]
    return [(r, x0 + sgn * x) for r, x in pts]


def ferrule_end(dn, size=64.0, od=51.0, L=21.5, name=None, mat='SS'):
    """Ферула (приварная) под кламп: 'a' — под сварку (−X), 'b' — плоскость клампа (+X)."""
    Df = size
    s = revolve_profile(_ferrule_prof(od, Df, L), (0, 0, 0), X, Z)
    p = Part(name or f'ферула под кламп Ø{Df:g} AISI 316L (DIN 32676)', 'ferrule', dn, material=mat)
    p.add(s, 'ss')
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=od)
    p.port('b', (L, 0, 0), X, Z, dn, 'clamp', od=Df)
    return p


def clamp_sight_glass(dn=50, size=64.0, od=51.0, L=200, name=None, tag=''):
    """Окно смотровое трубчатое с клампами (K64): стеклянная труба в защитной клетке, концевые ферулы."""
    Df = size
    p = Part(name or f'окно смотровое проточное DN{dn} с клампами Ø{Df:g} (трубка боросиликатная, защитная клетка, AISI 316L)' + (f' {tag}' if tag else ''), 'sight', dn)
    endA = revolve_profile(_ferrule_prof(od, Df, 21.5, 21.5, -1) + [], (0, 0, 0), X, Z)
    endB = revolve_profile(_ferrule_prof(od, Df, 21.5, L - 21.5, 1), (0, 0, 0), X, Z)
    capA = tube((21.5, 0, 0), (36, 0, 0), Df + 14, od - 3)
    capB = tube((L - 36, 0, 0), (L - 21.5, 0, 0), Df + 14, od - 3)
    rods = [cyl((36, (Df / 2 + 2) * math.sin(a), (Df / 2 + 2) * math.cos(a)), (L - 36, (Df / 2 + 2) * math.sin(a), (Df / 2 + 2) * math.cos(a)), 8)
            for a in [math.radians(45 + 90 * k) for k in range(4)]]
    p.add(fuse_all([endA, capA] + rods + [capB, endB]), 'ss', 'корпус с клеткой')
    p.add(tube((36, 0, 0), (L - 36, 0, 0), od + 6, od - 3), 'glass', 'трубка стеклянная')
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.port('b', (L, 0, 0), X, Z, dn, 'clamp', od=Df)
    return p


def clamp_ball_valve(dn=50, size=64.0, od=51.0, name=None, lever_dir=X, tag=''):
    """Кран шаровой с клампами (K64), трёхсоставной корпус, рукоятка."""
    Df = size
    L = 150.0
    br = Df / 2 + 8
    p = Part(name or f'кран шаровой санитарный DN{dn} с клампами Ø{Df:g}, AISI 316L/PTFE, рукоятка' + (f' {tag}' if tag else ''), 'valve', dn)
    endA = revolve_profile(_ferrule_prof(od, Df, 21.5, 21.5, -1), (0, 0, 0), X, Z)
    endB = revolve_profile(_ferrule_prof(od, Df, 21.5, L - 21.5, 1), (0, 0, 0), X, Z)
    body = revolve_profile([(od / 2 - 1.5, 21.5), (od / 2, 21.5), (br, 32), (br, L - 32), (od / 2, L - 21.5), (od / 2 - 1.5, L - 21.5)], (0, 0, 0), X, Z)
    neck = cyl((L / 2, 0, br - 6), (L / 2, 0, br + 22), 30)
    pad = cbox((L / 2, 0, br + 27), 44, 44, 10)
    p.add(fuse_all([endA, body, endB, neck, pad]), 'ss_cast', 'корпус')
    st = cyl((L / 2, 0, br + 32), (L / 2, 0, br + 50), 12)
    stl, gr = lever(V(L / 2, 0, br + 50), 12, 200, along=unit(lever_dir))
    p.add(fuse_all([st, stl]), 'ss_dark', 'рукоятка')
    p.add(gr, 'lever', 'накладка рукоятки')
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.port('b', (L, 0, 0), X, Z, dn, 'clamp', od=Df)
    p.anchor('top', (L / 2, 0, br + 60))
    return p


CLAMP_DN = {25.0: 20, 34.0: 15, 50.5: 25, 64.0: 50, 77.5: 65, 91.0: 65, 106.0: 80, 119.0: 100}   # Ø ферулы (DIN 32676 / ISO 2852) → DN клампового порта


CLAMP_TUBE_OD = {25.0: 19.05, 34.0: 25.4, 50.5: 33.7, 64.0: 51.0, 77.5: 63.5, 91.0: 70.0, 106.0: 85.0, 119.0: 104.0}   # К73: Ø трубы под ферулу


def clamp_tube_od(size):
    """Ø трубы под ферулу Ø size (для прокладки хомута; Ø64 → 51, как было)."""
    return CLAMP_TUBE_OD[min(CLAMP_TUBE_OD, key=lambda k: abs(k - size))]


def clamp_dn(size):
    """DN клампового соединения по Ø ферулы (ближайший типоразмер)."""
    return CLAMP_DN[min(CLAMP_DN, key=lambda k: abs(k - size))]


def reducing_flange_clamp(dn, pn, size=64.0, od=51.0, neck_L=60, name=None, dn_b=None):
    """Фланец-переходник DN → ферула Kxx: глухой фланец с патрубком и ферулой. 'a' — плоскость фланца (−X), 'b' — кламп (+X).
    DN порта 'b' — по Ø ферулы (Ø50,5 → DN25, Ø64 → DN50, Ø119 → DN100) или dn_b (исправлено 25.10: раньше всегда DN50)."""
    fl = std.flange(dn, pn)
    T = fl['C'] + fl['f1']
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (fl['D'] / 2, fl['f1']), (fl['D'] / 2, T), (0, T)], (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    nk = tube((T, 0, 0), (T + neck_L, 0, 0), od, od - 3)
    fe = revolve_profile(_ferrule_prof(od, size, 21.5, T + neck_L, 1), (0, 0, 0), X, Z)
    s = fuse_all([plate, nk, fe]).cut(cyl((-1, 0, 0), (T + neck_L + 30, 0, 0), od - 3))
    p = Part(name or f'фланец-переходник DN{dn} {pn} → кламп Ø{size:g} (AISI 316L)', 'flange', dn)
    p.add(s, 'ss')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (T + neck_L + 21.5, 0, 0), X, Z, dn_b or clamp_dn(size), 'clamp', od=size)
    return p


def clamp_cap(dn, size=64.0, od=51.0, name=None):
    """Заглушка кламповая с ручкой: заплечик и конус как у ферулы (под тот же хомут)."""
    Df = size
    s = revolve_profile([(0, 0), (Df / 2, 0), (Df / 2, -3), (od / 2, -7), (od / 2, -16), (0, -16)], (0, 0, 0), X, Z)
    s = s.fuse(cyl((-16, 0, 0), (-34, 0, 0), 20)).fuse(cyl((-34, -18, 0), (-34, 18, 0), 9))
    p = Part(name or f'заглушка кламповая Ø{Df:g} с ручкой (AISI 316L)', 'cap', dn)
    p.add(s, 'ss')
    p.port('a', (0, 0, 0), X, Z, dn, 'clamp', od=Df)
    return p


def ball_valve_thread(dn=20, name=None, tag='', lever_dir=X):
    """Кран шаровой муфтовый (G3/4 / G1/2), AISI 316, рукоятка."""
    o = {15: 21.3, 20: 26.9, 25: 33.7}[dn]
    L = {15: 65.0, 20: 75.0, 25: 90.0}[dn]
    s_ = o + 10
    body = fuse_all([hexagon((0, 0, 0), X, s_, 16), cyl((16, 0, 0), (L - 16, 0, 0), s_ + 6), hexagon((L - 16, 0, 0), X, s_, 16)])
    neck = cyl((L / 2, 0, (s_ + 6) / 2 - 4), (L / 2, 0, (s_ + 6) / 2 + 12), 16)
    body = fuse_all([body, neck]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), o - 6))
    p = Part(name or f'кран шаровой муфтовый DN{dn} (G{ {15: "1/2", 20: "3/4", 25: "1"}[dn]}) AISI 316/PTFE, PN40' + (f' {tag}' if tag else ''), 'valve', dn)
    p.add(body, 'ss_cast', 'корпус')
    st, gr = lever(V(L / 2, 0, (s_ + 6) / 2 + 12), 10, 110, along=unit(lever_dir))
    p.add(st.fuse(hexagon(V(L / 2, 0, (s_ + 6) / 2 + 12 + 5), Z, 13, 6)), 'ss_dark', 'рукоятка')
    p.add(gr, 'lever', 'накладка рукоятки')
    p.port('a', (0, 0, 0), -X, Z, dn, 'thread', od=o)
    p.port('b', (L, 0, 0), X, Z, dn, 'thread', od=o)
    return p


def plug_thread(dn=20, name=None):
    """Пробка резьбовая с шестигранником (заглушка воздушника/дренажа)."""
    o = {15: 21.3, 20: 26.9, 25: 33.7}[dn]
    s_ = o + 4
    p = Part(name or f'пробка резьбовая DN{dn} с шестигранником, AISI 316', 'plug', dn)
    p.add(fuse_all([cyl((0, 0, 0), (12, 0, 0), o - 2), hexagon((12, 0, 0), X, s_, 10)]), 'ss_dark')
    p.port('a', (0, 0, 0), -X, Z, dn, 'thread', od=o)
    return p
