"""lib3d.mashiny — изделия для скидов поставщиков и обвязки (добавлено для X-600, стиль и соглашения — как в valves.py):
фланец плоский приварной HG/T 20592 PL (B), кран шаровой с пневмоприводом (пневмоклапан KV), клапан регулирующий с
мембранным приводом и позиционером (TV), затвор дисковый межфланцевый с рукояткой, фильтр сетчатый Y-образный,
клапан балансировочный, ротаметр металлический фланцевый (FT), термометр биметаллический, указатель уровня магнитный (LIA),
насос центробежный вертикальный многоступенчатый (in-line) с электродвигателем, вертикальный электродвигатель на плите
с клиноремённой передачей и кожухом, фильтр-регулятор сжатого воздуха.

Локальная система (как в valves.py): вход 'a' в начале координат смотрит в −X, выход 'b' — в +X, привод/шток — вверх (+Z).
Детали без взаимных проникновений тел (касания), проходят clash3d.py --strict; галерея — gallery_items2.py.
Трубы серии B (метрические, GB/T 14976: 57×3, 45×3, 32×3…) — материал 'SSB' в std.PIPE.
"""
import math
from cadquery import Vector as V
from .core import (Part, Xf, cyl, tube, cone, box, cbox, obox, sph, torus, hexagon, fuse_all, revolve_profile, extrude_poly, unit, vec, perp_ref)
from .piping import bolt_holes, nut_clear_r, flange_plate, MAT_NAME, MAT_COLOR, pipe_dims
from .valves import flanged_body, handwheel, lever
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def _ports(p, fl, L, dn):
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (L, 0, 0), X, Z, dn, 'flange', fl=fl)


def _bore(dn):
    o, w = std.pipe('SS', dn)
    return o - 2 * w


def excl(shape, *others):
    """Тело без объёма других тел (убрать проникновения внутри изделия)."""
    for o in others:
        if o is None:
            continue
        try:
            if shape.BoundingBox().add(o.BoundingBox()) and _bb_overlap(shape, o):
                shape = shape.cut(o)
        except Exception:
            shape = shape.cut(o)
    return shape


def _bb_overlap(a, b):
    A, B = a.BoundingBox(), b.BoundingBox()
    return not (A.xmax < B.xmin or B.xmax < A.xmin or A.ymax < B.ymin or B.ymax < A.ymin or A.zmax < B.zmin or B.zmax < A.zmin)


# ------------------------------------------------------------------ фланец плоский приварной HG/T 20592 PL (B), RF
def pl_flange(dn, pn='PN16', mat='SSB', name=None, od=None, wall=None, color=None):
    """Фланец плоский приварной (PL, HG/T 20592 / ГОСТ 33259 тип 01): тарелка без воротника с выступом RF.
    'a' — тыльная сторона под приварку трубы (−X), 'b' — соединительная плоскость (+X). Присоединительные размеры = std.flange."""
    o, w = pipe_dims(mat, dn, od, wall)
    fl = std.flange(dn, pn, od=o)
    H = fl['C'] + fl['f1']
    s = flange_plate(fl, H, -1, bore=o - 2 * w)
    nm = name or f'фланец плоский приварной PL{dn}-{pn[2:]} RF {MAT_NAME.get(mat, mat)} (HG/T 20592, Dн {o:g})'
    p = Part(nm, 'flange', dn, material=mat)
    p.add(s, color or MAT_COLOR.get(mat, 'ss'))
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (H, 0, 0), X, Z, dn, 'flange', fl=fl)
    p.meta['L'] = H
    return p


# ------------------------------------------------------------------ кран шаровой с пневмоприводом (KV)
def ball_valve_pneumatic(dn, pn='PN16', mat='SS', name=None, tag='', single=False):
    """Кран шаровой фланцевый с пневмоприводом реечного типа (ISO 5211), соленоидным клапаном NAMUR и блоком концевиков
    с указателем положения. single=True — привод одностороннего действия (возвратные пружины, длиннее)."""
    fl = std.flange(dn, pn)
    L = std.BALL_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 4, D * 0.40)
    body = flanged_body(fl, L, br, 0)
    hb = br + D * 0.10
    neck = cyl((L / 2, 0, 0), (L / 2, 0, hb), br * 0.62)
    pad = cbox((L / 2, 0, hb + 5), br * 1.15, br * 1.15, 10)
    body = fuse_all([body, neck, pad]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), _bore(dn)))
    z0 = hb + 10
    # кронштейн (рамка) и муфта
    bh = max(40.0, dn * 0.9)
    brk = cbox((L / 2, 0, z0 + bh / 2), br * 1.1, br * 1.1, bh).cut(cbox((L / 2, 0, z0 + bh / 2), br * 0.7, br * 1.2, bh - 16))
    cpl = cyl((L / 2, 0, z0 + 8), (L / 2, 0, z0 + bh - 8), max(14, dn * 0.3))
    za = z0 + bh
    La = (2.9 if single else 2.2) * max(70.0, dn * 1.6)
    Ha = max(70.0, dn * 1.3)
    Wa = Ha * 0.95
    act = cbox((L / 2, 0, za + Ha / 2), La * 0.86, Wa, Ha)
    caps = [cbox((L / 2 + sg * (La * 0.43 + La * 0.035), 0, za + Ha / 2), La * 0.07, Wa * 1.04, Ha * 1.04) for sg in (-1, 1)]
    act = fuse_all([act] + caps)
    # соленоид NAMUR сбоку (−Y) и блок концевиков сверху
    sol = fuse_all([cbox((L / 2 + La * 0.12, -Wa / 2 - 18, za + Ha * 0.55), 40, 36, 38), cyl((L / 2 + La * 0.12, -Wa / 2 - 36, za + Ha * 0.55),
                                                                                             (L / 2 + La * 0.12, -Wa / 2 - 66, za + Ha * 0.55), 30)])
    lsb = cbox((L / 2, 0, za + Ha + 6 + 30), 100, 80, 60).fuse(cbox((L / 2, 0, za + Ha + 3), 40, 40, 6))
    dome = sph((L / 2, 0, za + Ha + 66), 46).cut(box(-1e4, -1e4, -1e4, 1e4, 1e4, za + Ha + 66))
    p = Part(name or (f'кран шаровой фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)}/PTFE с пневмоприводом '
                      f'{"одностороннего" if single else "двустороннего"} действия, соленоид, концевики' + (f' {tag}' if tag else '')), 'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    p.add(fuse_all([brk]), 'ss_dark', 'кронштейн')
    p.add(cpl, 'ss_dark', 'муфта')
    p.add(act, 'alu', 'пневмопривод')
    p.add(sol, 'black', 'соленоидный клапан')
    p.add(lsb, 'black', 'блок концевиков')
    p.add(dome, 'yellow', 'указатель положения')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, za + Ha + 89))
    p.anchor('tag', (L / 2, 0, za + Ha / 2))
    return p


# ------------------------------------------------------------------ клапан регулирующий с мембранным приводом (TV)
def control_valve(dn, pn='PN16', mat='SS', name=None, tag=''):
    """Клапан регулирующий седельный фланцевый (корпус проходной), бугель, мембранный исполнительный механизм
    (две чаши, болты по кругу), позиционер электропневматический на бугеле, указатель хода."""
    fl = std.flange(dn, pn)
    L = std.GLOBE_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 2, D * 0.32)
    body = flanged_body(fl, L, br, 0).fuse(sph((L / 2, 0, 0), D * 0.82))
    hb = D * 0.48
    bon = cyl((L / 2, 0, D * 0.25), (L / 2, 0, hb), D * 0.42)
    body = fuse_all([body, bon]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), _bore(dn)))
    zb = hb
    Hy = max(140.0, D * 1.2)
    yk = [cyl((L / 2, sg * D * 0.17, zb), (L / 2, sg * D * 0.17, zb + Hy), max(12, D * 0.08)) for sg in (-1, 1)]
    yk += [cyl((L / 2, 0, zb), (L / 2, 0, zb + 14), D * 0.50), cyl((L / 2, 0, zb + Hy - 14), (L / 2, 0, zb + Hy), D * 0.50)]
    yoke = fuse_all(yk)
    stem = cyl((L / 2, 0, zb + 14), (L / 2, 0, zb + Hy - 14), max(10, D * 0.08))
    Dm = max(220.0, D * 1.6)
    zc = zb + Hy
    low = revolve_profile([(20, 0), (Dm * 0.30, 0), (Dm / 2, 50), (Dm / 2, 62), (20, 62)], (L / 2, 0, zc), Z)
    up_ = revolve_profile([(20, 62), (Dm / 2, 62), (Dm / 2, 74), (Dm * 0.30, 124), (20, 124)], (L / 2, 0, zc), Z)
    nut = []
    for k in range(16):
        a = 2 * math.pi * k / 16
        nut.append(cyl((L / 2 + (Dm / 2 - 10) * math.cos(a), (Dm / 2 - 10) * math.sin(a), zc + 50 - 12), (L / 2 + (Dm / 2 - 10) * math.cos(a), (Dm / 2 - 10) * math.sin(a), zc + 86), 10))
    low = low.cut(fuse_all([cyl(q.Center() - Z * 30, q.Center() + Z * 30, 10.5) for q in nut]))
    up_ = up_.cut(fuse_all([cyl(q.Center() - Z * 30, q.Center() + Z * 30, 10.5) for q in nut]))
    pos = cbox((L / 2, -D * 0.17 - 12 - 55, zb + Hy * 0.45), 110, 110, 100)
    pos_br = cbox((L / 2, -D * 0.17 - 6, zb + Hy * 0.45), 60, 12, 80)
    gauge = cyl((L / 2 + 30, -D * 0.17 - 12 - 110, zb + Hy * 0.45 + 25), (L / 2 + 30, -D * 0.17 - 12 - 126, zb + Hy * 0.45 + 25), 40)
    p = Part(name or (f'клапан регулирующий фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)} с мембранным приводом и позиционером' + (f' {tag}' if tag else '')),
             'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    p.add(excl(yoke, body), 'ss_dark', 'бугель')
    p.add(stem, 'ss_dark', 'шток')
    p.add([low, up_], 'paint_grey', 'мембранный привод')
    p.add(fuse_all(nut), 'bolt', 'болты привода')
    p.add(excl(pos_br, yoke), 'ss_dark', 'кронштейн позиционера')
    p.add(pos, 'instr', 'позиционер')
    p.add(gauge, 'dial', 'манометр подачи воздуха')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, zc + 124))
    p.anchor('tag', (L / 2, 0, zc + 62))
    return p


# ------------------------------------------------------------------ затвор дисковый межфланцевый (lug) с рукояткой
def butterfly_valve(dn, pn='PN16', mat='CS', name=None, tag='', lever_dir=X):
    """Затвор дисковый межфланцевый (корпус с проушинами под шпильки), манжета EPDM, рукоятка с фиксацией по гребёнке.
    Строительная длина — EN 558 сер.20 (DN50 — 43, DN65 — 46, DN80 — 46, DN100 — 52). Порты 'a', 'b' — вставные ('insert',
    между ответными фланцами, как держатель мембраны); монтаж в линию — wafer(): одни сквозные шпильки через проушины."""
    fl = std.flange(dn, pn)
    L = {25: 33, 32: 36, 40: 33, 50: 43, 65: 46, 80: 46, 100: 52, 125: 56, 150: 56, 200: 60}[dn]
    D = fl['D']
    o = std.pipe('SS', dn)[0]
    ring = cyl((0, 0, 0), (L, 0, 0), fl['d1'] + 6)
    lugs = []
    for k in range(fl['n']):
        a = math.radians((k + 0.5) * 360 / fl['n'])
        y, z = fl['K'] / 2 * math.sin(a), fl['K'] / 2 * math.cos(a)
        lugs.append(cyl((0, y, z), (L, y, z), fl['L'] + 16))
    neck = cyl((L / 2, 0, fl['d1'] / 2), (L / 2, 0, D / 2 + 40), 40)
    pad = cbox((L / 2, 0, D / 2 + 46), 70, 70, 12)
    body = fuse_all([ring] + lugs + [neck, pad])
    for h in bolt_holes(fl, -1, L + 1):
        body = body.cut(h)
    body = body.cut(cyl((-1, 0, 0), (L + 1, 0, 0), o - 2))
    disc = cyl((L / 2 - 6, 0, 0), (L / 2 + 6, 0, 0), o - 4)
    seat = tube((0.5, 0, 0), (L - 0.5, 0, 0), o - 2, o - 4).cut(disc)
    zt = D / 2 + 52
    stem = cyl((L / 2, 0, zt), (L / 2, 0, zt + 28), 16)
    comb = cbox((L / 2, 0, zt + 4), 90, 26, 8).cut(cyl((L / 2, 0, zt - 1), (L / 2, 0, zt + 9), 17))
    st, gr = lever(V(L / 2, 0, zt + 28), 16, max(200.0, std.LEVER_L.get(dn, 230)), along=unit(lever_dir))
    p = Part(name or (f'затвор дисковый межфланцевый DN{dn} {pn}, корпус {MAT_NAME.get(mat, mat)}, диск AISI 316, манжета EPDM, рукоятка' + (f' {tag}' if tag else '')),
             'valve', dn, material=mat)
    p.add(body, 'cs_paint' if mat == 'CS' else 'ss_cast', 'корпус с проушинами')
    p.add(seat, 'rubber', 'манжета EPDM')
    p.add(disc, 'ss', 'диск')
    p.add(fuse_all([stem, comb]), 'ss_dark', 'шток и гребёнка')
    p.add(st, 'ss_dark', 'рукоятка')
    p.add(gr, 'lever_blue', 'накладка рукоятки')
    p.port('a', (0, 0, 0), -X, Z, dn, 'insert', fl=fl)
    p.port('b', (L, 0, 0), X, Z, dn, 'insert', fl=fl)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, zt + 40))
    return p


def wafer(r, valve, mat=None, pn=None, name_joint=None, up=None):
    """Межфланцевое изделие (затвор дисковый) в линию r: ставится вплотную к текущему фланцу r.cur (манжета — уплотнение,
    отдельных прокладок нет), за ним — ответный воротниковый фланец (на PP — втулка с буртом и свободный фланец); одно болтовое соединение сквозными шпильками через
    проушины корпуса. Дальше линия продолжается от торца ответного фланца под сварку."""
    from .core import align_xf
    from .piping import wn_flange, bolt_joint
    tgt = r.cur
    assert tgt.kind == 'flange', f'{r.line}: межфланцевое изделие ставится только на фланец ({tgt})'
    pa = valve.ports['a']
    roll = 0.0
    if up is not None:
        x0 = align_xf(pa, tgt, 0.0, 0.0)
        lu = x0.d(Z)
        ax = tgt.dir
        u0 = (lu - ax * lu.dot(ax)).normalized()
        u1 = (vec(up) - ax * vec(up).dot(ax)).normalized()
        roll = math.degrees(math.atan2(ax.dot(u0.cross(u1)), u0.dot(u1)))
        pt = std.pitch(tgt.fl)
        roll = round(roll / pt) * pt
    valve.apply(align_xf(pa, tgt, 0.0, roll))
    r.sc.put(valve, r.group, r.line)
    r.sc.link(tgt, valve.ports['a'], 'insert')
    if r.mat in ('PPR', 'PPH'):                      # PP: втулка под фланец + свободный фланец
        from .piping import lap_flange
        f = lap_flange(tgt.dn, pn or tgt.fl['pn'], r.mat)
    else:
        m = mat or (r.mat if r.mat in ('SS', 'CS') else 'SS')
        f = wn_flange(tgt.dn, pn or tgt.fl['pn'], m, od=std.pipe(r.mat, tgt.dn)[0] if r.mat in std.PIPE and tgt.dn in std.PIPE[r.mat] else None)
    f.apply(align_xf(f.ports['b'], valve.ports['b'], 0.0, roll))
    r.sc.put(f, r.group, r.line)
    r.sc.link(valve.ports['b'], f.ports['b'], 'insert')
    j = bolt_joint(tgt, f.ports['b'], gasket=None, name=name_joint or f'соединение межфланцевое DN{tgt.dn} {tgt.fl["pn"]}: '
                   f'{tgt.fl["n"]} шпилек {tgt.fl["bolt"]} сквозь проушины затвора, с гайками (манжета — уплотнение)')
    r.sc.put(j, r.group, r.line)
    r.items += [valve, j, f]
    r.cur = f.ports['a']
    return valve


# ------------------------------------------------------------------ фильтр сетчатый Y-образный
def y_strainer(dn, pn='PN16', mat='SS', name=None, tag=''):
    """Фильтр сетчатый фланцевый Y-образный: корпус, наклонный стакан с сеткой (вниз под 45°), крышка на болтах, пробка слива."""
    fl = std.flange(dn, pn)
    L = std.GLOBE_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 2, D * 0.30)
    body = flanged_body(fl, L, br, 0)
    u = V(0.7071, 0, -0.7071) if dn > 25 else V(0.5, 0, -0.866)    # малые DN: стакан круче — мимо гаек фланцев
    c0 = V(L * (0.25 if dn > 25 else 0.42), 0, 0)
    Ls = max(D * 0.55, (br + 6 + 0.233 * D) / 0.7071 - 22)          # крышка — ниже корпуса прохода
    leg = cyl(c0, c0 + u * Ls, D * 0.5)
    capf = cyl(c0 + u * Ls, c0 + u * (Ls + 14), D * 0.66)
    body = fuse_all([body, leg, capf]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), _bore(dn))).cut(cyl(c0, c0 + u * (Ls - 6), D * 0.5 - 8))
    cap = cyl(c0 + u * (Ls + 14), c0 + u * (Ls + 30), D * 0.66)
    plug = hexagon(c0 + u * (Ls + 30), u, max(17.0, D * 0.15), 12)
    bolts = []
    w1 = Y
    w2 = u.cross(Y)
    for k in range(6):
        a = 2 * math.pi * (k + 0.5) / 6
        q = c0 + u * (Ls + 30) + (w1 * math.cos(a) + w2 * math.sin(a)) * (D * 0.27)
        bolts.append(hexagon(q, u, max(10.0, min(13.0, D * 0.06)), 8))
    p = Part(name or (f'фильтр сетчатый Y-образный фланцевый DN{dn} {pn} {MAT_NAME.get(mat, mat)}, сетка 0,5 мм, пробка слива' + (f' {tag}' if tag else '')), 'valve', dn, material=mat)
    p.add(body, 'ss_cast', 'корпус')
    p.add(excl(fuse_all([cap, plug]), body), 'ss_dark', 'крышка с пробкой слива')
    p.add([excl(b_, body) for b_ in bolts], 'bolt', 'болты крышки')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, D * 0.5))
    return p


# ------------------------------------------------------------------ клапан балансировочный
def balancing_valve(dn, pn='PN16', mat='CS', name=None, tag=''):
    """Клапан балансировочный ручной фланцевый (корпус проходной), рукоятка-маховик с цифровой шкалой настройки и фиксатором,
    два измерительных ниппеля (до и после седла)."""
    fl = std.flange(dn, pn)
    L = std.GLOBE_L[dn]
    D = fl['D']
    br = max(nut_clear_r(fl) + 2, D * 0.32)
    body = flanged_body(fl, L, br, 0).fuse(sph((L / 2, 0, 0), D * 0.78))
    hb = D * 0.45
    bon = cyl((L / 2, 0, D * 0.2), (L / 2, 0, hb + 40), D * 0.38)
    nip = [cyl((L / 2 + sg * D * 0.32, 0, D * 0.2), (L / 2 + sg * D * 0.32, 0, D * 0.2 + D * 0.32), 18) for sg in (-1, 1)]
    body = fuse_all([body, bon] + nip).cut(cyl((-1, 0, 0), (L + 1, 0, 0), _bore(dn)))
    caps = [cyl((L / 2 + sg * D * 0.32, 0, D * 0.52), (L / 2 + sg * D * 0.32, 0, D * 0.52 + 14), 20) for sg in (-1, 1)]
    knob = cyl((L / 2, 0, hb + 40), (L / 2, 0, hb + 40 + 50), D * 0.62)
    scale = cyl((L / 2, 0, hb + 40 + 50), (L / 2, 0, hb + 40 + 56), D * 0.40)
    p = Part(name or (f'клапан балансировочный ручной фланцевый DN{dn} {pn} ({MAT_NAME.get(mat, mat)}), шкала настройки, 2 измерительных ниппеля' + (f' {tag}' if tag else '')),
             'valve', dn, material=mat)
    p.add(body, 'cs_paint' if mat == 'CS' else 'ss_cast', 'корпус')
    p.add(caps, 'red', 'колпачки ниппелей')
    p.add(knob, 'lever_blue', 'рукоятка настройки')
    p.add(scale, 'dial', 'шкала')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, hb + 96))
    return p


# ------------------------------------------------------------------ ротаметр металлический фланцевый (FT)
def rotameter(dn, pn='PN16', mat='SS', name=None, tag='', L=250.0, head_dir=Y):
    """Ротаметр с металлической трубкой (вертикальный, поток снизу вверх): измерительная трубка между фланцами,
    магнитный указатель в корпусе со шкалой (головка сбоку, в сторону head_dir), кабельный ввод выхода 4–20 мА."""
    fl = std.flange(dn, pn)
    D = fl['D']
    br = max(nut_clear_r(fl) + 2, D * 0.30)
    body = flanged_body(fl, L, br, 0).cut(cyl((-1, 0, 0), (L + 1, 0, 0), _bore(dn)))
    hd = unit(head_dir)
    w = hd.cross(X).normalized()
    Hh = 150.0
    c = V(L / 2, 0, 0) + hd * (br + 4 + 45)
    neck = cyl(V(L / 2, 0, 0) + hd * br, V(L / 2, 0, 0) + hd * (br + 4), 40)
    head = obox(c, X, hd, Hh, 90, 140)
    glass = obox(c + hd * 46, X, hd, 110, 2, 110)
    cable = cyl(c + w * 70, c + w * 92, 22)
    p = Part(name or (f'ротаметр фланцевый с металлической трубкой DN{dn} {pn} {MAT_NAME.get(mat, mat)}, местная шкала + 4–20 мА' + (f' {tag}' if tag else '')), 'instrument', dn, material=mat)
    p.add(body, 'ss_cast', 'измерительная трубка')
    p.add(neck, 'ss_dark', 'горловина')
    p.add(head, 'instr', 'корпус указателя')
    p.add(glass, 'glass', 'стекло шкалы')
    p.add(cable, 'black', 'кабельный ввод')
    _ports(p, fl, L, dn)
    p.meta['L'] = L
    p.anchor('tag', c + hd * 50)
    p.anchor('top', c + hd * 50)
    return p


# ------------------------------------------------------------------ термометр биметаллический (на бобышке M20×1,5)
def bimetal_thermometer(tag='TI', name=None, D=100, stem_L=100, back=False):
    """Термометр биметаллический показывающий: штуцер M20×1,5 (порт 'a' — на бобышку, смотрит в −X), гильза-погружная часть
    уходит в −X (внутрь трубы), корпус Ø D: радиальное подключение (циферблат вдоль X) или осевое (back=True — циферблат лицом в +X)."""
    p = Part(name or f'{tag} — термометр биметаллический Ø{D} мм, 0…200 °C, штуцер M20×1,5, погружная часть {stem_L}', 'instrument', 15)
    hexn = hexagon((0, 0, 0), X, 27, 14)
    probe = cyl((-stem_L, 0, 0), (0, 0, 0), 8) if stem_L > 0 else None
    if back:
        ext = cyl((14, 0, 0), (60, 0, 0), 12)
        case = cyl((60, 0, 0), (100, 0, 0), D)
        glass = cyl((100, 0, 0), (104, 0, 0), D - 8)
        dial = None
        top = (104, 0, 0)
    else:
        ext = cyl((14, 0, 0), (60, 0, 0), 12)
        case = cyl((60 + D / 2, -22, 0), (60 + D / 2, 22, 0), D)
        ext = ext.fuse(cyl((58, 0, 0), (60 + 2, 0, 0), 22))
        glass = cyl((60 + D / 2, -22, 0), (60 + D / 2, -26, 0), D - 8)
        top = (60 + D, 0, 0)
    p.add(fuse_all([hexn, ext]), 'ss_dark', 'штуцер и удлинитель')
    if stem_L > 0:
        p.add(probe, 'ss', 'погружная часть')
    p.add(excl(case, ext), 'ss', 'корпус')
    p.add(glass, 'glass', 'стекло и циферблат')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=27.0)
    p.anchor('top', top)
    p.anchor('tag', top)
    return p


# ------------------------------------------------------------------ указатель уровня магнитный (LIA)
def level_gauge(c2c, dn=20, pn='PN16', ext=80.0, name=None, tag='LI', mat='SS'):
    """Указатель уровня магнитный (поплавковый, байпасный): вертикальная камера Ø57 c двумя боковыми патрубками DN к аппарату
    (межосевое c2c), шкала с флажками, верхний воздушник и нижний дренажный кран. Порты 'a' (верхний) и 'b' (нижний) — фланцы,
    смотрят в −X (к ответным фланцам штуцеров аппарата); камера — на расстоянии ext от плоскости фланцев (+X); шкала — в +Y."""
    fl = std.flange(dn, pn)
    o = 57.0
    T = fl['C'] + fl['f1']
    shp, shb = [], []
    for zz in (0.0, -c2c):
        pl = flange_plate(fl, 0.0, +1)
        pl = Xf.move((0, 0, zz)).shape(pl)
        shp.append(pl)
        shp.append(tube((T, 0, zz), (ext, 0, zz), 25.0, 19.0))
    ch = tube((ext + o / 2 - 2, 0, 80), (ext + o / 2 - 2, 0, -c2c - 80), o, o - 6)
    capt = cyl((ext + o / 2 - 2, 0, 80), (ext + o / 2 - 2, 0, 95), o + 10)
    capb = cyl((ext + o / 2 - 2, 0, -c2c - 80), (ext + o / 2 - 2, 0, -c2c - 95), o + 10)
    body = fuse_all(shp + [ch, capt, capb])
    for zz in (0.0, -c2c):
        body = body.cut(cyl((-1, 0, zz), (ext + 4, 0, zz), 19.0))
    for h in bolt_holes(fl, -1, T + 1):
        for zz in (0.0, -c2c):
            body = body.cut(Xf.move((0, 0, zz)).shape(h))
    xc = ext + o / 2 - 2
    scale = cbox((xc, o / 2 + 16, -c2c / 2), 40, 26, c2c + 120)
    scale = scale.cut(cbox((xc, o / 2 + 30, -c2c / 2), 30, 4, c2c + 100))
    win = cbox((xc, o / 2 + 30, -c2c / 2), 30, 4, c2c + 100)
    clamps = [obox((xc, o / 2 + 2, z), X, Y, 30, 4, 20) for z in (0.0 + 20, -c2c / 2, -c2c - 20)]
    vent = cyl((xc, 0, 95), (xc, 0, 125), 20).fuse(hexagon((xc, 0, 125), Z, 22, 10))
    drn = cyl((xc, 0, -c2c - 95), (xc, 0, -c2c - 135), 21.3)
    dv = sph((xc, 0, -c2c - 150), 34).cut(cyl((xc, 0, -c2c - 130), (xc, 0, -c2c - 120), 1))
    dl = cyl((xc, 0, -c2c - 150), (xc + 90, 0, -c2c - 150), 8)
    p = Part(name or f'{tag} — указатель уровня магнитный DN{dn} {pn}, межосевое {c2c:g}, камера Ø57 {MAT_NAME.get(mat, mat)}, шкала с флажками, воздушник и дренажный кран', 'instrument', dn)
    p.add(body, 'ss', 'камера и патрубки')
    p.add(fuse_all([scale] + clamps), 'alu', 'шкала')
    p.add(win, 'red', 'флажки (уровень)')
    p.add(vent, 'ss_dark', 'воздушник')
    p.add(fuse_all([drn, dv]), 'ss_dark', 'дренажный кран')
    p.add(excl(dl, fuse_all([drn, dv])), 'lever', 'рукоятка крана')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (0, 0, -c2c), -X, Z, dn, 'flange', fl=fl)
    p.anchor('tag', (xc, o / 2 + 30, -c2c / 2))
    p.anchor('top', (xc, 0, 125))
    return p


# ------------------------------------------------------------------ насос центробежный вертикальный многоступенчатый (in-line)
def vertical_pump(dn_in, dn_out=None, pn='PN16', kw=1.5, H_stack=320.0, name=None, tag='P', motor_d=None, motor_h=None, foot=(260, 200), c2c=None, zc=None):
    """Насос центробежный вертикальный многоступенчатый (тип CDLF, проточная часть AISI 316L): основание-лапа с соосными
    всасывающим (−X) и напорным (+X) фланцами на одной оси, кожух ступеней, 4 стяжки с гайками, головка с воздушным
    винтом, фонарь с окнами и муфтой, электродвигатель вертикальный IM V1 (рёбра, кожух вентилятора, клеммная коробка).
    Начало — центр основания на уровне опорной поверхности; ось — +Z. Порты 's' (вход) и 'd' (выход) — фланцы, ось на z_c."""
    dn_out = dn_out or dn_in
    fs, fd = std.flange(dn_in, pn), std.flange(dn_out, pn)
    c2c = c2c or {25: 250, 32: 250, 40: 280, 50: 300}.get(max(dn_in, dn_out), 280)
    zc = zc or max(90.0, max(fs['D'], fd['D']) / 2 + 25)
    Lf, Wf = foot
    base = box(-Lf / 2, -Wf / 2, 0, Lf / 2, Wf / 2, 16)
    for sx in (-1, 1):
        for sy in (-1, 1):
            base = base.cut(cyl((sx * (Lf / 2 - 25), sy * (Wf / 2 - 25), -1), (sx * (Lf / 2 - 25), sy * (Wf / 2 - 25), 17), 14))
    # корпус-основание: центральный стакан + 2 патрубка с фланцами
    cup = cyl((0, 0, 16), (0, 0, zc + 70), 170)
    rs = max(nut_clear_r(fs), 30)
    arms = []
    for sg, fl in ((-1, fs), (1, fd)):
        Tf = fl['C'] + fl['f1']
        x_face = sg * c2c / 2
        pl = flange_plate(fl, 0.0, +1)
        pl = Xf.basis([X, Y, Z], [-X * sg, Y * (-sg), Z], V(0, 0, 0), V(x_face, 0, zc)).shape(pl)
        arm = cyl((sg * 60, 0, zc), (x_face - sg * Tf, 0, zc), 2 * min(rs, 0.5 * fl['D'] * 0.62))
        arms += [pl, arm]
    body = fuse_all([cup] + arms)
    body = body.cut(cyl((-c2c / 2 - 1, 0, zc), (-40, 0, zc), _bore(dn_in))).cut(cyl((40, 0, zc), (c2c / 2 + 1, 0, zc), _bore(dn_out)))
    # кожух ступеней, стяжки, головка
    z1 = zc + 70
    z2 = z1 + H_stack
    sleeve = cyl((0, 0, z1), (0, 0, z2), 120)
    head = cyl((0, 0, z2), (0, 0, z2 + 40), 170)
    vent = hexagon((50, 0, z2 + 40), Z, 17, 10)
    rods, nuts = [], []
    for k in range(4):
        a = math.radians(45 + 90 * k)
        q = V(72 * math.cos(a), 72 * math.sin(a), 0)
        rods.append(cyl(q + Z * (z1 + 10), q + Z * z2, 12))
        nuts += [hexagon(q + Z * (z2 + 40), Z, 19, 10), hexagon(q + Z * z1, Z, 19, 10)]
    # фонарь с окнами, муфта, двигатель
    zl = z2 + 40
    Hl = 160.0
    lant = tube((0, 0, zl), (0, 0, zl + Hl), 200, 170)
    for k in range(2):
        a = math.pi * k
        lant = lant.cut(obox((105 * math.cos(a), 105 * math.sin(a), zl + Hl / 2), V(math.cos(a), math.sin(a), 0), Z.cross(V(math.cos(a), math.sin(a), 0)), 60, 90, 100))
    lant = lant.fuse(cyl((0, 0, zl + Hl - 14), (0, 0, zl + Hl), 250))
    cpl = cyl((0, 0, zl + 30), (0, 0, zl + Hl - 30), 70)
    md = motor_d or (150.0 + 30.0 * kw ** 0.5 * 2)
    mh = motor_h or (230.0 + 40.0 * kw ** 0.5 * 2)
    zm = zl + Hl
    mfl = cyl((0, 0, zm), (0, 0, zm + 14), 250)
    mb = cyl((0, 0, zm + 14), (0, 0, zm + 14 + mh), md)
    fins = []
    for k in range(20):
        a = 2 * math.pi * k / 20
        fins.append(obox((md / 2 * math.cos(a), md / 2 * math.sin(a), zm + 14 + mh * 0.45), V(math.cos(a), math.sin(a), 0), Z, 10, mh * 0.8, 4))   # ребро: радиально 10, вдоль оси 0,8·H, толщина 4 (было — поперёк корпуса)
    mot = fuse_all([mfl, mb] + fins)
    cowl = cyl((0, 0, zm + 14 + mh), (0, 0, zm + 14 + mh + 70), md * 0.94)
    tb = cbox((0, -(md / 2 + 30), zm + 14 + mh * 0.35), 110, 60, 110)
    p = Part(name or (f'{tag} — насос центробежный вертикальный многоступенчатый (in-line) DN{dn_in}/DN{dn_out} {pn}, проточная часть AISI 316L, '
                      f'электродвигатель {kw:g} кВт Ex d IIBT4, IM V1'), 'pump', dn_in)
    p.add(base, 'cs_paint', 'опорная плита')
    p.add(body, 'ss_cast', 'основание с патрубками')
    p.add(sleeve, 'ss_polish', 'кожух ступеней')
    p.add(head, 'ss_cast', 'головка')
    p.add(vent, 'ss_dark', 'винт воздушника')
    p.add(rods, 'ss_dark', 'стяжки')
    p.add(nuts, 'bolt', 'гайки стяжек')
    p.add(lant, 'cs_paint', 'фонарь')
    p.add(cpl, 'ss_dark', 'муфта')
    p.add(mot, 'motor', 'электродвигатель')
    p.add(cowl, 'motor', 'кожух вентилятора')
    p.add(excl(tb, mot), 'motor', 'клеммная коробка')
    p.port('s', (-c2c / 2, 0, zc), -X, Z, dn_in, 'flange', fl=fs)
    p.port('d', (c2c / 2, 0, zc), X, Z, dn_out, 'flange', fl=fd)
    p.meta.update(c2c=c2c, zc=zc, H=zm + 14 + mh + 70)
    p.anchor('top', (0, 0, zm + 14 + mh + 70))
    p.anchor('tag', (0, 0, zm + 14 + mh * 0.5))
    p.anchor('base', (0, 0, 0))
    return p


# ------------------------------------------------------------------ двигатель вертикальный + клиноремённая передача
def belt_drive(motor_c, driven_c, z_plate, kw=7.5, motor_d=300.0, motor_h=520.0, pulley_d=(160.0, 250.0), n_belts=3, name_prefix='', driven_shaft_d=60.0):
    """Привод ротора: электродвигатель вертикальный фланцевый (IM V1, валом вниз) на подмоторной плите z_plate, шкив на валу
    двигателя и шкив на валу ротора — под плитой, клиновые ремни (n_belts), натяжные болты плиты, кожух ремней (сетчатый, условно — короб).
    motor_c, driven_c — оси (x, y). Возвращает список Part: двигатель, плита, шкивы с ремнями, кожух."""
    mc, dc = V(motor_c[0], motor_c[1], 0), V(driven_c[0], driven_c[1], 0)
    u = (dc - mc).normalized()
    w = Z.cross(u)
    L = (dc - mc).Length
    parts = []
    # подмоторная плита (салазки с натяжным болтом)
    pl = obox(mc + Z * (z_plate - 10), u, w, motor_d + 120, motor_d + 80, 20).cut(cyl(mc + Z * (z_plate - 25), mc + Z * (z_plate + 5), 60))
    rails = [obox(mc + w * sg * (motor_d / 2 + 25) + Z * (z_plate - 30), u, w, motor_d + 160, 30, 20) for sg in (-1, 1)]
    tens = [cyl(mc - u * (motor_d / 2 + 80) + w * sg * 60 + Z * (z_plate - 10), mc - u * (motor_d / 2 + 20) + w * sg * 60 + Z * (z_plate - 10), 16) for sg in (-1, 1)]
    tn = [hexagon(mc - u * (motor_d / 2 + 80) + w * sg * 60 + Z * (z_plate - 10), -u, 24, 13) for sg in (-1, 1)]
    pp = Part(name_prefix + 'подмоторная плита с салазками и натяжными болтами ремней', 'struct')
    pp.add(fuse_all([pl] + rails), 'cs_paint', 'плита и салазки')
    pp.add([excl(fuse_all([t, n]), fuse_all([pl] + rails)) for t, n in zip(tens, tn)], 'bolt', 'натяжные болты')
    parts.append(pp)
    # двигатель (фланец B5 на плите, корпус вверх, вал вниз)
    m = Part(name_prefix + f'электродвигатель {kw:g} кВт Ex d IIBT4, вертикальный IM V1 (валом вниз), клеммная коробка', 'motor')
    fl = cyl(mc + Z * z_plate, mc + Z * (z_plate + 16), motor_d * 1.05)
    bd = cyl(mc + Z * (z_plate + 16), mc + Z * (z_plate + 16 + motor_h), motor_d)
    fins = [obox(mc + V(motor_d / 2 * math.cos(a), motor_d / 2 * math.sin(a), z_plate + 16 + motor_h * 0.5), V(math.cos(a), math.sin(a), 0), Z, 12, motor_h * 0.85, 4)   # продольные рёбра (было — поперёк)
            for a in [2 * math.pi * k / 24 for k in range(24)]]
    cw = cyl(mc + Z * (z_plate + 16 + motor_h), mc + Z * (z_plate + 16 + motor_h + 90), motor_d * 0.94)
    bodym = fuse_all([fl, bd] + fins + [cw])
    tb = obox(mc + w * (motor_d / 2 + 45) + Z * (z_plate + 16 + motor_h * 0.4), w, u, 90, 130, 130)
    m.add(bodym, 'motor', 'корпус')
    m.add(excl(tb, bodym), 'motor', 'клеммная коробка')
    m.anchor('top', mc + Z * (z_plate + 16 + motor_h + 90))
    m.anchor('tag', mc + Z * (z_plate + 16 + motor_h * 0.6))
    parts.append(m)
    # валы, шкивы, ремни — под плитой
    d1, d2 = pulley_d
    hp = 22.0 * n_belts + 10
    gh = hp + 40
    zp = z_plate - 45 - gh / 2
    sh = cyl(mc + Z * z_plate, mc + Z * (zp - hp / 2 - 10), 38)
    p1 = cyl(mc + Z * (zp - hp / 2), mc + Z * (zp + hp / 2), d1)
    p2 = cyl(dc + Z * (zp - hp / 2), dc + Z * (zp + hp / 2), d2)
    grooves = []
    for k in range(n_belts):
        zz = zp - hp / 2 + 10 + 22 * k + 6
        for c_, dd in ((mc, d1), (dc, d2)):
            p1g = tube(c_ + Z * zz, c_ + Z * (zz + 10), dd + 1, dd - 18)
            grooves.append(p1g)
    pul = Part(name_prefix + f'шкивы клиноремённой передачи Ø{d1:g}/Ø{d2:g}, {n_belts} ремня SPZ', 'drive')
    pul.add(fuse_all([sh, p1]).cut(fuse_all(grooves)), 'ss_dark', 'шкив двигателя с валом')
    pul.add(p2.cut(fuse_all(grooves)).cut(cyl(dc + Z * (zp - hp), dc + Z * (zp + hp), driven_shaft_d)), 'ss_dark', 'шкив ротора (ступица на валу ротора)')
    # ремни: две касательные полосы + дуги (кольцо по шкиву)
    belts = []
    for k in range(n_belts):
        zz = zp - hp / 2 + 10 + 22 * k + 6
        for c_, dd in ((mc, d1), (dc, d2)):
            belts.append(tube(c_ + Z * zz, c_ + Z * (zz + 10), dd + 1, dd - 18))
        for sg in (-1, 1):
            r1, r2 = d1 / 2 - 4, d2 / 2 - 4
            a1 = mc + w * sg * r1 + Z * (zz + 5)
            a2 = dc + w * sg * r2 + Z * (zz + 5)
            belts.append(obox((a1 + a2) * 0.5 + w * sg * 3, (a2 - a1).normalized(), w, (a2 - a1).Length - 10, 9, 10))
    blt = fuse_all(belts)
    pul.add(excl(blt, cyl(mc + Z * (zp - hp), mc + Z * (zp + hp), d1 - 18), cyl(dc + Z * (zp - hp), dc + Z * (zp + hp), d2 - 18)), 'black', 'ремни клиновые')
    pul.anchor('tag', (mc + dc) * 0.5 + Z * zp)
    parts.append(pul)
    # кожух ремней (короб с торцами по шкивам, снизу открыт для обслуживания — условно)
    g = fuse_all([cyl(mc + Z * (zp - gh / 2), mc + Z * (zp + gh / 2), d1 + 80), cyl(dc + Z * (zp - gh / 2), dc + Z * (zp + gh / 2), d2 + 80),
                  obox((mc + dc) * 0.5 + Z * zp, u, w, L, max(d1, d2) + 80, gh)])
    gi = fuse_all([cyl(mc + Z * (zp - gh / 2 + 3), mc + Z * (zp + gh / 2 - 3), d1 + 74), cyl(dc + Z * (zp - gh / 2 + 3), dc + Z * (zp + gh / 2 - 3), d2 + 74),
                   obox((mc + dc) * 0.5 + Z * zp, u, w, L, max(d1, d2) + 74, gh - 6)])
    guard = g.cut(gi).cut(cyl(mc + Z * (zp + gh / 2 - 5), mc + Z * (zp + gh / 2 + 5), 46)).cut(cyl(dc + Z * (zp - gh / 2 - 5), dc + Z * (zp + gh / 2 + 5), driven_shaft_d + 6))
    gp = Part(name_prefix + 'кожух клиноремённой передачи (защитное ограждение)', 'guard')
    gp.add(guard, 'yellow', 'кожух')
    parts.append(gp)
    return parts, dict(z_pulley=zp, h_guard=gh, h_pulley=hp)


# ------------------------------------------------------------------ фильтр-регулятор сжатого воздуха
def air_regulator(dn=20, name=None, tag=''):
    """Фильтр-регулятор сжатого воздуха (резьба G3/4 → патрубки под сварку/резьбу): корпус, колба фильтра со сливом,
    регулировочная ручка, манометр. 'a' — вход (−X), 'b' — выход (+X), резьбовые."""
    L = 90.0
    od = 26.9
    body = cbox((L / 2, 0, 0), L - 20, 60, 60)
    ends = [cyl((0, 0, 0), (12, 0, 0), od + 6), cyl((L - 12, 0, 0), (L, 0, 0), od + 6)]
    bowl = cyl((L / 2, 0, -30), (L / 2, 0, -130), 50).fuse(cyl((L / 2, 0, -130), (L / 2, 0, -145), 20))
    knob = cyl((L / 2, 0, 30), (L / 2, 0, 75), 44)
    g = cyl((L / 2, 30, 0), (L / 2, 45, 0), 14).fuse(cyl((L / 2, 45, 0), (L / 2, 70, 0), 50))
    p = Part(name or (f'фильтр-регулятор сжатого воздуха DN{dn} (G3/4), 0…1 МПа, с манометром' + (f' {tag}' if tag else '')), 'valve', dn)
    p.add(fuse_all([body] + ends), 'alu', 'корпус')
    p.add(bowl, 'glass', 'колба фильтра')
    p.add(knob, 'black', 'ручка регулировки')
    p.add(excl(g, body), 'dial', 'манометр')
    p.port('a', (0, 0, 0), -X, Z, dn, 'thread', od=od)
    p.port('b', (L, 0, 0), X, Z, dn, 'thread', od=od)
    p.meta['L'] = L
    p.anchor('top', (L / 2, 0, 75))
    return p


# ------------------------------------------------------------------ пруток / рукав по сплайну
def sweep_rod(pts, d, d_in=0.0, t0=None, t1=None):
    """Тело круглого сечения Ø d (полое при d_in) по сплайну через точки pts; t0/t1 — касательные на концах (необязательно).
    Одна гладкая поверхность вместо цепочки цилиндров — лёгкая для STEP/GLB (рукава, сварные швы, спирали)."""
    import cadquery as cq
    pts = [vec(p_) for p_ in pts]
    tang = [unit(t0), unit(t1)] if t0 is not None and t1 is not None else None
    path = cq.Wire.assembleEdges([cq.Edge.makeSpline(pts, tangents=tang) if tang else cq.Edge.makeSpline(pts)])
    a = unit(tang[0]) if tang else unit(pts[1] - pts[0])
    xd = a.cross(Z) if abs(a.dot(Z)) < 0.9 else a.cross(X)
    w = cq.Workplane(cq.Plane(origin=pts[0], xDir=xd.normalized(), normal=a)).circle(d / 2)
    if d_in:
        w = w.circle(d_in / 2)
    return w.sweep(cq.Workplane().add(path), isFrenet=False, transition='round').val()


# ------------------------------------------------------------------ рукав по трассе (гладкий, со скруглёнными гибами)
def hose_path_solid(pts, od=16.0, d_in=10.0, R=60.0):
    """Гладкий рукав по ломаной pts: прямые участки + дуги радиуса R в изломах (радиус гиба рукава), сечение — кольцо od/d_in.
    Одна заметаемая поверхность — без «бус» из цилиндров и сфер. Возвращает (тело, длина по оси)."""
    import cadquery as cq
    pts = [vec(p_) for p_ in pts]
    edges, cur = [], pts[0]
    for i in range(1, len(pts) - 1):
        a, b, c = pts[i - 1], pts[i], pts[i + 1]
        din, dout = unit(b - a), unit(c - b)
        th = math.acos(max(-1.0, min(1.0, din.dot(dout))))
        if th < math.radians(1.0):
            continue
        t = min(R * math.tan(th / 2), 0.45 * (b - a).Length, 0.45 * (c - b).Length)
        rr = t / math.tan(th / 2)
        s, e = b - din * t, b + dout * t
        bis = unit(dout - din)
        cc = b + bis * (rr / math.cos(th / 2))
        m = cc - bis * rr
        if (s - cur).Length > 0.01:
            edges.append(cq.Edge.makeLine(cur, s))
        edges.append(cq.Edge.makeThreePointArc(s, m, e))
        cur = e
    edges.append(cq.Edge.makeLine(cur, pts[-1]))
    path = cq.Wire.assembleEdges(edges)
    d0 = unit(pts[1] - pts[0])
    inner = [cq.Wire.makeCircle(d_in / 2, pts[0], d0)] if d_in else []
    sol = cq.Solid.sweep(cq.Wire.makeCircle(od / 2, pts[0], d0), inner, path, makeSolid=True, isFrenet=False, transitionMode='right')
    return sol, path.Length()


def hose_end_fittings(p, d, od=16.0):
    """Конец рукава на штуцере-ёлочке: червячный хомут (лента + замок) на рукаве у торца; p — торец рукава, d — направление внутрь рукава."""
    d = unit(d)
    c = p + d * 12
    band = tube(c - d * 4.5, c + d * 4.5, od + 2.4, od)
    side = perp_ref(d)
    lock = obox(c + side * (od / 2 + 3.0), d, d.cross(side), 11, 7, 5)
    return [band.fuse(lock).cut(cyl(c - d * 6, c + d * 6, od))]


def hose_clip(c, d, od, anchor):
    """Скоба крепления рукава к конструкции: кольцо по рукаву (8 мм) и полоса 20×3 до точки крепления anchor (на конструкции)."""
    d = unit(d)
    ring = tube(c - d * 4, c + d * 4, od + 3, od)
    v = anchor - c
    v = v - d * v.dot(d)
    L = v.Length
    if L < od / 2 + 3:
        return [ring]
    u = unit(v)
    s0 = c + u * (od / 2 + 0.5)
    bar = obox((s0 + anchor - u * 3) * 0.5, u, d, (anchor - u * 3 - s0).Length, 20, 3)
    foot = obox(anchor - u * 1.5, u, d, 3, 30, 30)
    return [fuse_all([ring, bar, foot]).cut(cyl(c - d * 10, c + d * 10, od))]
