"""lib3d.supports — опоры трубопроводов и простые металлоконструкции (в мировых координатах).

Каждая опора — Part с meta['touch'] = [id детали трубы, id конструкции]: проверка check_ports убеждается,
что опора касается и трубы, и конструкции (зазор ≤ 1 мм), т.е. тяга не висит в воздухе и не «втыкается» в трубу.
Опоры не проникают в трубу: хомут охватывает трубу по наружному диаметру (касание).
"""
import math
from cadquery import Vector as V
from .core import Part, cyl, tube, box, cbox, obox, hexagon, fuse_all, unit, vec, revolve_profile, extrude_poly, perp_ref, torus

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def _touch(p, *parts):
    p.meta['touch'] = [q.id for q in parts if q is not None]
    p.contacts = [q.name for q in parts if q is not None]


# ------------------------------------------------------------------ металлопрокат
def ibeam(p0, p1, h=200, b=100, tw=5.6, tf=8.5, up=Z, name='балка двутавровая 20Б1 (ГОСТ Р 57837)', color='beam'):
    """Двутавр от p0 до p1 (ось — центр сечения), стенка вдоль up."""
    p0, p1 = vec(p0), vec(p1)
    ax = (p1 - p0).normalized()
    up = unit(up)
    up = (up - ax * up.dot(ax)).normalized()
    side = ax.cross(up).normalized()
    L = (p1 - p0).Length
    m = (p0 + p1) * 0.5
    web = obox(m, ax, side, L, tw, h - 2 * tf)
    f1 = obox(m + up * (h / 2 - tf / 2), ax, side, L, b, tf)
    f2 = obox(m - up * (h / 2 - tf / 2), ax, side, L, b, tf)
    p = Part(name, 'struct')
    p.add(fuse_all([web, f1, f2]), color)
    return p


def channel(p0, p1, h=160, b=64, t=5.0, tf=8.4, up=Z, opening=None, name='швеллер 16П (ГОСТ 8240)', color='beam'):
    p0, p1 = vec(p0), vec(p1)
    ax = (p1 - p0).normalized()
    up = unit(up)
    up = (up - ax * up.dot(ax)).normalized()
    side = unit(opening) if opening is not None else ax.cross(up).normalized()
    L = (p1 - p0).Length
    m = (p0 + p1) * 0.5
    web = obox(m - side * (b / 2 - t / 2), ax, side, L, t, h)
    f1 = obox(m + up * (h / 2 - tf / 2), ax, side, L, b, tf)
    f2 = obox(m - up * (h / 2 - tf / 2), ax, side, L, b, tf)
    p = Part(name, 'struct')
    p.add(fuse_all([web, f1, f2]), color)
    return p


def angle(p0, p1, a=50, t=5, legs=(Z, Y), name='уголок 50×5 (ГОСТ 8509)', color='sup'):
    """Уголок от p0 до p1: полки вдоль legs[0] и legs[1] от линии p0–p1 (вершина уголка)."""
    p0, p1 = vec(p0), vec(p1)
    ax = (p1 - p0).normalized()
    u, w = unit(legs[0]), unit(legs[1])
    L = (p1 - p0).Length
    m = (p0 + p1) * 0.5
    s1 = obox(m + u * (a / 2) + w * (t / 2), ax, w, L, t, a)
    s2 = obox(m + w * (a / 2) + u * (t / 2), ax, w, L, a, t)
    p = Part(name, 'struct')
    p.add(fuse_all([s1, s2]), color)
    return p


# ------------------------------------------------------------------ подвеска: хомут + тяга + крепление к конструкции
def hanger(c, od, axis, top_z, pipe=None, struct=None, rod_d=12, name=None, line=None, attach='plate'):
    """Подвеска горизонтальной трубы: хомут двухболтовый по наружному диаметру (касание), гайка-бобышка сверху,
    тяга M12 с контргайками и муфтой-талрепом, крепление к низу конструкции на отметке top_z (пластина 120×120×10 с гайкой)."""
    c = vec(c)
    ax = unit(axis)
    up = (Z - ax * Z.dot(ax)).normalized()          # «верх» в плоскости сечения трубы (для трубы с уклоном)
    side = ax.cross(up).normalized()
    R = od / 2
    t, b = 6.0, 40.0
    ring = tube(c - ax * (b / 2), c + ax * (b / 2), od + 2 * t, od)
    # уши сбоку (разъём хомута) и бобышка сверху
    ears, bolts = [], []
    for sg in (-1, 1):
        e0 = c + side * sg * (R + t + 14)
        ear = obox(e0, side, ax, 30, b, 8)
        ears.append(ear.translate(up * 5).fuse(ear.translate(up * -5)))
        bolts.append(fuse_all([cyl(e0 - up * 20, e0 + up * 20, 9.5), hexagon(e0 + up * 9, up, 16, 8), hexagon(e0 - up * 9, -up, 16, 8)]))
    ztop = c.z + (R + t) / max(up.z, 0.5)
    bossz = ztop + 22
    bossc = cyl(V(c.x, c.y, ztop - 8), V(c.x, c.y, bossz), 26)
    # уши: вырез под болт
    clamp = fuse_all([ring, bossc] + ears)
    for sg in (-1, 1):
        e0 = c + side * sg * (R + t + 14)
        clamp = clamp.cut(cyl(e0 - up * 30, e0 + up * 30, 13))
    clamp = clamp.cut(cyl(c - ax * (b / 2 + 1), c + ax * (b / 2 + 1), od))
    plate_t = 10.0
    zp = top_z - plate_t
    nut_h = 14.0
    zr0 = bossz
    zr1 = zp - nut_h
    rod = cyl(V(c.x, c.y, zr0), V(c.x, c.y, zr1), rod_d)
    zm = (zr0 + zr1) / 2
    turn = None
    if zr1 - zr0 > 260:
        turn = obox(V(c.x, c.y, zm), Z, X, 110, 26, 14).fuse(obox(V(c.x, c.y, zm), Z, Y, 110, 14, 26))
        turn = turn.cut(obox(V(c.x, c.y, zm), Z, X, 70, 27, 8))
    lock1 = hexagon(V(c.x, c.y, bossz), Z, 19, 10)
    rodall = fuse_all([rod, lock1] + ([turn] if turn is not None else []))
    pl = box(c.x - 60, c.y - 60, zp, c.x + 60, c.y + 60, top_z)
    pn = hexagon(V(c.x, c.y, zp), -Z, 19, nut_h)
    p = Part(name or f'подвеска трубы Ø{od:g}: хомут двухболтовый, тяга M{rod_d}' + (' с талрепом' if turn is not None else '') + ', пластина крепления к конструкции', 'support')
    p.add(clamp, 'sup_galv', 'хомут')
    p.add(bolts, 'bolt', 'болты хомута')
    p.add(rodall, 'sup_galv', 'тяга')
    p.add(fuse_all([pl, pn]), 'sup', 'пластина крепления с гайкой (приварная)')
    p.line = line
    _touch(p, pipe, struct)
    p.anchor('top', (c.x, c.y, top_z))
    return p


def shoe(c, od, axis, base_z, pipe=None, struct=None, name=None, line=None, guide=True):
    """Опора-башмак (скользящая) под горизонтальную трубу: ложемент 120° по трубе, рёбра, опорная плита на конструкции."""
    c = vec(c)
    ax = unit(axis)
    side = ax.cross(Z).normalized()
    R = od / 2
    Lb = max(120.0, od * 1.4)
    t = 8.0
    # ложемент: сектор трубы ±60° снизу
    sector = tube(c - ax * (Lb / 2), c + ax * (Lb / 2), od + 2 * t, od)
    cutter = box(-1e5, -1e5, c.z - R * math.cos(math.radians(60)), 1e5, 1e5, 1e5)
    cradle = sector.cut(cutter)
    zb = c.z - R - t
    web = obox(V(c.x, c.y, (zb + base_z + 10) / 2 + 2), ax, side, Lb - 20, 10, (zb + 4) - (base_z + 10))
    ribs = []
    for sg in (-1, 1):
        ribs.append(obox(V(c.x, c.y, (zb + base_z + 10) / 2 + 2) + ax * sg * (Lb / 2 - 15), ax, side, 10, R * 1.2, (zb + 4) - (base_z + 10)))
    base = obox(V(c.x, c.y, base_z + 5), ax, side, Lb, R * 1.2 + 40, 10)
    body = fuse_all([cradle, web, base] + ribs)
    body = body.cut(cyl(c - ax * Lb, c + ax * Lb, od))
    p = Part(name or f'опора-башмак скользящая под трубу Ø{od:g} (ОСТ 36-146), на конструкции', 'support')
    p.add(body, 'sup', 'башмак')
    if guide:
        g = []
        for sg in (-1, 1):
            g.append(obox(V(c.x, c.y, base_z + 20) + side * sg * ((R * 1.2 + 40) / 2 + 12 + 1), ax, side, 60, 24, 40))
        p.add(g, 'sup', 'направляющие')
    p.line = line
    _touch(p, pipe, struct)
    p.anchor('base', (c.x, c.y, base_z))
    return p


def stanchion(c, od, axis, base_z, pipe=None, struct=None, name=None, line=None, post_d=76.0):
    """Опора-стойка на перекрытие/пол: опорная плита с анкерами, стойка-труба, ложемент, U-болт по трубе."""
    c = vec(c)
    ax = unit(axis)
    side = ax.cross(Z).normalized()
    R = od / 2
    zc = c.z - R                    # низ трубы
    cr_t = 10.0
    cr = obox(V(c.x, c.y, zc - cr_t / 2), ax, side, 80, od + 60, cr_t)
    ud = 10.0 if od < 80 else 12.0
    # U-болт: полутор + две ветви вниз сквозь ложемент (отверстия), гайки снизу
    Ru = R + ud / 2
    ub = torus(c, ax, Ru, ud / 2).cut(box(-1e5, -1e5, -1e5, 1e5, 1e5, c.z))
    legs = []
    for sg in (-1, 1):
        q = c + side * sg * Ru
        cr = cr.cut(cyl(V(q.x, q.y, zc - cr_t - 1), V(q.x, q.y, zc + 1), ud + 2))
        legs += [cyl(q, V(q.x, q.y, zc - cr_t - 14), ud), hexagon(V(q.x, q.y, zc - cr_t), -Z, ud * 1.6, ud * 0.8)]
    post_d = min(post_d, 2 * (Ru - 0.93 * ud) - 4)       # ветви U-болта и гайки (описанный радиус 0,93·ud) — снаружи стойки
    post = tube(V(c.x, c.y, base_z + 14), V(c.x, c.y, zc - cr_t), post_d, post_d - 8)
    bp = box(c.x - 100, c.y - 100, base_z, c.x + 100, c.y + 100, base_z + 14)
    anchors = []
    for dx in (-75, 75):
        for dy in (-75, 75):
            bp = bp.cut(cyl((c.x + dx, c.y + dy, base_z - 1), (c.x + dx, c.y + dy, base_z + 15), 18))
            anchors.append(fuse_all([cyl((c.x + dx, c.y + dy, base_z), (c.x + dx, c.y + dy, base_z + 14 + 22), 16), hexagon((c.x + dx, c.y + dy, base_z + 14), Z, 24, 13)]))
    gus = []
    for k in range(4):
        a = math.radians(45 + 90 * k)
        u = V(math.cos(a), math.sin(a), 0)
        nrm = u.cross(Z)
        gus.append(extrude_poly([(post_d / 2 - 1, 0), (95, 0), (post_d / 2 - 1, 110)], V(c.x, c.y, base_z + 14) - nrm * 4, u, nrm, 8))
    p = Part(name or f'опора-стойка под трубу Ø{od:g}: плита 200×200 с анкерами M16, стойка Ø{post_d:g}, ложемент, U-болт', 'support')
    p.add(fuse_all([bp, post, cr] + gus), 'sup', 'стойка')
    p.add(fuse_all([ub] + legs), 'sup_galv', 'U-болт с гайками')
    p.add(anchors, 'bolt', 'анкеры')
    p.line = line
    _touch(p, pipe, struct)
    p.anchor('base', (c.x, c.y, base_z))
    return p


def riser_clamp(c, od, z_rest, along=X, pipe=None, struct=None, name=None, line=None, span=None):
    """Хомут стояка (опора вертикальной трубы на конструкцию): две полосы 80×12 по обе стороны трубы с полукруглыми
    вырезами, стянуты 4 болтами; концы полос лежат на конструкции на отметке z_rest."""
    c = vec(c)
    al = unit(along)
    side = Z.cross(al).normalized()
    R = od / 2
    span = span or (od + 260)
    h, t = 80.0, 12.0
    bars, bolts = [], []
    for sg in (-1, 1):
        bc = V(c.x, c.y, z_rest + h / 2) + side * sg * (R + t / 2 - 6)
        bar = obox(bc, al, side, span, t, h)
        bar = bar.cut(cyl(V(c.x, c.y, z_rest - 1), V(c.x, c.y, z_rest + h + 1), od))
        bars.append(bar)
    for s2 in (-1, 1):
        q = V(c.x, c.y, z_rest + h / 2) + al * s2 * (R + 30)
        bolts.append(fuse_all([cyl(q - side * (R + 20), q + side * (R + 20), 16), hexagon(q + side * (R + t - 6), side, 24, 13), hexagon(q - side * (R + t - 6), -side, 24, 13)]))
    for i in range(len(bars)):
        for s2 in (-1, 1):
            q = V(c.x, c.y, z_rest + h / 2) + al * s2 * (R + 30)
            bars[i] = bars[i].cut(cyl(q - side * (R + 40), q + side * (R + 40), 18))
    p = Part(name or f'хомут стояка Ø{od:g}: полосы 80×12, 4 болта M16, опирание на конструкцию', 'support')
    p.add(bars, 'sup', 'полосы хомута')
    p.add(bolts, 'bolt', 'болты')
    p.line = line
    _touch(p, pipe, struct)
    return p


def wall_bracket(c, od, wall_pt, wall_n, axis=Z, pipe=None, struct=None, name=None, line=None):
    """Консоль на стену под трубу: закладная пластина на стене, уголок-кронштейн с подкосом, хомут по трубе.
    wall_n — нормаль стены наружу (в сторону трубы). Для вертикальной трубы (axis=Z) — хомут кольцом; для горизонтальной — U-болт."""
    c = vec(c)
    n = unit(wall_n)
    wp = vec(wall_pt)
    d = (c - wp).dot(n)                       # вылет оси трубы от стены
    R = od / 2
    side = Z.cross(n).normalized()
    base = obox(wp + n * 6 + V(0, 0, c.z - wp.z), n, side, 12, 160, 220)
    t, b = 6.0, 50.0
    ring = None
    if abs(unit(axis).dot(Z)) > 0.9:
        ring = tube(V(c.x, c.y, c.z - b / 2), V(c.x, c.y, c.z + b / 2), od + 2 * t, od)
        arm_end = d - R - t + 2
        arm = obox(wp + n * (12 + (arm_end - 12) / 2) + V(0, 0, c.z - wp.z), n, side, arm_end - 12, 50, 50)
        brace_len = math.hypot(arm_end - 40, 180)
        bdir = (n * (arm_end - 40) + Z * 180).normalized()
        brace = obox(wp + n * 12 + V(0, 0, c.z - wp.z - 205) + bdir * (brace_len / 2), bdir, side, brace_len, 40, 6)
        body = fuse_all([base, arm, brace, ring]).cut(cyl(V(c.x, c.y, c.z - 100), V(c.x, c.y, c.z + 100), od))
    else:
        arm_end = d + R + 40
        zc = c.z - R
        arm = obox(wp + n * (12 + (arm_end - 12) / 2) + V(0, 0, zc - 25 - wp.z), n, side, arm_end - 12, 60, 50)
        brace_len = math.hypot(arm_end - 40, 200)
        bdir = (n * (arm_end - 40) + Z * 200).normalized()
        brace = obox(wp + n * 12 + V(0, 0, zc - 50 - 200 - wp.z) + bdir * (brace_len / 2), bdir, side, brace_len, 40, 6)
        body = fuse_all([base, arm, brace])
    p = Part(name or f'консоль на стену под трубу Ø{od:g}: закладная 160×220, кронштейн 50×50 с подкосом, хомут', 'support')
    p.add(body, 'sup', 'консоль')
    anchors = [fuse_all([cyl(wp + n * 12 + V(0, 0, c.z - wp.z) + side * dy + Z * dz, wp + n * 30 + V(0, 0, c.z - wp.z) + side * dy + Z * dz, 14),
                         hexagon(wp + n * 12 + V(0, 0, c.z - wp.z) + side * dy + Z * dz, n, 22, 11)]) for dy in (-55, 55) for dz in (-80, 80)]
    p.add(anchors, 'bolt', 'анкеры')
    p.line = line
    _touch(p, pipe, struct)
    return p


def sleeve(c, axis, od_pipe, length, name=None, line=None, gap=10.0):
    """Гильза в проходке (перекрытие/стена): труба-гильза с зазором и уплотнением."""
    c = vec(c)
    ax = unit(axis)
    s = tube(c - ax * (length / 2), c + ax * (length / 2), od_pipe + 2 * gap + 8, od_pipe + 2 * gap)
    seal = tube(c - ax * (length / 2 - 2), c - ax * (length / 2 - 22), od_pipe + 2 * gap, od_pipe)
    p = Part(name or f'гильза проходки под трубу Ø{od_pipe:g} с уплотнением', 'sleeve')
    p.add(s, 'sup', 'гильза')
    p.add(seal, 'rubber', 'уплотнение')
    p.line = line
    return p
