"""lib3d.equipment — узлы аппаратов: люк быстрооткрываемый, смотровое окно со светильником, мотор-редуктор со стойкой
и муфтой, двойное торцевое уплотнение с бачком затворной жидкости, лапа опорная с косынками, седловая опора.

Люк и окно — в локальной системе (ось +X — наружу из аппарата, начало — низ горловины), далее Xf/«place_axis».
Привод, уплотнение, лапы, сёдла — в мировых координатах (вертикальный вал).
"""
import math
from cadquery import Vector as V
from .core import Part, Xf, cyl, tube, cone, box, cbox, obox, hexagon, fuse_all, sph, torus, revolve_profile, extrude_poly, unit, vec, perp_ref
from .piping import bolt_holes, nut_clear_r
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def place_axis(part, base, axis, up=Z):
    """Перенести деталь, построенную вдоль +X от начала, в точку base с осью axis; локальный +Z — к up."""
    axis = unit(axis)
    u = vec(up) - axis * vec(up).dot(axis)
    if u.Length < 1e-6:
        u = perp_ref(axis)
    x = Xf.basis([X, Z, X.cross(Z)], [axis, u.normalized(), axis.cross(u.normalized())], V(0, 0, 0), vec(base))
    return part.apply(x)


# ------------------------------------------------------------------ люк быстрооткрываемый
def quick_manhole(dn=450, neck_od=480, neck_t=10, H=380, D=640, Tf=40, n_bolts=5, sight_dn=100, name=None, tag='M', sight=True):
    """Люк с быстрооткрываемой крышкой (HG/T 21518): горловина, фланец корпуса, прокладка, крышка со смотровым окном,
    шарнир (2 проушины на корпусе + 1 на крышке, ось), откидные болты на вилках с барашковыми гайками, ручка."""
    p = Part(name or f'{tag} — люк DN{dn} с быстрооткрываемой крышкой (HG/T 21518): шарнир, {n_bolts} откидных болтов, смотровое окно DN{sight_dn}', 'manhole', dn)
    g = 3.0
    x_f0, x_f1 = H - Tf, H                       # фланец корпуса
    x_c0, x_c1 = H + g, H + g + Tf                # крышка
    neck = tube((0, 0, 0), (x_f0, 0, 0), neck_od, neck_od - 2 * neck_t)
    flb = tube((x_f0, 0, 0), (x_f1, 0, 0), D, neck_od - 2 * neck_t)
    gk = tube((x_f1, 0, 0), (x_c0, 0, 0), D - 70, neck_od - 2 * neck_t + 10)
    cover = cyl((x_c0, 0, 0), (x_c1, 0, 0), D)
    # шарнир — вверху (+Z)
    zr = D / 2 + 28
    lugB = []
    for sg in (-1, 1):
        lb = box(x_f0, sg * 22, D / 2 - 15, x_f1 + 24, sg * 58, zr + 22)
        lb = lb.cut(box(x_f1, -100, -1e4, x_f1 + 30, 100, D / 2 + 3))
        lugB.append(lb)
    lugC = box(x_f1 - 20, -19, D / 2 - 15, x_c1, 19, zr + 22).cut(box(x_f1 - 21, -100, -1e4, x_c0, 100, D / 2 + 3))
    pin_x = x_f1 + 2
    pin = cyl((pin_x, -66, zr), (pin_x, 66, zr), 20)
    for i in range(2):
        lugB[i] = lugB[i].cut(cyl((pin_x, -70, zr), (pin_x, 70, zr), 21))
    lugC = lugC.cut(cyl((pin_x, -70, zr), (pin_x, 70, zr), 21))
    pin = fuse_all([pin, cyl((pin_x, -66, zr), (pin_x, -60, zr), 30), cyl((pin_x, 60, zr), (pin_x, 66, zr), 30)])
    # откидные болты
    forks, bolts, lugsC = [], [], []
    rp = D / 2 + 26
    for k in range(n_bolts):
        phi = math.radians(360.0 * (k + 1) / (n_bolts + 1))
        u = V(0, math.sin(phi), math.cos(phi))
        t = X.cross(u).normalized()
        for sg in (-1, 1):
            fk = obox(V(x_f0 + (Tf + 0) / 2, 0, 0) + u * (D / 2 + 22) + t * sg * 15, u, t, 64, 8, Tf)
            fk = fk.cut(cyl(V(x_f0 + Tf / 2, 0, 0) + u * rp - t * 30, V(x_f0 + Tf / 2, 0, 0) + u * rp + t * 30, 17))
            forks.append(fk)
        # проушина крышки с пазом
        lc = obox(V(x_c0 + Tf / 2 + 0, 0, 0) + u * (D / 2 + 22), u, t, 64, 46, Tf - 6).translate(X * 3)
        lc = lc.cut(obox(V(x_c0 + Tf / 2, 0, 0) + u * (rp + 19), u, t, 60, 23, Tf + 10))
        lugsC.append(lc)
        # болт: проушина на оси вилки, стержень вдоль +X сквозь паз, шайба и барашек сверху
        pc = V(x_f0 + Tf / 2, 0, 0) + u * rp
        eye = cyl(pc - t * 10.5, pc + t * 10.5, 34).cut(cyl(pc - t * 11, pc + t * 11, 16.5))
        pinb = cyl(pc - t * 22, pc + t * 22, 16)
        shank = cyl(pc + X * 15, pc + X * (x_c1 + 3 - pc.x + 32), 20)
        wash = cyl(V(x_c1 + 3, 0, 0) + u * rp, V(x_c1 + 7, 0, 0) + u * rp, 40)
        wing = fuse_all([cyl(V(x_c1 + 7, 0, 0) + u * rp, V(x_c1 + 25, 0, 0) + u * rp, 30),
                         obox(V(x_c1 + 18, 0, 0) + u * rp, X, t, 18, 70, 8)])
        wash = wash.cut(cyl(V(x_c1 + 2, 0, 0) + u * rp, V(x_c1 + 30, 0, 0) + u * rp, 20.6))
        wing = wing.cut(cyl(V(x_c1 + 2, 0, 0) + u * rp, V(x_c1 + 30, 0, 0) + u * rp, 20.6))
        bolts.append(fuse_all([eye, shank]))
        bolts.append(fuse_all([wash, wing]))
        bolts.append(pinb)
    for i in range(len(forks)):
        pass
    # смотровое окно S1 в крышке
    sd = 100.0 if sight else 0.0
    boss = cyl((x_c1, 0, 0), (x_c1 + 25, 0, 0), 180)
    if not sight:
        cov = fuse_all([cover, lugC] + lugsC)
        handle = fuse_all([cyl((x_c1, -110, -D / 2 + 120), (x_c1 + 70, -110, -D / 2 + 120), 18), cyl((x_c1, 110, -D / 2 + 120), (x_c1 + 70, 110, -D / 2 + 120), 18),
                           cyl((x_c1 + 70, -119, -D / 2 + 120), (x_c1 + 70, 119, -D / 2 + 120), 22)])
        p.add(fuse_all([neck, flb] + lugB + forks), 'ss', 'горловина и фланец корпуса с проушинами')
        p.add(gk, 'ptfe', 'прокладка')
        p.add(cov, 'ss', 'крышка')
        p.add([pin], 'ss_dark', 'ось шарнира')
        p.add(bolts, 'bolt', 'откидные болты с барашками')
        p.add(handle, 'ss_dark', 'ручка крышки')
        p.port('a', (0, 0, 0), -X, Z, dn, 'info')
        p.anchor('top', (x_c1, 0, 0))
        p.meta.update(H=H, D=D)
        return p
    cov = fuse_all([cover, lugC, boss] + lugsC).cut(cyl((x_c0 - 1, 0, 0), (x_c1 + 26, 0, 0), sd))
    ring = cyl((x_c1 + 25, 0, 0), (x_c1 + 45, 0, 0), 180).cut(cyl((x_c1 + 24, 0, 0), (x_c1 + 40, 0, 0), 122)).cut(cyl((x_c1 + 24, 0, 0), (x_c1 + 46, 0, 0), sd))
    glass = cyl((x_c1 + 25, 0, 0), (x_c1 + 40, 0, 0), 120)
    studs = []
    for k in range(6):
        a = math.radians(30 + 60 * k)
        q = V(x_c1, 76 * math.sin(a), 76 * math.cos(a))
        cov = cov.cut(cyl(q + X * 5, q + X * 26, 13))
        ring = ring.cut(cyl(q + X * 24, q + X * 46, 14))
        studs.append(fuse_all([cyl(q + X * 5, q + X * 62, 12), hexagon(q + X * 45, X, 18, 10)]))
    handle = fuse_all([cyl((x_c1, -110, -D / 2 + 120), (x_c1 + 70, -110, -D / 2 + 120), 18), cyl((x_c1, 110, -D / 2 + 120), (x_c1 + 70, 110, -D / 2 + 120), 18),
                       cyl((x_c1 + 70, -119, -D / 2 + 120), (x_c1 + 70, 119, -D / 2 + 120), 22)])
    body = fuse_all([neck, flb] + lugB + forks)
    p.add(body, 'ss', 'горловина и фланец корпуса с проушинами')
    p.add(gk, 'ptfe', 'прокладка')
    p.add(cov, 'ss', 'крышка')
    p.add(glass, 'glass', 'стекло S1')
    p.add(ring, 'ss_dark', 'кольцо прижимное S1')
    p.add(studs, 'bolt', 'шпильки S1')
    p.add([pin], 'ss_dark', 'ось шарнира')
    p.add(bolts, 'bolt', 'откидные болты с барашками')
    p.add(handle, 'ss_dark', 'ручка крышки')
    p.port('a', (0, 0, 0), -X, Z, dn, 'info')
    p.anchor('top', (x_c1 + 45, 0, 0))
    p.meta.update(H=H, D=D)
    return p


# ------------------------------------------------------------------ смотровое окно со светильником
def sight_window(dn=100, pn='PN16', H=170, lamp=True, name=None, tag='S'):
    """Окно смотровое (NB/T 21619): горловина, фланец, стекло на прокладках, прижимной фланец, шпильки с гайками;
    светильник Ex на кронштейне, направлен в окно."""
    fl = std.flange(dn, pn)
    o, w = std.pipe('SS', dn)
    D, K, C = fl['D'], fl['K'], fl['C']
    p = Part(name or f'{tag} — окно смотровое DN{dn} {pn} (NB/T 21619)' + (' со светильником Ex' if lamp else ''), 'window', dn)
    neck = tube((0, 0, 0), (H - C, 0, 0), o + 6, o - 2 * w)
    f0 = tube((H - C, 0, 0), (H, 0, 0), D, o - 2 * w)
    for h in bolt_holes(fl, H - C - 1, H + 1):
        f0 = f0.cut(h)
    g1 = tube((H, 0, 0), (H + 2, 0, 0), K - fl['L'] - 6, o - 2 * w)
    gl = cyl((H + 2, 0, 0), (H + 22, 0, 0), K - fl['L'] - 6)
    g2 = tube((H + 22, 0, 0), (H + 24, 0, 0), K - fl['L'] - 6, o - 2 * w)
    f1 = tube((H + 24, 0, 0), (H + 24 + C, 0, 0), D, o - 2 * w - 10)
    for h in bolt_holes(fl, H + 23, H + 25 + C):
        f1 = f1.cut(h)
    d, s_, m = std.BOLT[fl['bolt']]
    studs = []
    for i in range(fl['n']):
        a = math.radians((i + 0.5) * 360 / fl['n'])
        q = V(0, K / 2 * math.sin(a), K / 2 * math.cos(a))
        studs.append(fuse_all([cyl(q + X * (H - C - m - 5), q + X * (H + 24 + C + m + 5), d), hexagon(q + X * (H - C), -X, s_, m), hexagon(q + X * (H + 24 + C), X, s_, m)]))
    p.add(fuse_all([neck, f0]), 'ss', 'горловина с фланцем')
    p.add([g1, g2], 'ptfe', 'прокладки')
    p.add(gl, 'glass', 'стекло боросиликатное')
    p.add(f1, 'ss', 'фланец прижимной')
    p.add(studs, 'bolt', 'шпильки с гайками')
    if lamp:
        # кронштейн под гайку верхней шпильки, светильник под 35° к оси окна
        i0 = 0
        a = math.radians((i0 + 0.5) * 360 / fl['n'])
        q = V(H + 24 + C + m, K / 2 * math.sin(a), K / 2 * math.cos(a))
        u = V(0, math.sin(a), math.cos(a))
        br0 = q
        arm = obox(br0 + X * 3 + u * 40, u, X.cross(u), 110, 30, 6)
        arm = arm.cut(cyl(q - X * 1, q + X * 7, d + 1))
        up_arm = obox(br0 + X * (6 + 60) + u * 92, X, X.cross(u), 120, 30, 6)
        lc = br0 + X * 140 + u * 60
        ax = (V(H + 24 + C, 0, 0) - lc).normalized()
        housing = cyl(lc - ax * 80, lc + ax * 40, 86)
        front = cyl(lc + ax * 40, lc + ax * 52, 74)
        fins = [cyl(lc - ax * (70 - 14 * k), lc - ax * (64 - 14 * k), 98) for k in range(4)]
        gland = cyl(lc - ax * 80, lc - ax * 110, 22)
        p.add(fuse_all([arm, up_arm, housing] + fins + [gland]), 'instr_grey', 'светильник Ex для смотрового окна на кронштейне')
        p.add(front, 'glass', 'стекло светильника')
        p.add(cyl(lc - ax * 110, lc - ax * 200, 9), 'cable', 'кабель')
    p.port('a', (0, 0, 0), -X, Z, dn, 'info')
    p.anchor('top', (H + 24 + C, 0, 0))
    return p


# ------------------------------------------------------------------ привод мешалки
def agitator_drive(c, z0, stand_h=800, stand_d0=560, stand_d1=440, gear_d=380, gear_h=230, motor_d=380, motor_h=560, kw=45, shaft_d=95,
                   name_prefix='', seal=True, pot_side=(1, 0, 0), seal_hoses=False):
    """Привод мешалки на опорном фланце z0: стойка-фонарь с окнами, муфта, редуктор, мотор (рёбра, кожух вентилятора,
    клеммная коробка с кабельным вводом, рым-болт), двойное торцевое уплотнение и бачок затворной жидкости с трубками.
    seal_hoses=True (замечание Мареева 25.10, п.8/17): бачок поднят выше уплотнения (термосифон), штуцеры бачка — к уплотнению,
    подача (низ бачка → нижний штуцер уплотнения) и возврат (верхний штуцер → верх бачка) — металлорукавами в оплётке DN10
    (lib3d.tara.rukav), вместо трубок. Возвращает список Part."""
    c = V(c[0], c[1], 0)
    P = []
    pre = name_prefix
    # --- стойка-фонарь
    zt = z0 + stand_h
    shell = revolve_profile([(stand_d0 / 2 - 40, 30), (stand_d0 / 2 - 30, 30), (stand_d1 / 2 - 10, stand_h - 30), (stand_d1 / 2 - 20, stand_h - 30)], c + Z * z0, Z)
    shell = shell.fuse(tube(c + Z * z0, c + Z * (z0 + 30), stand_d0, stand_d0 - 200)).fuse(tube(c + Z * (zt - 30), c + Z * zt, stand_d1, stand_d1 - 160))
    ws = []
    pu = unit(pot_side)
    pv = Z.cross(pu)
    for sg in (-1, 1):
        ws.append(obox(c + Z * (z0 + stand_h * 0.55) + pv * sg * stand_d0 * 0.4, pv, Z, stand_d0 * 0.5, stand_h * 0.62, 260))
        ws.append(obox(c + Z * (z0 + 30 + 120) + pu * sg * stand_d0 * 0.4, pu, Z, stand_d0 * 0.5, 200, 220))
    for wbox in ws:
        shell = shell.cut(wbox)
    st = Part(f'{pre}стойка привода (фонарь) с окнами обслуживания', 'drive')
    st.add(shell, 'paint_grey')
    P.append(st)
    # --- двойное торцевое уплотнение (картридж) на опорном фланце
    sl = Part(f'{pre}уплотнение торцевое двойное 2020B-095 (вал Ø{shaft_d}, фланец Ø305, H 215), подвод/отвод затворной жидкости', 'seal')
    # по чертежу «2020B Double mechanical seal DN95»: фланец Ø305 (8 отв. Ø22 на Ø270), высота 215, корпус с рубашкой охлаждения
    gl = cyl(c + Z * z0, c + Z * (z0 + 22), 305)
    bd = cyl(c + Z * (z0 + 22), c + Z * (z0 + 150), 230)
    up_ = cyl(c + Z * (z0 + 150), c + Z * (z0 + 190), 170)
    cl = cyl(c + Z * (z0 + 190), c + Z * (z0 + 215), 150)
    sbody = fuse_all([gl, bd, up_, cl]).cut(cyl(c + Z * (z0 - 1), c + Z * (z0 + 216), shaft_d + 2))
    for a_ in range(8):
        q = c + V(135 * math.cos(math.radians(22.5 + 45 * a_)), 135 * math.sin(math.radians(22.5 + 45 * a_)), 0)
        sbody = sbody.cut(cyl(q + Z * (z0 - 1), q + Z * (z0 + 23), 22))
    nuts = [fuse_all([cyl(c + Z * (z0 - 0) + V(135 * math.cos(math.radians(22.5 + 45 * a_)), 135 * math.sin(math.radians(22.5 + 45 * a_)), 0),
                          c + Z * (z0 + 22 + 18 + 6) + V(135 * math.cos(math.radians(22.5 + 45 * a_)), 135 * math.sin(math.radians(22.5 + 45 * a_)), 0), 20),
                      hexagon(c + Z * (z0 + 22) + V(135 * math.cos(math.radians(22.5 + 45 * a_)), 135 * math.sin(math.radians(22.5 + 45 * a_)), 0), Z, 30, 18)])
            for a_ in range(8)]
    sl.add(nuts, 'bolt', 'гайки крепления')
    ports = []
    for k, dz in enumerate((60, 120)):
        q0 = c + Z * (z0 + 24 + dz) + pu * 105
        q0 = q0 + pv * (40 if k else -40)
        q0 = q0 - pu * (105 - math.sqrt(115 ** 2 - 40 ** 2))
        ports.append(fuse_all([cyl(q0 - pu * 12, q0 + pu * 22, 22), hexagon(q0 + pu * 22, pu, 22, 10)]))
    sl.add(fuse_all([sbody] + ports), 'ss', 'корпус уплотнения со штуцерами затворной жидкости G1/2')
    P.append(sl)
    # --- вал над уплотнением и муфта
    zc = z0 + stand_h * 0.55
    sh = Part(f'{pre}вал мешалки Ø{shaft_d} (участок в стойке)', 'shaft')
    sh.add(cyl(c + Z * (z0 + 215), c + Z * (zc - 60), shaft_d), 'ss_polish')
    P.append(sh)
    cp = Part(f'{pre}муфта упругая (полумуфты, звёздочка)', 'coupling')
    h1 = cyl(c + Z * (zc - 60), c + Z * (zc - 4), shaft_d * 2.0)
    spider = cyl(c + Z * (zc - 4), c + Z * (zc + 4), shaft_d * 1.7)
    h2 = cyl(c + Z * (zc + 4), c + Z * (zc + 60), shaft_d * 2.0)
    cp.add([h1, h2], 'cs_paint', 'полумуфты')
    cp.add(spider, 'rubber', 'звёздочка')
    P.append(cp)
    so = Part(f'{pre}вал выходной редуктора', 'shaft')
    so.add(cyl(c + Z * (zc + 60), c + Z * zt, shaft_d * 0.9), 'ss_dark')
    P.append(so)
    # --- редуктор
    gr = Part(f'{pre}редуктор цилиндрический соосный (мотор-редуктор {kw} кВт)', 'gear')
    g0 = zt
    gb = fuse_all([cyl(c + Z * g0, c + Z * (g0 + 22), stand_d1), cyl(c + Z * (g0 + 22), c + Z * (g0 + gear_h - 20), gear_d),
                   cyl(c + Z * (g0 + gear_h - 20), c + Z * (g0 + gear_h), motor_d + 40)])
    ribs = [obox(c + Z * (g0 + gear_h / 2) + V(math.cos(math.radians(a)), math.sin(math.radians(a)), 0) * (gear_d / 2 + 12),
                 V(math.cos(math.radians(a)), math.sin(math.radians(a)), 0), Z, 26, gear_h - 50, 14) for a in range(0, 360, 45)]
    plug = [cyl(c + Z * (g0 + gear_h * 0.6) + V(1, 0, 0) * (gear_d / 2 - 2), c + Z * (g0 + gear_h * 0.6) + V(1, 0, 0) * (gear_d / 2 + 26), 24)]
    gr.add(fuse_all([gb] + ribs + plug), 'gear')
    gbolts = [hexagon(c + Z * (g0 + 22) + V(math.cos(math.radians(a)), math.sin(math.radians(a)), 0) * (stand_d1 / 2 - 13), Z, 24, 13) for a in range(22, 360, 45)]
    gr.add(gbolts, 'bolt', 'болты фланца')
    P.append(gr)
    # --- мотор
    mo = Part(f'{pre}электродвигатель {kw} кВт, исполнение Ex d IIB T4, IM V1', 'motor')
    m0 = g0 + gear_h
    fl_m = cyl(c + Z * m0, c + Z * (m0 + 24), motor_d + 40)
    frame = cyl(c + Z * (m0 + 24), c + Z * (m0 + motor_h - 140), motor_d - 40)
    fins = []
    nf = 24
    for k in range(nf):
        a = math.radians(360 * k / nf + 7.5)
        u = V(math.cos(a), math.sin(a), 0)
        if abs(math.degrees(a) % 360 - 90) < 42:
            continue
        fins.append(obox(c + Z * (m0 + 24 + (motor_h - 164) / 2) + u * (motor_d / 2 - 20 + 9), u, Z, 22, motor_h - 164, 6))
    endb = cyl(c + Z * (m0 + motor_h - 140), c + Z * (m0 + motor_h - 120), motor_d)
    body_m = fuse_all([fl_m, frame, endb] + fins)
    fc = revolve_profile([(0, 0), (motor_d / 2 - 2, 0), (motor_d / 2 - 2, 100), (motor_d / 2 - 30, 120), (0, 120)], c + Z * (m0 + motor_h - 120), Z)
    fc = fc.cut(cyl(c + Z * (m0 + motor_h - 20) + X * 120, c + Z * (m0 + motor_h + 1) + X * 120, 17))
    grill = []
    for k in range(4):
        r0 = 40 + 32 * k
        grill.append(tube(c + Z * (m0 + motor_h - 0.0), c + Z * (m0 + motor_h + 3), 2 * r0 + 12, 2 * r0))
    mo.add(fc, 'motor', 'кожух вентилятора')
    mo.add(grill, 'black', 'решётка кожуха')
    tb_c = c + Z * (m0 + motor_h * 0.45) + V(0, 1, 0) * (motor_d / 2 - 20 + 0)
    tbox = obox(tb_c + V(0, 1, 0) * 80, Y, X, 160, 200, 180)
    tlid = obox(tb_c + V(0, 1, 0) * 166, Y, X, 12, 210, 190)
    glands = [fuse_all([cyl(tb_c + Y * 80 + X * 100 + Z * dz, tb_c + Y * 80 + X * 128 + Z * dz, 32), hexagon(tb_c + Y * 80 + X * 128 + Z * dz, X, 36, 14)]) for dz in (-40, 40)]
    mo.add(fuse_all([body_m, tbox, tlid]), 'motor', 'корпус с клеммной коробкой Ex d')
    mo.add(glands, 'ss_dark', 'кабельные вводы Ex d')
    mo.add(cyl(tb_c + Y * 80 + X * 142 + Z * -40, tb_c + Y * 80 + X * 300 + Z * -40, 26), 'cable', 'кабель питания')
    eye = fuse_all([torus(c + Z * (m0 + motor_h + 3 + 30) + X * 120, Y, 22, 7), cyl(c + Z * (m0 + motor_h - 20) + X * 120, c + Z * (m0 + motor_h + 3 + 9) + X * 120, 16)])
    mo.add(eye, 'ss_dark', 'рым-болт')
    mo.add(obox(c + Z * (m0 + motor_h * 0.6) + V(-1, 0, 0) * (motor_d / 2 - 20 + 22 + 1), X, Y, 2, 120, 80), 'nameplate', 'табличка')
    P.append(mo)
    top = m0 + motor_h + 3
    # --- бачок затворной жидкости на кронштейне к стойке
    if seal:
        pt = Part(f'{pre}бачок затворной жидкости 5 л (термосифон): смотровое стекло уровня, манометр, заливная пробка, кронштейн', 'seal_pot')
        R0 = stand_d0 / 2
        z_pot = z0 + (300 if seal_hoses else 120)
        pc = c + pu * (R0 + 230) + Z * z_pot
        hb, Dp = 300, 160
        ves = revolve_profile([(0, 0)] + [(Dp / 2 * math.sin(math.radians(t)), 30 * (1 - math.cos(math.radians(t)))) for t in range(10, 91, 10)] +
                              [(Dp / 2, hb - 30)] + [(Dp / 2 * math.cos(math.radians(t)), hb - 30 + 30 * math.sin(math.radians(t))) for t in range(10, 91, 10)], pc, Z)
        pt.add(ves, 'ss', 'корпус бачка')
        # кронштейн: две полосы от стойки к бачку
        brk = []
        for dz in (110, 200):
            a0 = c + pu * (R0 - 26) + Z * (z_pot + dz)
            a1 = pc + Z * dz - pu * (Dp / 2)
            L = (a1 - a0).Length
            brk.append(obox((a0 + a1) * 0.5, pu, pv, L, 8, 40))
            brk.append(tube(pc + Z * (dz - 15), pc + Z * (dz + 15), Dp + 12, Dp))
        pt.add(fuse_all(brk), 'ss_dark', 'кронштейн и хомуты бачка')
        # смотровое стекло уровня (сбоку), манометр и пробка сверху
        sgx = pc + pv * (Dp / 2)
        lg = fuse_all([cyl(sgx + Z * 70, sgx + Z * 70 + pv * 30, 22), cyl(sgx + Z * 230, sgx + Z * 230 + pv * 30, 22),
                       obox(sgx + pv * 38 + Z * 150, pv, Z, 16, 30, 200)])
        pt.add(lg, 'ss_dark', 'указатель уровня')
        pt.add(obox(sgx + pv * 46.65 + Z * 150, pv, Z, 1.2, 14, 150), 'glass', 'стекло указателя')
        pg = pc + Z * hb
        stub = cyl(pg + pu * 30, pg + pu * 30 + Z * 40, 18)
        gcase = cyl(pg + pu * 30 + Z * 40 + Z * 32 - pv * 15, pg + pu * 30 + Z * 40 + Z * 32 + pv * 15, 63)
        pt.add(fuse_all([stub, gcase]), 'ss', 'манометр бачка Ø63')
        pt.add(cyl(pg + pu * 30 + Z * 72 + pv * 15, pg + pu * 30 + Z * 72 + pv * 16.5, 56), 'dial', 'циферблат')
        plugc = fuse_all([cyl(pg - pu * 30, pg - pu * 30 + Z * 25, 30), hexagon(pg - pu * 30 + Z * 25, Z, 32, 12)])
        pt.add(plugc, 'ss_dark', 'заливная пробка')
        P.append(pt)
        if seal_hoses:
            from .core import Port
            from . import tara as _ta
            nip = []
            for k, (dz, zz, what) in enumerate(((60, z_pot + 60, 'подача: низ бачка → нижний штуцер уплотнения'),
                                                (120, z_pot + hb - 70, 'возврат: верхний штуцер уплотнения → верх бачка'))):
                off = 40 if k else -40
                q0 = c + Z * (z0 + 24 + dz) + pu * math.sqrt(115 ** 2 - 40 ** 2) + pv * off
                pa = Port('a', q0 + pu * 32, pu, Z, 10, 'hose')
                xe = math.sqrt((Dp / 2) ** 2 - off ** 2)
                s0 = pc + Z * (zz - z_pot) + pv * off - pu * (xe - 2)
                nip.append(fuse_all([cyl(s0, s0 - pu * 32, 18), hexagon(s0 - pu * 22, -pu, 22, 10)]))
                pb = Port('b', s0 - pu * 32, -pu, Z, 10, 'hose')
                via = [q0 + pu * (R0 + 60 - math.sqrt(115 ** 2 - 40 ** 2))]
                h = _ta.rukav(pa, pb, name=f'{pre}рукав затворной жидкости DN10 — металлорукав в оплётке AISI 321/304 ({what})', vid='metall', dn=10, od=20.0,
                              via=via, k=40.0, R=40.0)
                h.kind = 'hose'
                h.ports = {}                       # рукав — в комплекте поставки уплотнения (концы на штуцерах бачка и уплотнения)
                P.append(h)
            pt.bodies[0] = (fuse_all([pt.bodies[0][0]] + nip), 'ss', 'корпус бачка со штуцерами')
        # трубки подвода/отвода: от штуцеров уплотнения горизонтально к бачку, затем в бачок
        nip = []
        tb = Part(f'{pre}трубки затворной жидкости 12×1,5 AISI 316 (бачок ↔ уплотнение)', 'tubing')
        tubes = []
        for k, dz in enumerate((60, 120)):
            off = 40 if k else -40
            q0 = c + Z * (z0 + 24 + dz) + pu * (math.sqrt(115 ** 2 - 40 ** 2) + 32) + pv * off
            zz = z0 + 120 + (150 if k == 0 else hb - 70)
            xin = math.sqrt((Dp / 2) ** 2 - off ** 2)
            qb = c + pu * (R0 + 230 - xin - 40) + Z * q0.z + pv * off
            qc = V(qb.x, qb.y, zz)
            xe = math.sqrt((Dp / 2) ** 2 - (abs(off) - 6) ** 2) + 0.2
            qd = c + pu * (R0 + 230 - xe) + Z * zz + pv * off
            nip.append(cyl(c + pu * (R0 + 230 - xe + 0.2 + 14) + Z * zz + pv * off, c + pu * (R0 + 230 - xe + 0.2) + Z * zz + pv * off, 16))
            seg = [cyl(q0, qb, 12), sph(qb, 12)]
            if abs(zz - q0.z) > 1:
                seg += [cyl(qb, qc, 12), sph(qc, 12)]
            seg.append(cyl(qc, qd, 12))
            tubes += seg
        if not seal_hoses:
            tb.add(fuse_all([t for t in tubes if t is not None]), 'ss_dark')
            pt.bodies[0] = (fuse_all([pt.bodies[0][0]] + nip), 'ss', 'корпус бачка со штуцерами')
            P.append(tb)
    for q in P:
        q.anchor('top', c + Z * top)
    return P, top


# ------------------------------------------------------------------ опоры аппаратов
def vessel_lug(c_axis, R_shell, ang_deg, z_base, H=300, Lb=250, B=220, t=16, name=None, bolt='M24'):
    """Лапа опорная (NB/T 47065.3 тип A): накладка на корпус (по радиусу), две косынки, опорная плита на z_base,
    анкерный болт с гайкой и шайбой. ang_deg — азимут (0 — север +Y, по часовой)."""
    a = math.radians(ang_deg)
    u = V(math.sin(a), math.cos(a), 0)
    v = Z.cross(u)
    c0 = V(c_axis[0], c_axis[1], 0)
    p = Part(name or f'лапа опорная тип A (NB/T 47065.3): накладка, 2 косынки, плита {Lb}×{B}×20, анкер {bolt}', 'lug')
    pad_t = 8
    pad = revolve_profile([(R_shell, z_base + 20), (R_shell + pad_t, z_base + 20), (R_shell + pad_t, z_base + H + 40), (R_shell, z_base + H + 40)], c0, Z,
                          ref=u, angle=360)
    sector = obox(c0 + u * (R_shell + 60) + Z * (z_base + H / 2), u, v, 200, B + 40, 2000)
    pad = pad.intersect(sector)
    r0 = R_shell + pad_t
    r1 = R_shell + Lb
    gus = []
    for sg in (-1, 1):
        o = c0 + v * sg * (B / 2 - 30) + v * (t / 2)
        pts = [(r0, z_base + 20), (r1, z_base + 20), (r1, z_base + 50), (r0 + 40, z_base + H), (r0, z_base + H)]
        gus.append(extrude_poly(pts, o, u, -v, t))          # плоскость (u, Z), толщина — вдоль −v
    plate = obox(c0 + u * ((r0 + r1) / 2) + Z * (z_base + 10), u, v, r1 - r0, B, 20)
    hole = c0 + u * (r1 - 60) + Z * z_base
    plate = plate.cut(cyl(hole - Z * 5, hole + Z * 40, 30))
    top = obox(c0 + u * (r0 + 30) + Z * (z_base + H - 6), u, v, 60, B - 60 + t, 12)
    p.add(fuse_all([pad, plate, top] + gus), 'ss_dark', 'лапа')
    d = {'M20': (20, 30, 18), 'M24': (24, 36, 21.5), 'M30': (30, 46, 25.6)}[bolt]
    ab = fuse_all([cyl(hole, hole + Z * (20 + 4 + d[2] + 10), d[0]), cyl(hole + Z * 20, hole + Z * 24, d[1] + 10), hexagon(hole + Z * 24, Z, d[1], d[2])])
    p.add(ab, 'bolt', 'болт крепления с шайбой и гайкой')
    p.anchor('base', hole)
    return p


def saddle(c_axis_pt, axis, D_shell, base_z, width=200, foot=550, name=None, n_ribs=3):
    """Седловая опора горизонтального аппарата: ложемент 120° по корпусу (касание), стенка, рёбра, опорная плита на base_z."""
    c = vec(c_axis_pt)
    ax0 = unit(axis)
    ax = (ax0 - Z * ax0.dot(Z)).normalized()          # стенка, рёбра и плита — вертикальны/горизонтальны и при уклоне аппарата
    side = Z.cross(ax).normalized() if abs(ax.dot(Z)) < 0.9 else X
    R = D_shell / 2
    t = 10.0
    sec = tube(c - ax0 * (width / 2), c + ax0 * (width / 2), D_shell + 2 * t, D_shell)
    sec = sec.cut(box(-1e5, -1e5, c.z - R * math.cos(math.radians(60)), 1e5, 1e5, 1e5))
    hz = c.z - R * math.cos(math.radians(60)) - (base_z + 16)
    web = obox(V(c.x, c.y, base_z + 16 + hz / 2) + ax * 0, side, Z, foot - 40, hz, 12)
    web = web.cut(cyl(c - ax0 * width, c + ax0 * width, D_shell))
    ribs = []
    for k in range(n_ribs):
        s = -foot / 2 + 70 + k * (foot - 140) / max(1, n_ribs - 1)
        rb = obox(V(c.x, c.y, base_z + 16 + hz / 2) + side * s, ax, Z, width - 20, hz, 10).cut(cyl(c - ax0 * width, c + ax0 * width, D_shell))
        ribs.append(rb)
    base = obox(V(c.x, c.y, base_z + 8), side, ax, foot, width, 16)
    holes = []
    for sg in (-1, 1):
      for sa in (-1, 1):
        q = V(c.x, c.y, base_z) + side * sg * (foot / 2 - 32) + ax * sa * (width / 2 - 35)
        base = base.cut(cyl(q - Z, q + Z * 20, 26))
        holes.append(fuse_all([cyl(q - Z * 0, q + Z * (16 + 18 + 12), 20), hexagon(q + Z * 16, Z, 30, 18)]))
    p = Part(name or f'опора седловая {foot}×{width}: ложемент 120°, стенка, {n_ribs} ребра, плита с анкерами M20', 'saddle')
    p.add(fuse_all([sec, web, base] + ribs), 'ss_dark', 'седло')
    p.add(holes, 'bolt', 'анкерные болты')
    return p


# ------------------------------------------------------------------ донный клапан (выдвижной вверх)
def bottom_valve_f41(dn=100, pn='PN25', name=None, tag=''):
    """Клапан донный F41W-25RL DN100 PN25, корпус CF3M (по чертежу поставщика): верхний фланец к штуцеру B (D235, 8 отв. Ø22 на Ø190),
    корпус Y-образный, выход 45° с фланцем, сальник со шпильками, бугель, шток, маховик снизу.
    Локально: 'a' — верхний фланец (смотрит в −X, к аппарату), корпус — в +X (вниз), выход 'b' — 45° между +X и +Y."""
    fl = std.flange(dn, pn)
    T = fl['f1'] + fl['C']
    D = fl['D']
    p = Part(name or f'клапан донный F41W-25RL DN{dn} {pn}, корпус CF3M (316L), шток вверх (по чертежу поставщика)' + (f' {tag}' if tag else ''), 'valve', dn)
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (D / 2, fl['f1']), (D / 2, T), (0, T)], (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    rn = nut_clear_r(fl)
    neck = revolve_profile([(0, T), (rn, T), (rn, T + 35), (70, T + 120), (52, T + 170), (0, T + 170)], (0, 0, 0), X, Z)
    # выход 45°: патрубок и фланец
    u = V(math.cos(math.radians(45)), math.sin(math.radians(45)), 0)
    Lb = 300.0                                   # от оси корпуса (точка на оси x0) до плоскости выходного фланца
    x0 = T + 60
    c0 = V(x0, 0, 0)
    br = cyl(c0, c0 + u * (Lb - T - 35), 2 * rn)
    fo = revolve_profile([(rn, 0), (D / 2, 0), (D / 2, fl['C']), (fl['d1'] / 2, fl['C']), (fl['d1'] / 2, T), (rn - 20, T)], c0 + u * (Lb - T), u, Z)
    for k in range(fl['n']):
        a = math.radians((k + 0.5) * 360 / fl['n'])
        w = Z * math.cos(a) + u.cross(Z) * math.sin(a)
        q = c0 + u * (Lb - T) + w * (fl['K'] / 2)
        fo = fo.cut(cyl(q - u * 1, q + u * (T + 1), fl['L']))
    stemh = cyl((T + 170, 0, 0), (T + 330, 0, 0), 76)
    glandf = cyl((T + 330, 0, 0), (T + 350, 0, 0), 150)
    body = fuse_all([plate, neck, br, fo, stemh, glandf])
    body = body.cut(cyl((-1, 0, 0), (T + 160, 0, 0), std.pipe('SS', dn)[0] - 2 * 6)).cut(cyl(c0, c0 + u * (Lb + 1), std.pipe('SS', dn)[0] - 12))
    body = body.cut(cyl((T + 150, 0, 0), (T + 351, 0, 0), 35))
    for s_ in (-1, 1):
        body = body.cut(cyl((T + 329, s_ * 62, 0), (T + 351, s_ * 62, 0), 15))
    p.add(body, 'ss_cast', 'корпус')
    gl = cyl((T + 350, 0, 0), (T + 372, 0, 0), 150).cut(cyl((T + 349, 0, 0), (T + 373, 0, 0), 36))
    for s_ in (-1, 1):
        gl = gl.cut(cyl((T + 349, s_ * 62, 0), (T + 373, s_ * 62, 0), 15))
    studs = [fuse_all([cyl((T + 330 - 4, s * 62, 0), (T + 372 + 16, s * 62, 0), 14), hexagon((T + 372, s * 62, 0), X, 22, 11)]) for s in (-1, 1)]
    p.add(gl, 'ss', 'сальник')
    p.add(studs, 'bolt', 'шпильки сальника')
    # бугель и шток, маховик
    yk = [obox((T + 372 + 70, s * 40, 0), X, Y, 140, 14, 30) for s in (-1, 1)] + [cyl((T + 372 + 140, 0, 0), (T + 372 + 160, 0, 0), 110)]
    p.add(fuse_all(yk).cut(cyl((T + 372 + 139, 0, 0), (T + 372 + 161, 0, 0), 36)), 'ss_cast', 'бугель')
    st = cyl((T + 160, 0, 0), (T + 372 + 200, 0, 0), 34)
    p.add(st, 'ss_dark', 'шток')
    Dw = 250
    p.add(handwheel_(V(T + 372 + 200 + max(6, Dw * 0.045) * 1.6 + 0.2, 0, 0), X, Dw), 'wheel', 'маховик')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', c0 + u * Lb, u, Z, dn, 'flange', fl=fl)
    p.anchor('top', (T + 372 + 220, 0, 0))
    p.anchor('mid', (T + 100, 0, 0))
    return p


def handwheel_(c, axis, Dw):
    from .valves import handwheel
    return handwheel(c, axis, Dw)
