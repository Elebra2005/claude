"""lib3d.k73 — элементы по решению К73 (27.10): загрузка жидкостей через переходник фланец-кламп и гребёнку К63,
гребёнка защиты реактора (как в эталоне ТЕФКОТ, вместо КДЗТ), пост дозирования (весы, бочка 200 л).

Кламп называется по феруле (DIN 32676 / ASME BPE): K25 (Ду20, труба 19,05), K50,5 (Ду25), K63 (= ферула Ø64, Ду50, труба 51),
K91 (Ду65), K119 (Ду100). Соглашения lib3d: мм, Z вверх; 'a' — в начале координат, смотрит в −X; 'b' — в +X; отвод тройника 'c' — +Y.
Кламповые порты kind='clamp', od = Ø ферулы: Run.put сам ставит хомут с прокладкой (зазор 3 мм).

Детали (Part):
  perekhodnik_flanec_klamp(dn, pn, klamp)     — фланец DN → ферула (глухой фланец с патрубком);
  trubka_klamp, troynik_klamp, otvod_klamp, perekhod_klamp, perekhodnik_klamp_rezba, zaglushka_klamp;
  kran_klamp, obratnyy_klapan_klamp, shpunt_apparat, manometr_klamp, rotametr, reduktor_azota;
  vesy(tip='grubye'|'tochnye', ...), bochka_200(...) — dict(parts=..., порты).
Сборки (кладут детали в сцену через Run, связи порт-в-порт):
  grebenka_zagruzki(sc, vhod, vhody, ...)     — коллектор K63 «тройник-тройник-тройник», кран под каждым тройником, входы K25;
  grebenka_zashchity(sc, vhod, ...)           — коллектор K25 на тройниках, кран перед каждой веткой: шпунт-аппарат, обратный клапан
                                                аварийного сброса, мановакуумметр, ввод азота (редуктор + ротаметр с вентилем),
                                                сброс на атмосферу; выходы шпунта и обратного клапана сведены в один порт 'vyhod'.
Все тела валидны (BRepCheck), без взаимных проникновений (касания) — см. GOTOVO_K73_27-10.md, самопроверка: python3 -m lib3d.k73.
"""
import math
import cadquery as cq
from cadquery import Vector as V
from .core import Part, Xf, cyl, tube, box, cbox, obox, hexagon, fuse_all, revolve_profile, unit, vec, perp_ref
from .piping import Run, elbow_solid
from .valves import _ferrule_prof, lever, clamp_cap
from . import std, export

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)
export.PALETTE.setdefault('drum', (0.16, 0.33, 0.62))          # бочка стальная окрашенная
export.PALETTE.setdefault('scale_deck', (0.70, 0.72, 0.74))    # настил весов (нерж. рифлёный)

# имя клампа → (Ø ферулы, Ø трубы, стенка, DN)
# Бабкин называет клампы по Ø ферулы (ТЕФКОТ: «коллектор ½″ (кламп 25)», Ду25 — «кламп 50,5»): К25 — ферула Ø25 (½″), К63 — ферула Ø64 (Ду50)
KLAMP = {'K25': (25.0, 19.05, 1.65, 20), 'K50,5': (50.5, 33.7, 1.65, 25), 'K63': (64.0, 51.0, 1.5, 50), 'K64': (64.0, 51.0, 1.5, 50),
         'K91': (91.0, 70.0, 2.0, 65), 'K119': (119.0, 104.0, 2.0, 100),
         'KF50': (75.0, 52.0, 1.5, 50), 'KF40': (55.0, 41.0, 1.5, 40)}      # ISO-KF (вакуум): фланец KF50 Ø75, хомут KF с центрирующим кольцом
FL = 21.5   # длина ферулы

# 03.11 (Мареев): каталожные позиции, из которых собираются кламповые узлы (размеры — по карточкам поставщиков)
KATALOG = {
    'zatvor': 'кран-бабочка (затвор дисковый) под кламп, AISI 304, рукоятка с фиксатором (откр./45°/закр.); типоразмеры 1½″, 2″, 3″ — арт. 101938 (2″)',
    'shpunt': 'шпунт-аппарат угловой с манометром, кламп 50,5 (1½″), 0,2…2,2 бар (гильза со шкалой), манометр 0…4 бар на мембранном разделителе, AISI 304, EPDM/FPM',
    'kran_kf': 'кран трёхсоставной KF под вакуум (шар, седло PTFE, до 10⁻⁹ мбар, −20…+150 °C), AISI 304/316L; KF16…KF50',
    'troynik': 'тройник кламп равнопроходный DIN 32676 (DN10…DN200, Ra ≤ 0,8), AISI 316L',
    'otvod': 'отвод кламп 90° DIN 32676 (DN10…DN200, Ra ≤ 0,8), AISI 304/316L',
}
ZATVOR_DYUYM = {'K50,5': '1½″', 'K63': '2″', 'K91': '3″'}


def kl(k):
    """Параметры клампа: (Df, od, wall, dn). k — 'K25' | 'K50,5' | 'K63' | … (кириллическая К тоже)."""
    k = k.replace('К', 'K').replace('.', ',')
    return KLAMP[k]


def _kn(k):
    return k.replace('K', 'К')


def _fa(od, Df):
    """Ферула: плоскость в x=0 (порт смотрит в −X), под сварку — x=21,5."""
    return revolve_profile(_ferrule_prof(od, Df, FL, FL, -1), (0, 0, 0), X, Z)


def _fb(od, Df, L, origin=(0, 0, 0), axis=X):
    """Ферула: плоскость в L вдоль axis от origin (порт смотрит по axis)."""
    return revolve_profile(_ferrule_prof(od, Df, FL, L - FL, 1), origin, axis, Z if abs(unit(axis).dot(Z)) < 0.9 else X)


def _cports(p, k, L, dn=None):
    Df, od, w, d = kl(k)
    p.port('a', (0, 0, 0), -X, Z, dn or d, 'clamp', od=Df)
    p.port('b', (L, 0, 0), X, Z, dn or d, 'clamp', od=Df)


# ------------------------------------------------------------------ переходник фланец → кламп
def perekhodnik_flanec_klamp(dn, pn='PN16', klamp='K63', name=None, neck_L=None, mat='SS'):
    """Переходник фланец-кламп: тарелка фланца DN pn (EN 1092-1, отверстия под шпильки) с патрубком и ферулой klamp.
    'a' — плоскость фланца (−X, kind flange, ставится на штуцер через Run.add — шпильки и прокладка автоматически),
    'b' — ферула (+X, kind clamp). Подходит и для «меньший фланец → больший кламп» (Ду25 → K63)."""
    from .piping import bolt_holes
    Df, od, w, dk = kl(klamp)
    fl = std.flange(dn, pn)
    T = fl['C'] + fl['f1']
    neck_L = neck_L if neck_L is not None else 40.0
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (fl['D'] / 2, fl['f1']), (fl['D'] / 2, T), (0, T)], (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    hub = revolve_profile([(od / 2 - 1.5, T), (od / 2 + 8, T), (od / 2, T + 8), (od / 2 - 1.5, T + 8)], (0, 0, 0), X, Z)
    nk = tube((T + 8, 0, 0), (T + neck_L, 0, 0), od, od - 3)
    L = T + neck_L + FL
    fe = _fb(od, Df, L)
    bore = min(od - 3, std.pipe('SS', dn)[0] - 2 * std.pipe('SS', dn)[1]) if dn in std.PIPE['SS'] else od - 3
    s = fuse_all([plate, hub, nk, fe]).cut(cyl((-1, 0, 0), (T + 9, 0, 0), bore)).cut(cyl((T, 0, 0), (L + 1, 0, 0), od - 3))
    p = Part(name or f'переходник фланец-кламп DN{dn} {pn} → {_kn(klamp)} (AISI 316L)', 'flange', dn, material=mat)
    p.add(s, 'ss')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (L, 0, 0), X, Z, dk, 'clamp', od=Df)
    p.anchor('top', (L, 0, 0))
    p.meta['L'] = L
    return p


def zaglushka_klamp(klamp='K63', name=None):
    """Заглушка кламповая с ручкой (порт 'a', kind clamp)."""
    Df, od, w, dn = kl(klamp)
    return clamp_cap(dn, Df, od=od, name=name or f'заглушка кламповая {_kn(klamp)} с ручкой (AISI 316L)')


# ------------------------------------------------------------------ трубная мелочь на клампах
def trubka_klamp(klamp, L, name=None, color='ss'):
    """Патрубок с ферулами на обоих концах, L — между плоскостями ферул (≥ 44)."""
    Df, od, w, dn = kl(klamp)
    if L < 2 * FL + 1:
        raise ValueError(f'патрубок {klamp}: L={L:.1f} < {2 * FL + 1}')
    s = fuse_all([_fa(od, Df), tube((FL, 0, 0), (L - FL, 0, 0), od, od - 3), _fb(od, Df, L)])
    p = Part(name or f'патрубок {_kn(klamp)} {od:g}×{w:g} AISI 316L с ферулами, L={L:.0f}', 'pipe', dn, material='SS')
    p.add(s, color)
    _cports(p, klamp, L)
    p.meta.update(L=L, od=od)
    return p


def troynik_C(klamp):
    Df, od, w, dn = kl(klamp)
    return round(Df / 2 + FL + 25.0, 1)


def troynik_klamp(klamp, name=None, color='ss'):
    """Тройник кламповый равнопроходный: прогон a(−X)…b(+X), отвод c (+Y); от центра до плоскостей — C = troynik_C(klamp)."""
    Df, od, w, dn = kl(klamp)
    C = troynik_C(klamp)
    ob = od * 0.996                                     # отвод чуть тоньше прогона: валидный B-Rep после STEP
    run = fuse_all([_fa(od, Df), tube((FL, 0, 0), (2 * C - FL, 0, 0), od, 0), _fb(od, Df, 2 * C)])
    br = fuse_all([cyl((C, 0, 0), (C, C - FL, 0), ob), revolve_profile(_ferrule_prof(od, Df, FL, C - FL, 1), (C, 0, 0), Y, Z)])
    s = run.fuse(br).cut(cyl((-1, 0, 0), (2 * C + 1, 0, 0), od - 3)).cut(cyl((C, 0, 0), (C, C + 1, 0), ob - 3))
    p = Part(name or f'тройник кламп равнопроходный {_kn(klamp)} ({od:g}×{w:g}, кламп Ø{Df:g}) DIN 32676, AISI 316L — каталог', 'tee', dn, material='SS')
    p.add(s, color)
    _cports(p, klamp, 2 * C)
    p.port('c', (C, C, 0), Y, Z, dn, 'clamp', od=Df)
    p.meta.update(C=C, M=C)
    return p


def otvod_klamp(klamp, ang=90.0, R=None, name=None, color='ss'):
    """Отвод кламповый ang° (по умолчанию 90°): 'a' (−X), 'b' — в плоскости XY, поворот к +Y."""
    Df, od, w, dn = kl(klamp)
    R = R or round(1.5 * od + 10)
    a = math.radians(ang)
    arc = elbow_solid(od, od - 3, R, ang).translate(V(FL, 0, 0))
    E = V(FL + R * math.sin(a), R * (1 - math.cos(a)), 0)
    d = V(math.cos(a), math.sin(a), 0)
    fb = revolve_profile(_ferrule_prof(od, Df, FL, 0, 1), E, d, Z)
    s = fuse_all([_fa(od, Df), arc, fb])
    p = Part(name or f'отвод кламп {ang:.0f}° {_kn(klamp)} ({od:g}×{w:g}, кламп Ø{Df:g}) DIN 32676, AISI 316L — каталог', 'elbow', dn, material='SS')
    p.add(s, color)
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.port('b', E + d * FL, d, Z, dn, 'clamp', od=Df)
    p.meta.update(R=R, ang=ang)
    return p


def perekhod_klamp(k1, k2, name=None, color='ss'):
    """Переход кламповый концентрический k1 ('a') → k2 ('b')."""
    D1, o1, w1, d1 = kl(k1)
    D2, o2, w2, d2 = kl(k2)
    Lc = max(30.0, 1.2 * abs(o1 - o2))
    L = 2 * FL + Lc
    cone_ = revolve_profile([(o1 / 2 - 1.5, FL), (o1 / 2, FL), (o2 / 2, FL + Lc), (o2 / 2 - 1.5, FL + Lc)], (0, 0, 0), X, Z)
    s = fuse_all([_fa(o1, D1), cone_, _fb(o2, D2, L)])
    p = Part(name or f'переход кламповый концентрический {_kn(k1)} → {_kn(k2)} AISI 316L', 'reducer', d1, material='SS')
    p.add(s, color)
    p.port('a', (0, 0, 0), -X, Z, d1, 'clamp', od=D1)
    p.port('b', (L, 0, 0), X, Z, d2, 'clamp', od=D2)
    p.meta['L'] = L
    return p


def perekhodnik_klamp_rezba(klamp='K25', rezba='G1/2', name=None, color='ss'):
    """Переходник кламп → наружная резьба G1/2 (для азота, КИП): 'a' — ферула, 'b' — резьба (kind thread, DN15, Ø21,3)."""
    Df, od, w, dn = kl(klamp)
    L = FL + 30.0
    s = fuse_all([_fa(od, Df), cyl((FL, 0, 0), (FL + 14, 0, 0), od), hexagon((FL + 14, 0, 0), X, 27, 12), cyl((FL + 26, 0, 0), (L, 0, 0), 21.3)])
    s = s.cut(cyl((-1, 0, 0), (L + 1, 0, 0), 12.0))
    p = Part(name or f'переходник {_kn(klamp)} → {rezba} (AISI 316L)', 'reducer', dn, material='SS')
    p.add(s, color)
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.port('b', (L, 0, 0), X, Z, 15, 'thread', od=21.3)
    return p


# ------------------------------------------------------------------ арматура на клампах
def kran_klamp(klamp='K25', name=None, lever_dir=X, tag=''):
    """Кран шаровой санитарный с клампами (трёхсоставной, AISI 316L/PTFE, рукоятка). Шток — в +Z."""
    Df, od, w, dn = kl(klamp)
    L = round(max(90.0, 1.6 * Df + 50))
    br = Df / 2 + 8
    body = revolve_profile([(od / 2 - 1.5, FL), (od / 2, FL), (br, FL + 10), (br, L - FL - 10), (od / 2, L - FL), (od / 2 - 1.5, L - FL)], (0, 0, 0), X, Z)
    nd = max(18.0, 0.45 * Df)
    neck = cyl((L / 2, 0, br - 6), (L / 2, 0, br + 14), nd)
    pad = cbox((L / 2, 0, br + 18), nd + 10, nd + 10, 8)
    p = Part(name or f'кран шаровой санитарный {_kn(klamp)} с клампами, AISI 316L/PTFE, рукоятка' + (f' {tag}' if tag else ''), 'valve', dn)
    p.add(fuse_all([_fa(od, Df), body, _fb(od, Df, L), neck, pad]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), od - 3)), 'ss_cast', 'корпус')
    sd = max(8.0, 0.2 * Df)
    st = cyl((L / 2, 0, br + 22), (L / 2, 0, br + 36), sd)
    stl, gr = lever(V(L / 2, 0, br + 36), sd, round(2.4 * Df + 60), along=unit(vec(lever_dir)))
    p.add(fuse_all([st, stl]), 'ss_dark', 'рукоятка')
    p.add(gr, 'lever', 'накладка рукоятки')
    _cports(p, klamp, L)
    p.anchor('top', (L / 2, 0, br + 50))
    p.meta['L'] = L
    return p


def zatvor_klamp(klamp='K63', name=None, lever_dir=X, tag=''):
    """Кран-бабочка (затвор дисковый) под кламп (03.11, каталог: 1½″ / 2″ / 3″ — К50,5 / К63 / К91), AISI 304, уплотнение диска
    силикон/EPDM; рукоятка с подпружиненным фиксатором (открыто / 45° / закрыто). Шток — в +Z, рукоятка — вдоль lever_dir."""
    Df, od, w, dn = kl(klamp)
    L = round(2 * FL + max(22.0, 0.28 * Df))          # строительная длина между плоскостями ферул (≈ 65…70 мм)
    R = Df / 2 + 10
    xc = L / 2
    body = revolve_profile([(od / 2 - 1.5, FL), (od / 2, FL), (R, xc - 11), (R, xc + 11), (od / 2, L - FL), (od / 2 - 1.5, L - FL)], (0, 0, 0), X, Z)
    nd = max(16.0, 0.32 * Df)
    neck = cyl((xc, 0, R - 4), (xc, 0, R + 16), nd)
    pad = cbox((xc, 0, R + 20), nd + 12, nd + 12, 8)
    disc = cyl((xc - 1.5, 0, 0), (xc + 1.5, 0, 0), od - 4)
    dz = f'{ZATVOR_DYUYM.get(klamp, _kn(klamp))}'
    p = Part(name or f'кран-бабочка (затвор дисковый) под кламп {dz} ({_kn(klamp)}), AISI 304, рукоятка с фиксатором — каталог' + (f' {tag}' if tag else ''), 'valve', dn)
    p.add(fuse_all([_fa(od, Df), body, _fb(od, Df, L), neck, pad]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), od - 3)).fuse(disc), 'ss_cast', 'корпус с диском')
    sd = max(8.0, 0.18 * Df)
    st = cyl((xc, 0, R + 24), (xc, 0, R + 40), sd)
    stl, gr = lever(V(xc, 0, R + 40), sd, round(1.8 * Df + 100), along=unit(vec(lever_dir)))
    p.add(fuse_all([st, stl]), 'ss_dark', 'рукоятка с фиксатором')
    p.add(gr, 'lever', 'шаровой упор рукоятки')
    _cports(p, klamp, L)
    p.anchor('top', (xc, 0, R + 54))
    p.meta['L'] = L
    return p


def kran_kf(kf='KF50', name=None, lever_dir=X, tag=''):
    """Кран трёхсоставной KF под вакуум (03.11, каталог): шар AISI 304, седло PTFE, до 10⁻⁹ мбар, −20…+150 °C; фланцы ISO-KF
    (KF50 — Ø75, DN50; KF40 — Ø55). Порты kind 'clamp' с od = Ø фланца KF: хомут KF с центрирующим кольцом ставится как кламповый."""
    p = kran_klamp(kf, name=name or f'кран трёхсоставной {kf} под вакуум (ISO-KF; шар AISI 304, седло PTFE, до 10⁻⁹ мбар) — каталог' + (f' {tag}' if tag else ''),
                   lever_dir=lever_dir)
    return p


def perekhodnik_kf_klamp(klamp='K63', kf='KF50', name=None, color='ss'):
    """Переходник кламп (DIN 32676) → фланец ISO-KF: 'a' — ферула klamp, 'b' — фланец KF."""
    return perekhod_klamp(klamp, kf, name=name or f'переходник кламп {_kn(klamp)} → {kf} (ISO-KF), AISI 304', color=color)


def obratnyy_klapan_klamp(klamp='K25', name=None, tag=''):
    """Клапан обратный пружинный с клампами (AISI 316L, уплотнение PTFE); поток a → b."""
    Df, od, w, dn = kl(klamp)
    L = round(1.8 * Df + 60)
    R = Df / 2 + 8
    body = revolve_profile([(od / 2 - 1.5, FL), (od / 2, FL), (R, FL + 12), (R, L - FL - 12), (od / 2, L - FL), (od / 2 - 1.5, L - FL)], (0, 0, 0), X, Z)
    ring = cyl((L / 2 - 6, 0, 0), (L / 2 + 6, 0, 0), 2 * R + 8)
    p = Part(name or f'клапан обратный пружинный {_kn(klamp)} с клампами (AISI 316L / PTFE), поток →' + (f' {tag}' if tag else ''), 'valve', dn)
    p.add(fuse_all([_fa(od, Df), body, ring, _fb(od, Df, L)]).cut(cyl((-1, 0, 0), (L + 1, 0, 0), od - 3)), 'ss_cast', 'корпус')
    # стрелка направления на корпусе (касание по образующей сверху)
    p.add(obox((L / 2 + 19, 0, R + 1), X, Y, 22, 6, 2).fuse(cq.Solid.makeCone(6, 0.5, 10, V(L / 2 + 30, 0, R + 6.05), X)), 'black', 'стрелка «поток»')
    _cports(p, klamp, L)
    p.anchor('top', (L / 2, 0, R + 20))
    p.meta['L'] = L
    return p


def _manometr_tela(D=63.0):
    """Корпус показывающего прибора в локальной системе: ось циферблата +Z, задняя плоскость корпуса z=0, центр (0,0).
    → [(тело, цвет, подпись)]: корпус, байонет, циферблат, стекло, стрелка (касания, без проникновений)."""
    R = D / 2
    h = max(22.0, 0.3 * D)
    case = cyl((0, 0, 0), (0, 0, h), D)
    bez = revolve_profile([(R - 3, h), (R + 2, h), (R + 2, h + 5), (R - 3, h + 5)], (0, 0, 0), Z, X)
    dial = cyl((0, 0, h), (0, 0, h + 1.5), D - 8)
    glass = cyl((0, 0, h + 3), (0, 0, h + 4.5), D - 6)
    nd = obox((R * 0.2, R * 0.1, h + 2.0), V(math.cos(0.5), math.sin(0.5), 0), Z, R * 0.6, 0.8, 1.2)
    return [(case, 'ss', 'корпус прибора'), (bez, 'ss_dark', 'байонетное кольцо'), (dial, 'dial', 'циферблат'),
            (glass, 'glass', 'стекло'), (nd, 'black', 'стрелка')]


def _place_tela(tela, origin, normal, ref):
    x = Xf.basis([X, Y, Z], [unit(ref), unit(normal).cross(unit(ref)), unit(normal)], V(0, 0, 0), vec(origin))
    return [(x.shape(s), c, sub) for s, c, sub in tela]


def shpunt_apparat(klamp='K25', name=None, tag='', storona=1):
    """Шпунт-аппарат (регулятор-ограничитель давления с манометром, «гидрозатвор» по К73): вход 'a' снизу (−X, кламп), корпус Ø70
    вдоль +X, винт настройки с Т-рукояткой на торце, выход 'b' вбок (+Y, кламп), манометр Ø63 — на стороне storona·Z.
    Уставка — ниже давления срабатывания разрывной мембраны, уточнить."""
    Df, od, w, dn = kl(klamp)
    xb, Lb, Rb = FL + 14, 110.0, 35.0
    xo = xb + 50.0                                  # ось выхода
    yo = Rb + 60.0                                  # плоскость ферулы выхода
    body = revolve_profile([(od / 2 - 1.5, FL), (od / 2, FL), (od / 2, xb), (Rb, xb + 8), (Rb, xb + Lb - 8), (26, xb + Lb), (od / 2 - 1.5, xb + Lb)],
                           (0, 0, 0), X, Z)
    bon = cyl((xb + Lb, 0, 0), (xb + Lb + 28, 0, 0), 46)
    stub = cyl((xo, 0, 0), (xo, yo - FL, 0), od)
    fo = revolve_profile(_ferrule_prof(od, Df, FL, yo - FL, 1), (xo, 0, 0), Y, Z)
    s_ = storona
    stem = cyl((xo, 0, s_ * (Rb - 4)), (xo, 0, s_ * (Rb + 18)), 14)
    main = fuse_all([_fa(od, Df), body, bon, stub, fo, stem]).cut(cyl((-1, 0, 0), (xb + 30, 0, 0), od - 3)).cut(cyl((xo, 0, 0), (xo, yo + 1, 0), od - 3))
    p = Part(name or f'шпунт-аппарат угловой с манометром {_kn(klamp)} (0,2…2,2 бар, гильза со шкалой; манометр 0…4 бар на разделителе), AISI 304, EPDM — каталог' + (f' {tag}' if tag else ''),
             'valve', dn)
    p.add(main, 'ss_cast', 'корпус с выходом и штуцером манометра')
    x1 = xb + Lb + 28
    p.add(fuse_all([cyl((x1, 0, 0), (x1 + 30, 0, 0), 12), cyl((x1 + 30, 0, 0), (x1 + 42, 0, 0), 22), cyl((x1 + 36, -35, 0), (x1 + 36, 35, 0), 10)]),
          'ss_dark', 'винт настройки с Т-рукояткой')
    for s, c, sub in _place_tela(_manometr_tela(63.0), (xo, 0, s_ * (Rb + 18)), Z * s_, X):
        p.add(s, c, 'манометр: ' + sub)
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.port('b', (xo, yo, 0), Y, Z, dn, 'clamp', od=Df)
    p.anchor('top', (x1 + 45, 0, 0))
    p.meta.update(xo=xo, yo=yo)
    return p


def manometr_klamp(klamp='K25', name=None, tag='PI', rng='−0,1…0,15 МПа', D=100.0):
    """Мановакуумметр на мембранном разделителе с клампом: 'a' — ферула (−X); разделитель и штуцер вдоль +X, корпус над штуцером,
    циферблат смотрит в +Y (при Run.add(..., up=лицо, local_up=Y) — на оператора)."""
    Df, od, w, dn = kl(klamp)
    sep = fuse_all([_fa(od, Df), cyl((FL, 0, 0), (FL + 22, 0, 0), Df + 20), cyl((FL + 22, 0, 0), (FL + 36, 0, 0), 36),
                    hexagon((FL + 36, 0, 0), X, 22, 12), cyl((FL + 48, 0, 0), (FL + 60, 0, 0), 14)])
    x0 = FL + 60
    R = D / 2
    tela = _manometr_tela(D)
    # корпус: ось циферблата +Y, нижняя точка обода — в конце штуцера
    tela = _place_tela(tela, (x0 + R, -12, 0), Y, X)
    p = Part(name or f'{tag} — мановакуумметр показывающий Ø{D:g}, {rng}, на мембранном разделителе {_kn(klamp)} (AISI 316L)', 'instrument', dn)
    case0 = tela[0][0].fuse(sep)
    p.add(case0, 'ss', 'разделитель, штуцер, корпус')
    for s, c, sub in tela[1:]:
        p.add(s, c, sub)
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=Df)
    p.anchor('top', (x0 + 2 * R, 0, 0))
    return p


def rotametr(name=None, tag='FI', L=300.0):
    """Ротаметр газовый (азот) со стеклянной конусной трубкой, поплавком и игольчатым вентилем на входе, присоединение G1/2.
    Ось — X: 'a' — ВЫХОД (x=0, −X, ставится к коллектору), 'b' — ВХОД (x=L, +X, снизу, с вентилем). Ставить вертикально, вход снизу.
    Вентиль и шкала — лицом в +Z."""
    hx = [hexagon((0, 0, 0), X, 27, 16), hexagon((L - 16, 0, 0), X, 27, 16)]
    blk = [box(16, -25, -17, 50, 25, 17), box(L - 50, -25, -17, L - 16, 25, 17)]
    rods = [cyl((50, s_ * 21, 0), (L - 50, s_ * 21, 0), 8) for s_ in (-1, 1)]
    plate = box(56, -16, -20, L - 56, 16, -17)
    knob_x = L - 33
    vstem = cyl((knob_x, 0, 17), (knob_x, 0, 40), 10)
    p = Part(name or f'{tag} — ротаметр азота со стеклянной трубкой и игольчатым вентилем на входе, G1/2, AISI 316', 'instrument', 15)
    p.add(fuse_all(hx + blk + rods + [vstem, plate]).cut(cyl((-1, 0, 0), (17, 0, 0), 12)).cut(cyl((L - 17, 0, 0), (L + 1, 0, 0), 12)),
          'ss', 'корпус, стойки, шкала')
    p.add(tube((50, 0, 0), (L - 50, 0, 0), 24, 18), 'glass', 'трубка стеклянная')
    p.add(cyl((L - 110, 0, 0), (L - 98, 0, 0), 16), 'red', 'поплавок')
    p.add(cyl((knob_x, 0, 40), (knob_x, 0, 55), 30), 'black', 'маховичок игольчатого вентиля')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=21.3)
    p.port('b', (L, 0, 0), X, Z, 15, 'thread', od=21.3)
    p.anchor('top', (L / 2, 0, 30))
    return p


def reduktor_azota(name=None, tag='PCV', L=110.0):
    """Редуктор давления азота с манометром выхода: ось X, 'a' — ВЫХОД (x=0), 'b' — ВХОД (x=L), G1/2; манометр — лицом в +Z,
    колпак с маховичком настройки — в +Y."""
    s = fuse_all([hexagon((0, 0, 0), X, 27, 16), cyl((16, 0, 0), (26, 0, 0), 24), box(26, -30, -30, L - 26, 30, 30),
                  cyl((L - 26, 0, 0), (L - 16, 0, 0), 24), hexagon((L - 16, 0, 0), X, 27, 16),
                  cyl((L / 2, 30, 0), (L / 2, 70, 0), 50), cyl((L / 2, 0, 30), (L / 2, 0, 46), 14)])
    s = s.cut(cyl((-1, 0, 0), (27, 0, 0), 12)).cut(cyl((L - 27, 0, 0), (L + 1, 0, 0), 12))
    p = Part(name or f'{tag} — редуктор давления азота с манометром, G1/2, AISI 316', 'valve', 15)
    p.add(s, 'ss_cast', 'корпус, колпак')
    p.add(cyl((L / 2, 70, 0), (L / 2, 90, 0), 40), 'black', 'маховичок настройки')
    for b_, c, sub in _place_tela(_manometr_tela(50.0), (L / 2, 0, 46), Z, X):
        p.add(b_, c, 'манометр: ' + sub)
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=21.3)
    p.port('b', (L, 0, 0), X, Z, 15, 'thread', od=21.3)
    p.anchor('top', (L / 2, 0, 80))
    return p


def ushi(r, k, ot=None):
    """Повернуть хомуты, поставленные Run r начиная с элемента ot (индекс в r.items), вокруг их оси так, чтобы шарнирные проушины
    и барашек смотрели по k (проекция на плоскость хомута) — чтобы хомуты соседних соединений не задевали друг друга."""
    from .core import rotate_vec
    k = unit(vec(k))
    for j in r.items[ot or 0:]:
        if j.kind != 'clamp' or j.meta.get('ushi'):
            continue
        ax = j.meta.get('ax')
        c = j.meta.get('c')
        if ax is None:
            continue
        cur = j.meta['ear']
        kk = k - ax * k.dot(ax)
        if kk.Length < 1e-3:
            continue
        kk = kk.normalized()
        ang = math.degrees(math.atan2(ax.dot(cur.cross(kk)), cur.dot(kk)))
        j.apply(Xf.rot(c, ax, ang))
        j.meta['ear'] = kk
        j.meta['ushi'] = True


# ------------------------------------------------------------------ кронштейн гребёнки
def kronshtein(sc, part, k, L, group=None, name=None):
    """Хомут вокруг патрубка part (по середине между 'a' и 'b') + полоса 40×8 по направлению k длиной L + пластина 120×120×8
    к конструкции (порт 'opora', kind contact). Возвращает Part."""
    a, b = part.ports['a'].pos, part.ports['b'].pos
    ax = unit(b - a)
    c = (a + b) * 0.5
    od = part.meta.get('od') or kl('K25')[1]
    k = unit(vec(k) - ax * vec(k).dot(ax))
    ring = tube(c - ax * 15, c + ax * 15, od + 12, od)
    bar = obox(c + k * (od / 2 + 3 + L / 2), k, ax, L, 40, 8)
    pl = obox(c + k * (od / 2 + 3 + L + 4), k, ax, 8, 120, 120)
    q = Part(name or 'кронштейн гребёнки: хомут, полоса 40×8, пластина 120×120 к конструкции (AISI 304)', 'support')
    q.add(fuse_all([ring, bar, pl]), 'sup_galv')
    q.port('opora', c + k * (od / 2 + 3 + L + 8), k, ax, None, 'contact')
    sc.put(q, group)
    return q


# ------------------------------------------------------------------ гребёнка загрузки
def grebenka_zagruzki(sc, vhod, vhody, line='загрузка', group=None, napr=X, vetki=None, lico=None, h0=250.0, shag=280.0,
                      kran='K63', zaglushki=None, tablichki=True, kollektor='K63', vhod_klamp='K25', konec='zaglushka'):
    """Гребёнка загрузки жидкостей (К73): от vhod (кламп K63 на переходнике N1, или фланец — тогда сам ставит переходник) —
    патрубок h0 → отвод на napr → коллектор kollektor «тройник-тройник-тройник» с шагом shag; под каждым тройником (отвод — по vetki,
    по умолчанию вниз) кран kran, затем переход на вход vhod_klamp; на конце коллектора — заглушка K63 (место наращивания).
    vhody — список подписей словами («ЭХГ», «толуол», …); zaglushki — множество подписей, на которые ставится заглушка
    (по умолчанию — на все). Таблички «вход: …» у каждого входа.
    Возвращает dict(vhody={подпись: свободный порт K25 (если без заглушки)}, porty_vseh={подпись: порт до заглушки}, konec=порт,
    parts=[…], kollektor=[патрубки коллектора])."""
    from . import obshchie as OB
    vetki = unit(vec(vetki)) if vetki is not None else -Z
    napr = unit(vec(napr))
    lico = unit(vec(lico)) if lico is not None else unit(vetki.cross(napr)) if vetki.cross(napr).Length > 0.5 else Y
    zaglushki = set(vhody) if zaglushki is None else set(zaglushki)
    col = std.stream_key('feed')
    kran_ = zatvor_klamp if kran in ZATVOR_DYUYM else kran_klamp          # 03.11: краны входов — дисковые затворы под кламп (каталог)
    r = Run(sc, vhod, line, 'SS', vhod.dn, gasket='PTFE', group=group)
    if vhod.kind == 'flange':
        r.add(perekhodnik_flanec_klamp(vhod.dn, vhod.fl['pn'] if vhod.fl else 'PN16', kollektor))
    kol = []
    if abs(r.cur.dir.dot(napr)) < 0.99:
        if h0 > 2 * FL + 1:
            kol.append(r.add(trubka_klamp(kollektor, h0, color=col)))
        r.add(otvod_klamp(kollektor, color=col), up=napr, local_up=Y)
    C = troynik_C(kollektor)
    out, vse = {}, {}
    # 02.11 (Мареев): тройники — вплотную, одним хомутом (без коротких патрубков «по два клампа рядом»), если шаг не больше 2C + патрубок
    vplotnuyu = shag - 2 * C - 6 < 2 * FL + 40.0
    for i, nm in enumerate(vhody):
        Ls = 60.0 if i == 0 else shag - 2 * C - 6
        if i == 0 or not vplotnuyu:
            kol.append(r.add(trubka_klamp(kollektor, Ls, color=col)))
        t = r.add(troynik_klamp(kollektor, color=col), up=vetki, local_up=Y)
        rb = Run(sc, t.ports['c'], line, 'SS', group=group, gasket='PTFE')
        if kran == kollektor:
            rb.add(kran_(kollektor, tag=f'— вход «{nm}»'), up=lico, local_up=Z)
            rb.add(perekhod_klamp(kollektor, vhod_klamp, color=col))
        else:
            rb.add(perekhod_klamp(kollektor, kran, color=col))
            rb.add(kran_(kran, tag=f'— вход «{nm}»'), up=lico, local_up=Z)
            if kran != vhod_klamp:
                rb.add(perekhod_klamp(kran, vhod_klamp, color=col))
        vse[nm] = rb.cur
        kr = [q for q in rb.items if q.kind == 'valve'][0]
        if tablichki and vplotnuyu:
            pass                                 # тройники вплотную: таблички входов — на монтажной схеме; вход с рукавом подписывает узел
        elif tablichki:
            mid = (kr.ports['a'].pos + kr.ports['b'].pos) * 0.5
            sc.put(OB.tablichka(f'вход гребёнки загрузки: {nm}', kr, mid - napr * 150.0, normal=-napr, arm=60, line=line), group)
        if nm in zaglushki:
            rb.add(zaglushka_klamp(vhod_klamp, name=f'заглушка кламповая {_kn(vhod_klamp)} с ручкой — вход «{nm}»'), b=None)
            # тройники вплотную: таблички входов не ставятся (тяги задевали ручки кранов и хомуты) — входы подписаны на монтажной схеме
        else:
            out[nm] = rb.cur
        ushi(rb, -lico)
    kol.append(r.add(trubka_klamp(kollektor, 60.0, color=col)))
    if konec == 'zaglushka':
        r.add(zaglushka_klamp(kollektor, name=f'заглушка кламповая {_kn(kollektor)} — конец гребёнки загрузки (место наращивания)'), b=None)
        kon = None
    else:
        kon = r.cur
    ushi(r, -lico)
    return dict(vhody=out, porty_vseh=vse, konec=kon, kollektor=kol, parts=list(r.items))


# ------------------------------------------------------------------ гребёнка защиты (эталон ТЕФКОТ)
def grebenka_zashchity(sc, vhod, tag='R-x01', line='защита', group=None, napr=X, vverh=Z, lico=None, h0=150.0, shag=230.0,
                       klamp='K63', opora=None, linii=None):      # 01.11 (Мареев): гребёнки защиты — на К63
    """Гребёнка защиты реактора вместо КДЗТ (К73): от vhod (врезка в аварийную линию ниже разрывной мембраны: фланец — ставится
    переходник фланец→K25; или кламп K25) — патрубок h0 → отвод на napr → коллектор K25 на тройниках, перед каждой веткой кран:
      1) шпунт-аппарат (вверх), 2) обратный клапан аварийного сброса (вверх; кран «закрыт только на время вакуумирования») —
         выход шпунта вбок сведён тройником с выходом клапана → порт 'vyhod' (вверх, K25) → в сдувку 114/214/314 → газоочистка;
      3) мановакуумметр (вверх); 4) ввод азота (вниз): кран → переходник K25→G1/2 → ротаметр с игольчатым вентилем → редуктор →
         порт 'azot' (G1/2, вниз — от азотной линии); 5) конец коллектора: кран сброса на атмосферу → отвод вниз → порт 'atm'.
    lico — сторона оператора (циферблаты, рукоятки); opora=(k, L) — два кронштейна от коллектора по направлению k на L до конструкции.
    linii — dict кодов линий {'vent': '114-…', 'n2': '…'} для p.line. Возвращает dict(vyhod, azot, atm, parts, opory, kollektor)."""
    napr, vverh = unit(vec(napr)), unit(vec(vverh))
    lico = unit(vec(lico)) if lico is not None else unit(vverh.cross(napr))
    linii = linii or {}
    cv, cn = std.stream_key('vent'), std.stream_key('nitrogen')
    kran_ = zatvor_klamp if klamp in ZATVOR_DYUYM else kran_klamp        # 03.11: краны веток — дисковые затворы под кламп (каталог)
    Lv = kran_(klamp).meta['L']
    C = troynik_C(klamp)
    r = Run(sc, vhod, line, 'SS', vhod.dn, gasket='PTFE', group=group)
    if vhod.kind == 'flange':
        r.add(perekhodnik_flanec_klamp(vhod.dn, vhod.fl['pn'] if vhod.fl else 'PN16', klamp, name=f'{tag}: переходник фланец-кламп DN{vhod.dn} → {_kn(klamp)} — вход гребёнки защиты'))
    kol = []
    if abs(r.cur.dir.dot(napr)) < 0.99:
        if h0 > 2 * FL + 1:
            kol.append(r.add(trubka_klamp(klamp, h0, color=cv)))
        r.add(otvod_klamp(klamp, color=cv), up=napr, local_up=Y)
    tees = []
    for i, d_ in enumerate((vverh, vverh, vverh, -vverh)):
        kol.append(r.add(trubka_klamp(klamp, 60.0 if i == 0 else shag - 2 * C - 6, color=cv)))
        tees.append(r.add(troynik_klamp(klamp, color=cn if i == 3 else cv), up=d_, local_up=Y))
    # 1) шпунт и 2) обратный клапан — высоты выходов равны
    sh = shpunt_apparat(klamp, tag=f'{tag}', storona=1 if lico.dot(vverh.cross(napr)) >= 0 else -1)
    ck = obratnyy_klapan_klamp(klamp, tag=f'{tag} — аварийный сброс')
    Lck = ck.meta['L']
    Lc2 = 50.0
    Ls = Lck + Lc2 + 3 + C - sh.meta['xo']
    if Ls < 50.0:
        Lc2 += 50.0 - Ls
        Ls = 50.0
    r1 = Run(sc, tees[0].ports['c'], linii.get('vent', line), 'SS', group=group, gasket='PTFE')
    r1.add(kran_(klamp, tag=f'{tag} — перед шпунт-аппаратом'), up=lico, local_up=Z)
    r1.add(trubka_klamp(klamp, Ls, color=cv))
    r1.add(sh, up=napr, local_up=Y)
    r2 = Run(sc, tees[1].ports['c'], linii.get('vent', line), 'SS', group=group, gasket='PTFE')
    r2.add(kran_(klamp, tag=f'{tag} — перед обратным клапаном аварийного сброса (закрыт только на время вакуумирования)'), up=lico, local_up=Z)
    r2.add(ck, up=lico, local_up=Z)
    r2.add(trubka_klamp(klamp, Lc2, color=cv))
    tv = r2.add(troynik_klamp(klamp, color=cv), up=-napr, local_up=Y)
    vyhod = r2.cur
    # выход шпунта → патрубок → в отвод тройника
    d = (tv.ports['c'].pos - r1.cur.pos).dot(napr)
    off = (tv.ports['c'].pos - r1.cur.pos - napr * d).Length
    if off > 0.5:
        raise ValueError(f'гребёнка защиты {tag}: выход шпунта не соосен тройнику ({off:.1f} мм)')
    r1.add(trubka_klamp(klamp, d - 6.0, color=cv))
    from .valves import clamp_joint
    j = clamp_joint(kl(klamp)[0], 'PTFE', dn=kl(klamp)[3], od=kl(klamp)[1])
    e = [X, Z, X.cross(Z)]
    f = [r1.cur.dir, perp_ref(r1.cur.dir), r1.cur.dir.cross(perp_ref(r1.cur.dir))]
    j.apply(Xf.basis(e, f, V(0, 0, 0), r1.cur.pos + r1.cur.dir * 1.5))
    j.meta.update(ax=r1.cur.dir, c=r1.cur.pos + r1.cur.dir * 1.5, ear=perp_ref(r1.cur.dir) * -1)
    r1.items.append(j)
    sc.put(j, group, r1.line)
    sc.link(r1.cur, tv.ports['c'], 'clamp')
    # 3) мановакуумметр
    r3 = Run(sc, tees[2].ports['c'], line, 'SS', group=group, gasket='PTFE')
    r3.add(kran_(klamp, tag=f'{tag} — перед мановакуумметром'), up=lico, local_up=Z)
    r3.add(manometr_klamp(klamp, tag=f'PI {tag}'), b=None, up=lico, local_up=Y)
    # 4) азот (вниз)
    r4 = Run(sc, tees[3].ports['c'], linii.get('n2', line), 'SS', group=group, gasket='PTFE')
    r4.add(kran_(klamp, tag=f'{tag} — ввод азота (азотная подушка)'), up=lico, local_up=Z)
    r4.add(perekhodnik_klamp_rezba(klamp, color=cn))
    r4.add(rotametr(tag=f'FI {tag}'), up=lico, local_up=Z)
    r4.add(reduktor_azota(tag=f'PCV {tag}'), up=lico, local_up=Z)
    azot = r4.cur
    # 5) сброс на атмосферу
    kol.append(r.add(trubka_klamp(klamp, 60.0, color=cv)))
    r.add(kran_(klamp, tag=f'{tag} — сброс на атмосферу'), up=vverh, local_up=Z)
    r.add(otvod_klamp(klamp, color=cv), up=-vverh, local_up=Y)
    atm = r.cur
    for rr in (r, r1, r2, r3, r4):
        ushi(rr, -lico)
    opory = []
    if opora:
        k, Lk = opora
        for pt in (kol[1] if len(kol) > 1 and h0 > 2 * FL + 1 else kol[0], kol[-2]):
            opory.append(kronshtein(sc, pt, k, Lk, group, name=f'{tag}: кронштейн гребёнки защиты (хомут, полоса 40×8, пластина к конструкции)'))
    parts = r.items + r1.items + r2.items + r3.items + r4.items
    return dict(vyhod=vyhod, azot=azot, atm=atm, parts=parts, opory=opory, kollektor=kol, tees=tees)


# ------------------------------------------------------------------ весы
VESY = {'grubye': dict(L=1200.0, W=1200.0, H=90.0, name='весы платформенные низкопрофильные 1200×1200, НПВ 1500 кг, d = 0,5 кг, Ex'),
        'tochnye': dict(L=700.0, W=700.0, H=95.0, name='весы платформенные под бочку 200 л 700×700, НПВ 300 кг, d = 0,05 кг, Ex')}


def vesy(c, tip='grubye', lico=X, z0=0.0, name=None, tag='W', indikator=True, pandus=True, tablo_lok=None):
    """Весы платформенные (Ex): рама, настил (нерж. рифлёный), 4 тензодатчика с опорными ножками, клеммная коробка; индикатор
    на стойке у стороны lico (сбоку); у грубых — пандус с −lico (заезд рохлей). c — центр основания, z0 — отметка пола.
    Возвращает dict(parts, z_top (отметка настила), tablo=точка индикатора, gabarit=(L, W) с пандусом)."""
    from .tara import place
    P = VESY[tip]
    L, W, H = P['L'], P['W'], P['H']
    nm = name or f'{tag} — {P["name"]}'
    fr = [box(-L / 2, -W / 2, 20, L / 2, -W / 2 + 60, H - 6), box(-L / 2, W / 2 - 60, 20, L / 2, W / 2, H - 6),
          box(-L / 2, -W / 2 + 60, 20, -L / 2 + 60, W / 2 - 60, H - 6), box(L / 2 - 60, -W / 2 + 60, 20, L / 2, W / 2 - 60, H - 6),
          box(-30, -W / 2 + 60, 20, 30, W / 2 - 60, H - 6)]
    deck = box(-L / 2, -W / 2, H - 6, L / 2, W / 2, H)
    feet = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = sx * (L / 2 - 30), sy * (W / 2 - 30)
            feet.append(cyl((cx, cy, 0), (cx, cy, 8), 60))
            feet.append(cyl((cx, cy, 8), (cx, cy, 20), 24))
    p = Part(f'{nm}: рама, настил, тензодатчики (4 шт.)', 'equipment')
    p.add(fuse_all(fr), 'cs_paint', 'рама')
    p.add(deck, 'scale_deck', 'настил')
    p.add(fuse_all(feet), 'ss_dark', 'тензодатчики с ножками')
    p.add(box(-L / 2 + 70, -W / 2 + 70, 30, -L / 2 + 170, -W / 2 + 140, 70), 'instr_grey', 'коробка клеммная')
    parts = [p]
    ext = [L, W]
    if tip == 'grubye' and pandus:
        rp = Part(f'{nm}: пандус заезда 1200×600', 'equipment')
        Lr = 600.0
        rp.add(extrude_ramp(-L / 2 - Lr, -L / 2, -W / 2, W / 2, H), 'cs_paint', 'пандус')
        parts.append(rp)
        ext[0] += Lr
    tablo = None
    if indikator:
        q = Part(f'{nm}: индикатор весовой Ex на стойке', 'instrument')
        xs, ys = tablo_lok if tablo_lok else (L / 2 - 100, -W / 2 - 160)      # tablo_lok — центр стойки в локальной системе (x — по lico)
        q.add(fuse_all([box(xs - 100, ys - 100, 0, xs + 100, ys + 100, 10), cyl((xs, ys, 10), (xs, ys, 1100), 60)]), 'cs_paint', 'стойка')
        q.add(box(xs - 130, ys - 40, 1100, xs + 130, ys + 40, 1280), 'instr', 'корпус индикатора')
        q.add(box(xs - 90, ys + 40, 1150, xs + 90, ys + 42, 1240), 'black', 'дисплей')
        q.add(cyl((xs, ys, 1100), (xs, ys, 300), 0.0001) if False else box(xs - 8, ys + 30, 300, xs + 8, ys + 40, 1100), 'cable', 'кабель')
        q.anchor('top', (xs, ys, 1300))
        parts.append(q)
    p.anchor('top', (0, 0, H))
    place(parts, c, lico, z0)
    if indikator:
        tablo = parts[-1].meta['anchors']['top']
    return dict(parts=parts, z_top=vec(c).z + z0 + H, tablo=tablo, gabarit=tuple(ext))


def extrude_ramp(x0, x1, y0, y1, H):
    """Клин пандуса: подъём от 0 при x0 до H при x1."""
    face = cq.Face.makeFromWires(cq.Wire.makePolygon([V(x0, y0, 0), V(x1, y0, 0), V(x1, y0, H), V(x0, y0, 0)]))
    return cq.Solid.extrudeLinear(face, V(0, y1 - y0, 0))


# ------------------------------------------------------------------ бочка 200 л
BOCHKA = dict(D=585.0, H=880.0)


def bochka_200(c, lico=X, z0=0.0, name='Бочка стальная 200 л', soderzhimoe='', sifon=True, dn=25, vyhod='hose'):
    """Бочка 200 л (Ø585×880, крышка с пробками 2″ и ¾″, 2 обруча): с sifon=True в пробку 2″ вставлена заборная трубка (сифон) Ø33,7
    до дна, сверху — отвод на lico с рукавным штуцером (порт 'out', kind hose, DN25); vyhod='klamp' — вместо штуцера ферула K50,5
    (порт 'out', kind clamp — под кран K50,5 «перед насосом»). Без сифона — пробки закрыты.
    Возвращает dict(parts, out, top)."""
    from .tara import place
    D, H = BOCHKA['D'], BOCHKA['H']
    R = D / 2
    xb = R - 90                                     # пробка 2″ ближе к краю, по стороне +X (→ lico)
    what = name + (f' — {soderzhimoe}' if soderzhimoe else '')
    shell = tube((0, 0, 8), (0, 0, H - 8), D, D - 2)
    bot = cyl((0, 0, 8), (0, 0, 9), D - 2)
    top = cyl((0, 0, H - 9), (0, 0, H - 8), D - 2).cut(cyl((xb, 0, H - 10), (xb, 0, H), 52))
    rims = [tube((0, 0, 0), (0, 0, 8), D + 6, D - 20), tube((0, 0, H - 8), (0, 0, H), D + 6, D - 20)]
    hoops = [revolve_profile([(R, z - 12), (R + 8, z - 4), (R + 8, z + 4), (R, z + 12)], (0, 0, 0), Z, X) for z in (H / 3, 2 * H / 3)]
    boss = tube((xb, 0, H - 9), (xb, 0, H + 6), 70, 52)
    boss2 = cyl((-xb, 0, H - 8), (-xb, 0, H + 4), 36)
    p = Part(f'{what}: корпус (обечайка, днища, обручи)', 'equipment')
    p.add(fuse_all([shell, bot, top] + rims + hoops + [boss, boss2]), 'drum', 'корпус')
    parts = [p]
    out = None
    if sifon:
        o = 33.7
        zt = H + 60
        s = Part(f'{what}: сифон (заборная трубка Ø33,7 AISI 316L до дна) с пробкой 2″ и рукавным штуцером DN{dn}', 'pipe', dn)
        tb = fuse_all([tube((xb, 0, 25), (xb, 0, zt), o, o - 3), tube((xb, 0, H + 6), (xb, 0, H + 26), 66, o)])
        el = elbow_solid(o, o - 3, 50, 90.0)
        # отвод: вход вдоль +Z, выход вдоль +X
        el = Xf.basis([X, Y, Z], [Z, X, Z.cross(X)], V(0, 0, 0), V(xb, 0, zt)).shape(el)
        ex = V(xb + 50, 0, zt + 50)
        if vyhod == 'klamp':
            fe = revolve_profile(_ferrule_prof(o, 50.5, FL, 0, 1), ex, X, Z)
            s.add(fuse_all([tb, el, fe]), 'ss', 'трубка, пробка, ферула K50,5')
            s.port('out', ex + X * FL, X, Z, 25, 'clamp', od=50.5)
            s.name = s.name.replace(f'рукавным штуцером DN{dn}', 'ферулой K50,5')
        else:
            tail = fuse_all([cyl(ex, ex + X * 90, o), cyl(ex + X * 30, ex + X * 40, o + 6), cyl(ex + X * 55, ex + X * 65, o + 6)]).cut(cyl(ex - X, ex + X * 91, o - 6))
            s.add(fuse_all([tb, el]), 'ss', 'трубка и пробка')
            s.add(tail, 'ss', 'штуцер рукавный')
            s.port('out', ex + X * 90, X, Z, dn, 'hose')
        parts.append(s)
    p.anchor('top', (0, 0, H + 150))
    place(parts, c, lico, z0)
    if sifon:
        out = parts[1].ports['out']
    return dict(parts=parts, out=out, top=p.meta['anchors']['top'])


# ------------------------------------------------------------------ самопроверка
def _proverka(out=None):
    """Строит каждую деталь и обе гребёнки, проверяет BRepCheck, пересечения тел (checks.overlaps) и висящие порты."""
    from OCP.BRepCheck import BRepCheck_Analyzer
    from .core import Scene, Port
    from . import checks, obshchie as OB
    from .piping import wn_flange
    OB.sbros()
    det = [perekhodnik_flanec_klamp(100, 'PN25', 'K63'), perekhodnik_flanec_klamp(25, 'PN25', 'K63'), perekhodnik_flanec_klamp(50, 'PN16', 'K25'),
           trubka_klamp('K25', 100), troynik_klamp('K25'), troynik_klamp('K63'), otvod_klamp('K25'), otvod_klamp('K63'),
           perekhod_klamp('K63', 'K25'), perekhodnik_klamp_rezba('K25'), kran_klamp('K25'), kran_klamp('K63'), obratnyy_klapan_klamp('K25'),
           shpunt_apparat('K25'), manometr_klamp('K25'), rotametr(), reduktor_azota(), zaglushka_klamp('K25'), zaglushka_klamp('K63')]
    det += vesy((0, 0, 0), 'grubye')['parts'] + vesy((3000, 0, 0), 'tochnye')['parts'] + bochka_200((5000, 0, 0))['parts'] + bochka_200((6000, 0, 0), vyhod='klamp')['parts']
    for i, p in enumerate(det[:19]):
        p.apply(Xf.move((600.0 * (i % 6), 3000.0 + 700.0 * (i // 6), 0)))
    bad = []
    for p in det:
        for s, c, sub in p.bodies:
            if not BRepCheck_Analyzer(s.wrapped).IsValid():
                bad.append(f'{p.name} [{sub}]')
    hits = checks.overlaps(det, min_vol=1.0)
    # сборки
    sc = Scene('K73 проверка')
    f1 = wn_flange(100, 'PN25'); sc.put(f1, 'N1')
    f1.apply(Xf.basis([X, Z, X.cross(Z)], [Z, X, Z.cross(X)], f1.ports['a'].pos, V(0, 0, 0)))
    sc.terminal(f1.ports['a'], 'boundary', 'N1')
    g1 = grebenka_zagruzki(sc, f1.ports['b'], ['ЭХГ', 'уксусная кислота', 'толуол'], group='загрузка', zaglushki={'уксусная кислота', 'толуол'})
    for k_, p_ in g1['vhody'].items():
        sc.terminal(p_, 'tochka', k_)
    f2 = wn_flange(50, 'PN16'); sc.put(f2, 'аварийная')
    f2.apply(Xf.basis([X, Z, X.cross(Z)], [Z, X, Z.cross(X)], f2.ports['a'].pos, V(2000, 0, 0)))
    sc.terminal(f2.ports['a'], 'boundary', 'аварийная линия')
    g2 = grebenka_zashchity(sc, f2.ports['b'], tag='R-T', group='защита', lico=-Y, opora=(Y, 200.0))
    sc.terminal(g2['vyhod'], 'tochka', 'сдувка'); sc.terminal(g2['azot'], 'tochka', 'азот'); sc.terminal(g2['atm'], 'vent', 'атмосфера')
    for q in g2['opory']:
        sc.terminal(q.ports['opora'], 'boundary', 'конструкция')
    for p in sc.parts:
        for s, c, sub in p.bodies:
            if not BRepCheck_Analyzer(s.wrapped).IsValid():
                bad.append(f'сборка: {p.name} [{sub}]')
    allow = lambda pa, sa, pb, sb: pa.kind == 'label' or pb.kind == 'label'
    hits2 = checks.overlaps(sc.parts, min_vol=1.0, allow=allow)
    dang = checks.dangling(sc)
    print(f'деталей {len(det)}, тел невалидных: {len(bad)}; пересечений в деталях: {len(hits)}; в сборках: {len(hits2)}; висящих портов: {len(dang)}')
    for b in bad: print('  НЕВАЛИДНО', b)
    for h in hits[:20] + hits2[:20]: print('  ПЕРЕСЕЧЕНИЕ', h)
    for d in dang[:20]: print('  ВИСИТ', d[0].name, d[1])
    if out:
        from . import export as EX
        sc2 = Scene('K73 галерея')
        for p in det:
            sc2.put(p, 'детали')
        EX.export(sc, out, 'k73-sborki', labels=OB.labels_viewer())
    return len(bad) + len(hits) + len(hits2) + len(dang)


if __name__ == '__main__':
    import sys
    n = _proverka(sys.argv[1] if len(sys.argv) > 1 else None)
    print('ИТОГО замечаний:', n)
