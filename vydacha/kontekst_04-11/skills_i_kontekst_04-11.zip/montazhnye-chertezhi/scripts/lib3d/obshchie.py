"""lib3d.obshchie — общие детали оформления и проверки для всех узлов (замечания Мареева 25.10; CLAUDE.md «куда что идёт»,
«без изломов», «свободные штуцеры — только заглушка», «ни одной трубы в никуда»).

Детали (возвращают Part; в сцену кладёт узел — sc.put(part, группа, линия), кроме функций *_v_scenu):
- tablichka(text, part, pt, normal=None, arm=60, line='')   — табличка-стрелка «→ куда» у конца линии / границы (вместо жёлтых шаров
                                                                и дисков): лист-стрелка 220×90×2 на тяге Ø3 к детали (касание);
- strelka(p, d, od, line='', name=None)                     — стрелка направления потока на трубе: конус-«наконечник» вокруг трубы
                                                                (зазор 0,5 мм — без пересечения с трубой), цвет тёмный;
- strelki_i_vynoski(sc, ...)                                 — на каждой линии сцены: стрелка на каждой прямой трубе ≥ min_len и одна
                                                                выноска «линия — среда: откуда → куда» на самой длинной трубе линии;
- balka_km(p0, p1, z_top, profil='30Ш1', name=None)          — балка площадки целиком по КМ (от колонны до колонны / от главной до
                                                                главной), двутавр, полупрозрачно ('beam_ghost');
- zaglushka_shtucera(sc, port, apparat, shtucer, naznachenie, group, gasket='PTFE') — фланцевая заглушка с прокладкой и шпильками
                                                                на свободный штуцер + строка в SVOBODNYE (список «свободные штуцеры»);
- cvet_ov(name)                                              — цвет местных отсосов: всё (лиана FM-200, рукав KUA, воздуховоды, зонты) —
                                                                поток «вытяжная вентиляция» (серый), не оранжевый; крепёж — 'cs_paint'.
Проверки (по сцене в памяти, до экспорта; возвращают (строки отчёта, число ошибок)):
- izlomy(sc, tol_deg=0.5)          — стык двух труб/рукавов без фитинга под углом > tol = излом;
- otkrytye_koncy(sc, r=800)        — конец-граница (terminal 'tochka' / 'boundary' / 'open') без таблички «→ куда» рядом = открытый конец;
- svobodnye_md(title)              — таблица «свободные штуцеры» (Markdown) из SVOBODNYE.
Реестры (заполняются функциями выше; узел очищает их в начале сборки — sbros()):
  TABLICHKI [(текст, точка, линия)], VYNOSKI [(текст, точка, линия)], SVOBODNYE [(аппарат, штуцер, DN, назначение)].
  VYNOSKI и TABLICHKI — подписи для просмотрщика (export.export(..., labels=labels_viewer())) и рендеров.
"""
import math
import re
import cadquery as cq
from cadquery import Vector as V
from .core import Part, cyl, tube, cone, obox, box, fuse_all, unit, vec, perp_ref, align_xf
from .piping import blind_flange, bolt_joint, gasket_t
from . import std, export

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)
export.PALETTE.setdefault('beam_ghost', (0.42, 0.45, 0.50, 0.35))     # балки площадки по КМ — полупрозрачно
export.PALETTE.setdefault('sign', (0.98, 0.98, 0.96))                  # табличка (белая эмаль)
export.PALETTE.setdefault('sign_edge', (0.10, 0.30, 0.60))             # окантовка таблички (синяя)
export.PALETTE.setdefault('arrow', (0.15, 0.15, 0.17))                 # стрелка потока

TABLICHKI, VYNOSKI, SVOBODNYE = [], [], []


def sbros():
    """Очистить реестры (в начале сборки узла)."""
    TABLICHKI.clear(); VYNOSKI.clear(); SVOBODNYE.clear()


# ------------------------------------------------------------------ табличка «→ куда»
def _nearest(part, q):
    from OCP.BRepExtrema import BRepExtrema_DistShapeShape
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
    from OCP.gp import gp_Pnt
    comp = cq.Compound.makeCompound([b_ for b_, c_, s_ in part.bodies])
    ex = BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(gp_Pnt(*q.toTuple())).Vertex(), comp.wrapped)
    ex.Perform()
    p1 = ex.PointOnShape2(1)
    return V(p1.X(), p1.Y(), p1.Z())


def tablichka(text, part, pt, normal=None, arm=60.0, line='', w=220.0, h=90.0):
    """Табличка-стрелка «→ куда» (нерж. лист 2 мм, белая эмаль с синей окантовкой; текст — в имени детали и в подписи просмотрщика):
    лист в форме стрелки (остриё — по normal×Z, т.е. «туда», куда идёт линия, если normal задан поперёк линии) на тяге Ø3 от ближайшей
    точки детали part к точке pt (касание). Возвращает Part (kind 'label'), регистрирует (текст, точка) в TABLICHKI."""
    q = vec(pt)
    n = unit(normal) if normal is not None else V(-1, 0, 0)
    top = _nearest(part, q + n * 400.0)
    c = top + n * (arm + 1.0)
    w_ = Z.cross(n) if abs(n.z) < 0.9 else X
    w_ = unit(w_)
    up = n.cross(w_).normalized()
    # контур стрелки в плоскости (w_, up): прямоугольник w−h/2 и остриё h/2
    a = w - h / 2
    pts2 = [(-w / 2, -h / 2), (-w / 2 + a, -h / 2), (w / 2, 0.0), (-w / 2 + a, h / 2), (-w / 2, h / 2)]
    wp = [c + w_ * x + up * y for x, y in pts2]
    face = cq.Face.makeFromWires(cq.Wire.makePolygon(wp + [wp[0]]))
    plate = cq.Solid.extrudeLinear(face, n * 2.0)
    edge = cq.Solid.extrudeLinear(cq.Face.makeFromWires(cq.Wire.makePolygon(wp + [wp[0]])), n * -1.0)
    rod = cyl(top + n * 0.3, top + n * (arm + 1.0), 3.0)
    p = Part(f'{line + ": " if line else ""}табличка «{text[:110]}»', 'label')
    p.add(plate, 'sign', 'табличка')
    p.add(edge.cut(cq.Solid.extrudeLinear(cq.Face.makeFromWires(cq.Wire.makePolygon(
        [c + (q_ - c) * 0.88 for q_ in wp] + [c + (wp[0] - c) * 0.88])), n * -1.0)), 'sign_edge', 'окантовка')
    p.add(rod, 'ss_dark', 'тяга')
    p.meta['touch'] = [part.id]
    p.anchor('c', c + n * 2)
    TABLICHKI.append((text, c + n * 3, line))
    return p


# ------------------------------------------------------------------ стрелка потока
def strelka(p, d, od, line='', name=None, L=None):
    """Стрелка направления потока на трубе Ø od: полый конус вокруг трубы (внутр. Ø od+1, без касания), остриё — по d.
    p — центр стрелки на оси трубы. Возвращает Part (kind 'arrow')."""
    d = unit(d)
    L = L or max(110.0, 1.1 * od)
    r_in = od / 2 + 0.5
    r_out = od / 2 + max(14.0, 0.16 * od)
    p0, p1 = vec(p) - d * (L / 2), vec(p) + d * (L / 2)
    outer = cq.Solid.makeCone(r_out, r_in + 2.0, L, p0, d)
    inner = cyl(p0 - d, p1 + d, 2 * r_in)
    body = outer.cut(inner)
    q = Part(name or f'{line}: стрелка направления потока', 'arrow')
    q.add(body, 'arrow', 'стрелка')
    q.anchor('c', vec(p))
    return q


def _pipe_axis(p):
    """Ось прямой трубы по её портам 'a', 'b' (или None)."""
    if p.kind != 'pipe' or 'a' not in p.ports or 'b' not in p.ports:
        return None
    a, b = p.ports['a'].pos, p.ports['b'].pos
    L = (b - a).Length
    if L < 1.0:
        return None
    od = p.ports['a'].od or p.ports['b'].od
    if not od:
        bb = p.bbox()
        dims = sorted([bb.xlen, bb.ylen, bb.zlen])
        od = dims[1]
    return a, b, L, od


ZAPRET_Z = []      # полосы отметок (z0, z1), где стрелок и табличек быть не может (толща настилов) — задаёт узел


def _svobodno(sc, shape, exclude):
    """Тело shape не пересекает детали сцены (кроме exclude, включая чужие трассы) и не попадает в толщу настилов ZAPRET_Z —
    по габаритам и точно (объём общей части < 1 мм³)."""
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
    from OCP.GProp import GProp_GProps
    from OCP.BRepGProp import BRepGProp
    A = shape.BoundingBox()
    for z0, z1 in ZAPRET_Z:
        if A.zmax > z0 - 5 and A.zmin < z1 + 5:
            return False
    for q in sc.parts:
        if q in exclude or not q.bodies or q.kind in ('zone', 'tochka'):
            continue
        for b_, c_, s_ in q.bodies:
            B = b_.BoundingBox()
            if A.xmax < B.xmin or B.xmax < A.xmin or A.ymax < B.ymin or B.ymax < A.ymin or A.zmax < B.zmin or B.zmax < A.zmin:
                continue
            cm = BRepAlgoAPI_Common(shape.wrapped, b_.wrapped)
            pr = GProp_GProps()
            BRepGProp.VolumeProperties_s(cm.Shape(), pr)
            if pr.Mass() > 1.0:
                return False
    return True


def strelki_i_vynoski(sc, opisanie, group=None, min_len=500.0, obratno=(), skip=lambda p: False, label_min=0.0):
    """На каждой линии сцены (p.line из opisanie): стрелка потока на каждой прямой трубе длиной ≥ min_len (по направлению a → b,
    для линий из obratno или где obratno(p) истинно — b → a) и выноска «<линия> — <среда>: <откуда → куда>» у середины самой длинной трубы линии.
    opisanie: {линия: 'среда: откуда → куда'}. Возвращает число стрелок; выноски — в VYNOSKI."""
    best, n = {}, 0
    for p in list(sc.parts):
        if p.line not in opisanie or skip(p):
            continue
        ax = _pipe_axis(p)
        if ax is None:
            continue
        a, b, L, od = ax
        rev = obratno(p) if callable(obratno) else (p.line in obratno)
        d = unit(b - a) * (-1 if rev else 1)
        if L >= min_len:                                   # место стрелки — без пересечений с опорами, изоляцией и соседними деталями
            nb = [q for q in sc.parts if q is p]
            for f in (0.5, 0.35, 0.65, 0.2, 0.8, 0.12, 0.88):
                st = strelka(a + (b - a) * f, d, od, p.line)
                if _svobodno(sc, st.bodies[0][0], nb):
                    sc.put(st, group or p.group, p.line)
                    n += 1
                    break
        if L > best.get(p.line, (0,))[0]:
            best[p.line] = (L, (a + b) * 0.5, od)
    for ln, (L, c, od) in best.items():
        if L >= label_min:
            VYNOSKI.append((f'{ln} — {opisanie[ln]}', c + Z * (od / 2 + 10), ln))
    return n


# ------------------------------------------------------------------ балка площадки целиком по КМ
PROFIL = {'30Ш1': (296.0, 200.0, 9.0, 14.0), '35Ш1': (338.0, 250.0, 9.5, 12.5), '40Ш1': (388.0, 300.0, 9.5, 14.0),
          '20Б1': (200.0, 100.0, 5.6, 8.5), '25Б1': (248.0, 124.0, 5.0, 8.0), '30Б1': (296.0, 140.0, 5.8, 8.5), '12П': (120.0, 52.0, 4.8, 7.8), '16П': (160.0, 64.0, 5.0, 8.4),
          '24П': (240.0, 90.0, 5.6, 10.0)}


def balka_km(p0, p1, z_top, profil='30Ш1', name=None, color='beam_ghost'):
    """Балка площадки целиком (двутавр profil) от p0 до p1 (точки в плане, x/y), верх — z_top; полупрозрачно.
    Возвращает Part (kind 'struct'). Для швеллера ('12П') — П-образное сечение стенкой к p0×p1-левой стороне."""
    H, B, tw, tf = PROFIL[profil]
    a, b = V(p0[0], p0[1], 0), V(p1[0], p1[1], 0)
    u = unit(b - a)
    L = (b - a).Length
    w = Z.cross(u).normalized()
    m = (a + b) * 0.5
    zc = z_top - H / 2
    if profil.endswith('П'):
        web = obox(V(m.x, m.y, zc) - w * (B / 2 - tw / 2), u, w, L, tw, H)
        fl_t = obox(V(m.x, m.y, z_top - tf / 2), u, w, L, B, tf)
        fl_b = obox(V(m.x, m.y, z_top - H + tf / 2), u, w, L, B, tf)
        sh = fuse_all([web, fl_t.cut(web), fl_b.cut(web)])
    else:
        fl_t = obox(V(m.x, m.y, z_top - tf / 2), u, w, L, B, tf)
        fl_b = obox(V(m.x, m.y, z_top - H + tf / 2), u, w, L, B, tf)
        web = obox(V(m.x, m.y, zc), u, w, L, tw, H - 2 * tf)
        sh = fuse_all([fl_t, web, fl_b])
    q = Part(name or f'балка {profil} L={L:.0f} (КМ, целиком)', 'struct')
    q.add(sh, color, profil)
    q.meta['beam'] = dict(p0=tuple(p0), p1=tuple(p1), z_top=z_top, profil=profil, L=L)
    return q


# ------------------------------------------------------------------ свободный штуцер — только заглушка
def zaglushka_shtucera(sc, port, apparat, shtucer, naznachenie, group=None, gasket='PTFE', mat='SS', line=None):
    """Фланцевая заглушка (EN 1092-1 тип 05) с прокладкой и шпильками на свободный штуцер аппарата; строка в SVOBODNYE.
    port — фланцевый порт штуцера (смотрит наружу). Возвращает (заглушка, соединение)."""
    fl = port.fl
    pn = fl['pn'] if fl else 'PN16'
    b = blind_flange(port.dn, pn, mat, name=f'{apparat} {shtucer}: заглушка фланцевая DN{port.dn} {pn} — свободный штуцер ({naznachenie})')
    b.apply(align_xf(b.ports['a'], port, gasket_t(gasket), 0.0))
    j = bolt_joint(port, b.ports['a'], gasket, name=f'{apparat} {shtucer}: соединение заглушки DN{port.dn} {pn} (прокладка, шпильки с гайками)')
    sc.put(b, group, line or f'{apparat} {shtucer}')
    sc.put(j, group, line or f'{apparat} {shtucer}')
    sc.link(port, b.ports['a'], 'flange')
    SVOBODNYE.append((apparat, shtucer, port.dn, naznachenie))
    return b, j


def svobodnye_md(title):
    rows = [f'# {title} — свободные штуцеры (заглушены фланцевыми заглушками с прокладкой и крепежом)', '',
            'Правило (Мареев, 25.10): к штуцеру, не задействованному по схеме, ничего не подключается — фланцевая заглушка и строка здесь.', '',
            '| № | Аппарат | Штуцер | DN | Назначение по чертежу поставщика |', '|---|---|---|---|---|']
    rows += [f'| {i} | {a} | {s} | {dn} | {t} |' for i, (a, s, dn, t) in enumerate(SVOBODNYE, 1)]
    rows += ['', f'**СВОБОДНЫХ ШТУЦЕРОВ: {len(SVOBODNYE)}** (все заглушены)']
    return '\n'.join(rows) + '\n'


# ------------------------------------------------------------------ цвет местных отсосов
def cvet_ov(name):
    """Цвет детали местного отсоса: поток «вытяжная вентиляция» (серый) — лиана FM-200 целиком (балка, воздуховод, шланг, рукав KUA,
    воронка), зонты, воздуховоды, дроссель-клапаны; крепёж, плиты, болты, подвески — 'cs_paint' (тёмно-серый). Не оранжевый (25.10)."""
    low = name.lower()
    if any(k in low for k in ('болт', 'гайк', 'шпильк', 'подвеск', 'плита', 'хомут опор', 'консоль', 'талреп', 'тормоз', 'кронштейн стен')):
        return 'cs_paint'
    return std.stream_key('exhaust')


# ------------------------------------------------------------------ проверки
def izlomy(sc, tol_deg=0.5, kinds=('pipe', 'hose')):
    """Изломы на прямых (Мареев 25.10): связь двух деталей kinds без фитинга между ними — оси соосны (угол ≤ tol_deg).
    Возвращает (строки таблицы Markdown, число изломов)."""
    rows, n = [], 0
    for pa, na, pb, nb, kind in sc.links:
        if pa is None or pb is None or pa.kind != 'pipe' or pb.kind != 'pipe':
            continue
        a_, b_ = pa.ports[na], pb.ports[nb]
        ang = math.degrees(math.acos(max(-1.0, min(1.0, -a_.dir.dot(b_.dir)))))
        if ang > tol_deg:
            n += 1
            rows.append(f'| {pa.line} | {pa.name[:60]} | {pb.name[:60]} | {ang:.2f} |')
    # труба, приставленная к трубе без связи (стык «на глаз»): торцы совпадают, оси не соосны
    ends = [(p, k, q) for p in sc.parts if p.kind == 'pipe' for k, q in p.ports.items() if q.link is None]
    for i, (p, k, q) in enumerate(ends):
        for p2, k2, q2 in ends[i + 1:]:
            if p2 is p or (q.pos - q2.pos).Length > 0.5:
                continue
            ang = math.degrees(math.acos(max(-1.0, min(1.0, -q.dir.dot(q2.dir)))))
            if ang > tol_deg:
                n += 1
                rows.append(f'| {p.line} | {p.name[:60]} | {p2.name[:60]} | {ang:.2f} (без связи) |')
    head = ['Стык двух труб без фитинга: угол между осями ≤ 0,5°; смена направления или уклона — только отводом.', '',
            '| Линия | Труба A | Труба B | Угол, ° |', '|---|---|---|---|']
    return head + rows + ['', f'**ИЗЛОМОВ: {n}**'], n


def otkrytye_koncy(sc, r=900.0, kinds=('tochka', 'boundary', 'open')):
    """Открытые концы: каждый конец-граница (terminal kinds) — с табличкой «→ куда» (TABLICHKI) не дальше r от конца
    (заглушки, колпаки, воздушники с пробками — terminal 'plug'/'vent'/'drain' — закрыты). Возвращает (строки, число открытых)."""
    rows, n = [], 0
    for part, pn, kind, text in sc.terminals:
        if kind not in kinds:
            continue
        pos = part.ports[pn].pos
        near = [t for t, q, ln in TABLICHKI if (q - pos).Length <= r]
        ok = bool(near)
        n += 0 if ok else 1
        rows.append(f'| {part.line or ""} | {kind} | {pos.x:.0f}; {pos.y:.0f}; {pos.z:.0f} | {text[:90]} | {"«" + near[0][:60] + "»" if ok else "**НЕТ таблички**"} |')
    head = ['Каждый конец-граница — с табличкой «→ куда конкретно» (узел, аппарат, штуцер); прочие концы — заглушки, колпаки, пробки.', '',
            '| Линия | Конец | X; Y; Z, мм | Куда | Табличка |', '|---|---|---|---|---|']
    return head + rows + ['', f'**ОТКРЫТЫХ КОНЦОВ: {n}**'], n


def labels_viewer(dz=0.0):
    """Подписи для просмотрщика / рендеров: [[текст, x, y, z], …] — выноски линий и таблички."""
    out = [[t, q.x, q.y, q.z + dz] for t, q, ln in VYNOSKI]
    out += [['→ ' + t.lstrip('→ ') if not t.startswith(('→', '←')) else t, q.x, q.y, q.z] for t, q, ln in TABLICHKI]
    return out


# ------------------------------------------------------------------ выноски в кадре рендера (крупные планы)
_KLUCH = re.compile(r'^(?:ГРАНИЦА → )?(\d{3}|[A-ZА-ЯЁ]{1,4}-\d+(?:/\d+)?(?: поз\. \d+)?)')


def _kluch(t):
    """Ключ «одна выноска на линию/аппарат»: номер линии (105-50-S, 105 — …) → '105'; ЕК-1 … → 'ЕК-1'; SP-101 поз. 8 → 'SP-101 поз. 8'; табличка «→ …» — по тексту."""
    m = _KLUCH.match(t.strip())
    return m.group(1) if m else 'T:' + t.strip().lstrip('→ ').strip()[:28]


def vynoski_kadra(labels, eye, target, fov=30.0, W=2400, H=1600, maks=9, fs=20.0, ortho=None, verh=64.0, kray=12.0, centr=None):
    """Выноски для кадра рендера (lib3d/render.js, viewer.html: labels [текст, x, y, z, dx, dy]) — правило для крупных планов всех узлов:
    только то, что в кадре; одна выноска на линию/аппарат (дубли «ЕК-1 …» снимаются; приоритет — выноска линии, затем выноска узла,
    затем табличка «→ куда»); не больше maks (ближние к центру кадра); подписи разнесены в две колонки к левому и правому краю кадра
    (без наложений, порядок по высоте сохраняется — линии-выноски не пересекаются), текст не выходит за край кадра (длинный — с «…»);
    сверху оставлено verh px под заголовок. Полный набор выносок — в 3D-просмотрщике (кнопка «Выноски»).
    labels — [[текст, x, y, z], …] (мм цеха, Z вверх) — например OB.labels_viewer() или labels из viewer-meta.json."""
    import math as _m
    def t3(p):                                   # мм цеха -> three (Y вверх), как M() во viewer.html
        return (p[0], p[2], -p[1])
    e, g = t3(eye), t3(target)
    f = [g[i] - e[i] for i in range(3)]
    nf = _m.sqrt(sum(c * c for c in f)); f = [c / nf for c in f]
    up = (0.0, 1.0, 0.0)
    r = [f[1] * up[2] - f[2] * up[1], f[2] * up[0] - f[0] * up[2], f[0] * up[1] - f[1] * up[0]]
    nr = _m.sqrt(sum(c * c for c in r)) or 1.0; r = [c / nr for c in r]
    u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]]
    asp = W / H
    th_ = _m.tan(_m.radians(fov) / 2)

    def proj(p):
        q = t3(p)
        d = [q[i] - e[i] for i in range(3)]
        xc, yc, zc = (sum(d[i] * r[i] for i in range(3)), sum(d[i] * u[i] for i in range(3)), sum(d[i] * f[i] for i in range(3)))
        if ortho:
            nx, ny = xc / (ortho / 2), yc / (ortho / 2 / asp)
        else:
            if zc <= 1.0:
                return None
            nx, ny = xc / (zc * th_ * asp), yc / (zc * th_)
        return (nx + 1) / 2 * W, (1 - ny) / 2 * H
    tw_ = lambda t: len(t) * fs * 0.62 + 14         # как в viewer.html (жирный шрифт ≈ 0,6 кегля на знак)
    th = fs + 10
    maxch = int((0.42 * W - 14) / (fs * 0.62))
    cx, cy = (W / 2, H / 2) if centr is None else centr
    cand = {}
    for L in labels:
        t, x, y, z = L[0], L[1], L[2], L[3]
        pp = proj((x, y, z))
        if pp is None:
            continue
        px, py = pp
        if not (0.04 * W <= px <= 0.96 * W and verh + 10 <= py <= H - 0.04 * H):
            continue
        k = _kluch(t)
        pri = 0 if re.match(r'^\d{3}-\S+ — ', t) else (2 if t.lstrip().startswith('→') else 1)
        sc = (pri, _m.hypot(px - cx, py - cy))
        if k not in cand or sc < cand[k][0]:
            cand[k] = (sc, t if len(t) <= maxch else t[:maxch - 1].rstrip() + '…', x, y, z, px, py)
    sel = sorted(cand.values(), key=lambda c: c[0][1])[:maks]
    left = [c for c in sel if c[5] < W / 2]
    right = [c for c in sel if c[5] >= W / 2]
    # колонка не должна перекрывать свою точку: если подпись слишком длинная для стороны — на другую сторону
    def fits(c, side):
        w_ = tw_(c[1])
        return (kray + w_ + 20 < c[5]) if side == 'L' else (c[5] < W - kray - w_ - 20)
    for a, b, sd in ((left, right, 'L'), (right, left, 'R')):
        for c in list(a):
            if not fits(c, sd) and fits(c, 'R' if sd == 'L' else 'L'):
                a.remove(c); b.append(c)
    out = []
    pitch = th + 8
    for col, sd in ((left, 'L'), (right, 'R')):
        col.sort(key=lambda c: c[6])
        n = len(col)
        if not n:
            continue
        top_, bot_ = verh + th + 6, H - 10
        ys = []
        for c in col:                             # жадно сверху вниз, затем сдвиг вверх, если не влезло
            ys.append(max(c[6], ys[-1] + pitch if ys else top_))
        over = ys[-1] - bot_
        if over > 0:
            for i in range(n - 1, -1, -1):
                lim = bot_ - (n - 1 - i) * pitch
                ys[i] = min(ys[i], lim)
            for i in range(1, n):
                ys[i] = max(ys[i], ys[i - 1] + pitch)
        for c, ty in zip(col, ys):
            t, x, y, z, px, py = c[1], c[2], c[3], c[4], c[5], c[6]
            w_ = tw_(t)
            if sd == 'L':
                dx = min(-1.0, kray + w_ - px)        # x0 = px + dx − w = kray
            else:
                dx = max(0.0, W - kray - w_ - px)     # x0 = px + dx = W − kray − w
            out.append([t, x, y, z, round(dx, 1), round(ty - py, 1)])
    return out
