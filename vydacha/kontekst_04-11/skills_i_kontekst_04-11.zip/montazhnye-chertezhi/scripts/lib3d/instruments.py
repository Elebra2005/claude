"""lib3d.instruments — КИП: датчик давления (на мембранном разделителе или вентильном блоке), термопреобразователь
с головкой (в гильзе / на бобышке), манометр с сифонной трубкой и трёхходовым краном, радарный уровнемер.

Локальная система: присоединение 'a' — в начале координат, смотрит в −X; прибор растёт вдоль +X;
«лицо» прибора (дисплей, циферблат) — в +Y, кабельный ввод — вниз (−Z) у датчиков, сбоку у головок.
Детали прибора не проникают друг в друга: соседние тела соприкасаются торцами.
"""
import math
from cadquery import Vector as V
from .core import Part, cyl, tube, cone, revolve_profile, hexagon, fuse_all, sph, torus, box, cbox, obox, Xf, unit, vec
from .piping import bolt_holes, nut_clear_r, elbow_solid
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def _housing(p, x0, name_color='instr', display=True):
    """Корпус электроники двухкамерный (ось — вдоль Y), крышки с резьбой, дисплей спереди, кабельный ввод снизу.
    x0 — плоскость, на которую опирается шейка корпуса. Возвращает x верха корпуса."""
    Dh, Lh = 96.0, 118.0
    cx = x0 + Dh / 2
    body = cyl((cx, -Lh / 2, 0), (cx, Lh / 2, 0), Dh)
    neck_boss = cyl((x0, 0, 0), (cx, 0, 0), 46)
    p.add(fuse_all([body, neck_boss]), name_color, 'корпус электроники')
    covers = []
    for sg in (-1, 1):
        y0 = sg * Lh / 2
        covers.append(revolve_profile([(0, 0), (Dh / 2 + 3, 0), (Dh / 2 + 3, 14), (Dh / 2 - 6, 20), (0, 20)], (cx, y0, 0), Y * sg))
    p.add(covers, name_color, 'крышки')
    if display:
        p.add(cyl((cx, Lh / 2 + 20, 0), (cx, Lh / 2 + 21.5, 0), 60), 'glass', 'окно индикатора')
    # кабельный ввод (Ex d, M20×1,5) снизу корпуса и кабель
    g0 = V(cx, Lh * 0.18, -Dh / 2)
    gl = fuse_all([cyl(g0, g0 - Z * 14, 24), hexagon(g0 - Z * 14, -Z, 24, 10), cyl(g0 - Z * 24, g0 - Z * 40, 20)])
    p.add(gl, 'ss_dark', 'кабельный ввод Ex d M20×1,5')
    p.add(cyl(g0 - Z * 40, g0 - Z * 160, 10), 'cable', 'кабель')
    # шильдик
    p.add(obox((cx, -Lh * 0.15, Dh / 2 + 0.6 - 0.0), X, Y, 40, 30, 1.2).translate(V(0, 0, 0)), 'nameplate', 'табличка')
    return cx + Dh / 2


def pressure_transmitter(tag='PT', name=None, conn='thread', pn_fl=None, dn_fl=25, seal=True):
    """Датчик давления с корпусом электроники и кабельным вводом.
    conn='flange': на фланцевом мембранном разделителе DN dn_fl (порт 'a' — фланец);
    conn='thread': на резьбе M20×1,5 (порт 'a' — резьба, ставится на вентильный блок)."""
    p = Part(name or f'{tag} — датчик давления (абс./изб.) Ex d, 4–20 мА HART' + (f', мембранный разделитель фланцевый DN{dn_fl}' if conn == 'flange' else ''),
             'instrument')
    x = 0.0
    if conn == 'flange':
        fl = std.flange(dn_fl, pn_fl or 'PN16')
        # разделитель: нижняя часть = фланец с выступом и отверстиями, мембрана, верхний корпус с винтом заполнения
        plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (fl['D'] / 2, fl['f1']), (fl['D'] / 2, fl['f1'] + fl['C']), (0, fl['f1'] + fl['C'])],
                                (0, 0, 0), X)
        for h in bolt_holes(fl, -1, fl['f1'] + fl['C'] + 1):
            plate = plate.cut(h)
        x = fl['f1'] + fl['C']
        top = cyl((x, 0, 0), (x + 30, 0, 0), nut_clear_r(fl) * 2 - 4)
        p.add(fuse_all([plate, top]), 'ss', 'мембранный разделитель (фланец, мембрана 316L)')
        fs = hexagon((x + 12, 0, (nut_clear_r(fl) - 2)), Z, 10, 6)
        p.add(fs, 'ss_dark', 'винт заполнения разделителя')
        x += 30
        p.port('a', (0, 0, 0), -X, Z, dn_fl, 'flange', fl=fl)
    else:
        p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=20.0)
    # штуцер M20×1,5 (шестигранник) и сенсорный модуль
    hx = hexagon((x, 0, 0), X, 27, 16)
    sm = cyl((x + 16, 0, 0), (x + 16 + 70, 0, 0), 52)
    ring = cyl((x + 16 + 70, 0, 0), (x + 16 + 80, 0, 0), 58)
    neck = cyl((x + 96, 0, 0), (x + 120, 0, 0), 34)
    p.add(fuse_all([hx, sm, ring, neck]), 'ss', 'сенсорный модуль')
    xt = _housing(p, x + 120)
    p.anchor('top', (xt, 0, 0))
    p.anchor('mid', (x + 120 + 48, 0, 0))
    return p


def valve_manifold(name=None, tag=''):
    """Вентильный блок 2-вентильный (отсечной + дренажный), вход/выход M20×1,5, AISI 316."""
    p = Part(name or f'блок вентильный 2-вентильный AISI 316, PN400' + (f' {tag}' if tag else ''), 'manifold')
    blk = cbox((35, 0, 0), 70, 56, 56)
    inl = cyl((0, 0, 0), (7, 0, 0), 26)
    p.add(fuse_all([blk.translate(V(7, 0, 0)), inl]), 'ss_cast', 'корпус')
    for y0, sg in ((-28, -1), (28, 1)):
        c = V(42, y0, 0)
        b = fuse_all([cyl(c, c + Y * sg * 30, 24), hexagon(c + Y * sg * 30, Y * sg, 22, 10)])
        p.add(b, 'ss_dark', 'вентиль')
        st = cyl(c + Y * sg * 40, c + Y * sg * 62, 8)
        th = cyl(c + Y * sg * 62 + Z * -28, c + Y * sg * 62 + Z * 28, 9)
        p.add(fuse_all([st, th]), 'lever_blue', 'рукоятка')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=20.0)
    p.port('b', (77, 0, 0), X, Z, 15, 'thread', od=20.0)
    return p


def rtd(tag='TE', name=None, L_neck=120, conn='thread', insert_L=0):
    """Термопреобразователь сопротивления Pt100 с головкой (форма B, алюминий, Ex d), удлинитель, штуцер M20×1,5.
    insert_L — длина погружной части (уходит в −X внутрь гильзы/трубы; для бобышки на трубе)."""
    p = Part(name or f'{tag} — термопреобразователь сопротивления Pt100 с головкой Ex d (4–20 мА)', 'instrument')
    hx = hexagon((0, 0, 0), X, 27, 18)
    nk = cyl((18, 0, 0), (18 + L_neck, 0, 0), 16)
    nut2 = hexagon((18 + L_neck, 0, 0), X, 24, 12)
    p.add(fuse_all([hx, nk, nut2]), 'ss', 'штуцер и удлинитель')
    x0 = 30 + L_neck
    # головка: корпус Ø82 с крышкой, кабельный ввод сбоку (+Y)
    head = revolve_profile([(0, 0), (22, 0), (36, 12), (41, 14), (41, 58), (0, 58)], (x0, 0, 0), X)
    cover = revolve_profile([(0, 0), (43, 0), (43, 10), (36, 22), (0, 26)], (x0 + 58, 0, 0), X)
    gl = fuse_all([cyl((x0 + 34, 41, 0), (x0 + 34, 54, 0), 22), hexagon((x0 + 34, 54, 0), Y, 24, 10), cyl((x0 + 34, 64, 0), (x0 + 34, 78, 0), 18)])
    p.add(head, 'alu', 'головка')
    p.add(cover, 'instr', 'крышка головки')
    p.add(gl, 'ss_dark', 'кабельный ввод Ex d M20×1,5')
    p.add(cyl((x0 + 34, 78, 0), (x0 + 34, 200, 0), 9), 'cable', 'кабель')
    if insert_L:
        p.add(cyl((0, 0, 0), (-insert_L, 0, 0), 10), 'ss_dark', 'погружная часть Ø10')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=27.0)
    p.anchor('top', (x0 + 84, 0, 0))
    p.anchor('mid', (x0 + 30, 0, 0))
    return p


def thermowell_flange(dn, pn, L_well, d_well=57.0, boss_h=40, name=None, tag=''):
    """Гильза термометра фланцевая: глухой фланец DN с вваренной гильзой (уходит в −X — внутрь штуцера/аппарата)
    и бобышкой M20×1,5 сверху. Порт 'a' — плоскость фланца (смотрит в −X, к штуцеру), 'b' — торец бобышки (+X)."""
    fl = std.flange(dn, pn)
    T = fl['f1'] + fl['C']
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (fl['D'] / 2, fl['f1']), (fl['D'] / 2, T), (0, T)], (0, 0, 0), X)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    boss = cyl((T, 0, 0), (T + boss_h, 0, 0), 40)
    well = revolve_profile([(0, -L_well), (d_well / 2 - 4, -L_well), (d_well / 2, -L_well + 6), (d_well / 2, 0), (0, 0)], (0, 0, 0), X)
    p = Part(name or f'гильза термометра фланцевая DN{dn} {pn}, Ø{d_well:g}×5, L={L_well} (316L, поставка)' + (f' {tag}' if tag else ''), 'thermowell', dn)
    p.add(fuse_all([plate, boss, well]), 'ss', 'гильза с фланцем')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (T + boss_h, 0, 0), X, Z, 15, 'thread', od=27.0)
    return p


def boss(od_pipe, h=45, name='бобышка M20×1,5 (приварная)'):
    """Бобышка резьбовая на трубе: 'a' — основание (касается трубы по образующей), 'b' — торец под прибор."""
    p = Part(name, 'boss', 15)
    p.add(cyl((0, 0, 0), (h, 0, 0), 36), 'ss')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=36.0)
    p.port('b', (h, 0, 0), X, Z, 15, 'thread', od=27.0)
    return p


def gauge(tag='PI', name=None, D=100, rng='−0,1…0,15 МПа'):
    """Манометр показывающий: радиальный штуцер M20×1,5 снизу, корпус Ø D, циферблат и стекло — в +Y."""
    p = Part(name or f'{tag} — манометр (мановакуумметр) показывающий Ø{D}, {rng}, корпус AISI 304, кл. 1,5', 'instrument')
    hx = hexagon((0, 0, 0), X, 22, 14)
    st = cyl((14, 0, 0), (34, 0, 0), 14)
    p.add(fuse_all([hx, st]), 'brass', 'штуцер')
    R = D / 2
    cx = 34 + R + 2
    case = revolve_profile([(0, 0), (R, 0), (R + 2, 4), (R + 2, 30), (0, 30)], (cx, -14, 0), Y)
    lug = cyl((34, 0, 0), (cx - R + 6, 0, 0), 20)
    p.add(fuse_all([case, lug]), 'ss', 'корпус')
    bezel = revolve_profile([(R - 3, 0), (R + 3, 0), (R + 3, 6), (R - 3, 8)], (cx, 16, 0), Y)
    p.add(bezel, 'ss_dark', 'байонетное кольцо')
    p.add(cyl((cx, 16, 0), (cx, 17.5, 0), 2 * R - 8), 'dial', 'циферблат')
    p.add(cyl((cx, 22, 0), (cx, 23.5, 0), 2 * R - 6), 'glass', 'стекло')
    needle = obox((cx + R * 0.25, 19.5, R * 0.18), V(math.cos(math.radians(35)), 0, math.sin(math.radians(35))), Y, R * 0.72, 3, 1.5)
    p.add(fuse_all([needle, cyl((cx, 17.5, 0), (cx, 21, 0), 8)]), 'black', 'стрелка')
    ticks = []
    for k in range(11):
        a = math.radians(225 - 27 * k)
        u = V(math.cos(a), 0, math.sin(a))
        ticks.append(obox(V(cx, 17.5 + 0.5, 0) + u * (R * 0.75), u, Y, R * 0.12, 1.0, 1.0))
    p.add(ticks, 'black', 'шкала')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=22.0)
    p.anchor('top', (cx + R, 0, 0))
    p.anchor('mid', (cx, 0, 0))
    return p


def siphon(name=None, od=14.0, h=180.0, R=28.0):
    """Трубка сифонная (петлевая, ГОСТ 25164 тип П): вход 'a' (−X), петля 360° с шагом в сторону −Y, выход 'b' (+X)."""
    p = Part(name or 'трубка сифонная петлевая 14×2, AISI 316 (защита манометра)', 'siphon', 15)
    di = od - 4
    leg = h * 0.35
    s1 = tube((0, 0, 0), (leg, 0, 0), od, di)
    # петля: два полукольца в плоскостях с шагом по Y, соединённых переходом
    import cadquery as cq
    helix = cq.Wire.makeHelix(pitch=od * 1.6, height=od * 1.6, radius=R, center=V(0, 0, 0), dir=V(0, 0, 1))
    prof = cq.Workplane(cq.Plane(origin=helix.startPoint().toTuple(), xDir=(0, 0, 1), normal=helix.tangentAt(0).toTuple())).circle(od / 2).circle(di / 2)
    coil = prof.sweep(cq.Workplane().add(helix), isFrenet=True).val()
    # ориентация: ось спирали — вдоль −Y; спираль касается оси прямой ветки
    sp = helix.startPoint()
    x = Xf.basis([V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)], [Z, X, -Y], V(0, 0, 0), V(0, 0, 0))
    coil = x.shape(coil)
    sp2 = x.p(sp)
    t0 = x.d(helix.tangentAt(0))
    # совместить начало спирали с концом ветки (leg, 0, 0), касательная — +X
    coil = coil.translate(V(leg, 0, 0) - sp2)
    ep = x.p(helix.endPoint()) + (V(leg, 0, 0) - sp2)
    s2 = tube(ep, ep + X * leg, od, di)
    p.add([s1, coil, s2], 'ss', 'трубка')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=od)
    p.port('b', ep + X * leg, X, Z, 15, 'thread', od=od)
    p.meta['tangent0'] = t0
    return p


def gauge_cock(name=None):
    """Кран трёхходовой для манометра (11Б18бк, муфтовый M20×1,5) с рукояткой и контрольным фланцем."""
    p = Part(name or 'кран трёхходовой для манометра 11Б18бк (M20×1,5), AISI 316', 'valve', 15)
    body = fuse_all([hexagon((0, 0, 0), X, 22, 12), cyl((12, 0, 0), (52, 0, 0), 30), hexagon((52, 0, 0), X, 22, 12)])
    plug = cyl((32, 8, 0), (32, 36, 0), 20)
    ctrl = cyl((32, -8, 0), (32, -26, 0), 18).fuse(cyl((32, -26, 0), (32, -30, 0), 32))
    p.add(fuse_all([body, plug, ctrl]), 'brass', 'корпус')
    hd = fuse_all([cyl((32, 36, 0), (32, 44, 0), 14), obox((32 + 26, 40, 0), X, Y, 52, 8, 12)])
    p.add(hd, 'black', 'рукоятка')
    p.port('a', (0, 0, 0), -X, Z, 15, 'thread', od=22.0)
    p.port('b', (64, 0, 0), X, Z, 15, 'thread', od=22.0)
    return p


def radar_level(dn=50, pn='PN16', tag='LT', name=None, horn_L=140):
    """Уровнемер радарный (рупорная антенна PTFE/316L внутри штуцера, фланец DN, корпус Ex d с кабельным вводом)."""
    fl = std.flange(dn, pn)
    T = fl['f1'] + fl['C']
    p = Part(name or f'{tag} — уровнемер радарный 80 ГГц, фланец DN{dn} {pn}, антенна PTFE, Ex d, 4–20 мА', 'instrument', dn)
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (fl['D'] / 2, fl['f1']), (fl['D'] / 2, T), (0, T)], (0, 0, 0), X)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    neck = cyl((T, 0, 0), (T + 70, 0, 0), 48)
    hx = hexagon((T + 70, 0, 0), X, 55, 16)
    p.add(fuse_all([plate, neck, hx]), 'ss', 'фланец и переходник')
    horn = revolve_profile([(0, 0), (12, 0), (std.pipe('SS', dn)[0] / 2 - 9, -horn_L), (0, -horn_L)], (0, 0, 0), X)
    p.add(horn, 'ptfe', 'антенна PTFE')
    x0 = T + 86
    hs = revolve_profile([(0, 0), (40, 0), (58, 20), (58, 95), (0, 95)], (x0, 0, 0), X)
    p.add(hs, 'alu', 'корпус')
    cv = revolve_profile([(0, 0), (60, 0), (60, 14), (40, 34), (0, 40)], (x0 + 95, 0, 0), X)
    p.add(cv, 'instr', 'крышка')
    gl = fuse_all([cyl((x0 + 55, 58, 0), (x0 + 55, 72, 0), 24), hexagon((x0 + 55, 72, 0), Y, 24, 10)])
    p.add(gl, 'ss_dark', 'кабельный ввод Ex d')
    p.add(cyl((x0 + 55, 82, 0), (x0 + 55, 220, 0), 10), 'cable', 'кабель')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.anchor('top', (x0 + 135, 0, 0))
    return p
