// Рендеры модели через viewer.html (three.js) в headless Chromium — с точной камерой и выносками.
// Запуск: NODE_PATH=/opt/node22/lib/node_modules node render.js <папка модели (viewer.html + *.gltf.json)> <shots.json> <папка png> [W H]
// shots.json: [{name, eye:[x,y,z], target:[x,y,z], fov, hide:[re], only:[re], ghost:[re], section:{p:[x,y,z], n:[nx,ny,nz]}, labels:[[текст,x,y,z,dx,dy]], title}]
// three.js — из node_modules/three (рядом с этим файлом или в THREE_DIR), т.к. CDN в песочнице может быть недоступен.
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const [src, shotsFile, out, W, H] = process.argv.slice(2);
const THREE_DIR = process.env.THREE_DIR || path.join(__dirname, 'node_modules', 'three');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.glb': 'model/gltf-binary' };
const shots = JSON.parse(fs.readFileSync(shotsFile, 'utf8'));
const only = process.env.ONLY ? process.env.ONLY.split(',') : null;
const srv = http.createServer((q, r) => {
  let u = decodeURIComponent(q.url.split('?')[0]);
  if (u === '/' || u === '/index.html') {
    const h = fs.readFileSync(path.join(src, 'viewer.html'), 'utf8').replace(/https:\/\/unpkg\.com\/three@[\d.]+\//g, '/three/');
    r.writeHead(200, { 'Content-Type': TYPES['.html'] }); return r.end(h);
  }
  const f = u.startsWith('/three/') ? path.join(THREE_DIR, u.slice(7)) : path.join(src, u);
  fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream' }); r.end(d); });
}).listen(0, '127.0.0.1', async () => {
  const port = srv.address().port;
  fs.mkdirSync(out, { recursive: true });
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: +(W || 2400), height: +(H || 1600) }, colorScheme: 'light' });
  p.on('console', m => { if (m.type() === 'error') console.log('ERR', m.text()); });
  p.on('pageerror', e => console.log('PAGEERR', e.message));
  await p.goto(`http://127.0.0.1:${port}/index.html?ui=0`);
  await p.waitForFunction(() => window.__ready, null, { timeout: 600000 });
  for (const s of shots) {
    if (only && !only.includes(s.name)) continue;
    const t0 = Date.now(); await p.evaluate(s => window.shot(s), s);
    await p.waitForTimeout(400);
    const f = path.join(out, `${s.name}.png`); await p.screenshot({ path: f, timeout: 900000 }); console.log(f, ((Date.now() - t0) / 1000).toFixed(1) + ' с');
  }
  await b.close(); srv.close();
});
