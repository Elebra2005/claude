"""lib3d.tara — передвижная тара и подключения к ней (общие для всех узлов; замечания Мареева 25.10, п.7, 13, 14, 22).

Детали (все возвращают Part или список Part, в сцену не кладут — это делает узел: sc.put(part, группа, линия)):
- ibc(...)            — еврокуб IBC 1000 л реалистично: стальной поддон (доски, 9 бобышек, настил), обрешётка из прутка
                        с угловыми стойками и верхней рамкой, бак HDPE со скруглениями, верхняя горловина DN150 с крышкой
                        (или крышка-налив с рукавным штуцером), нижний кран DN50 (дисковый затвор) с кулачковой полумуфтой 2″;
- telezhka(...)       — тележка платформенная под еврокуб: рама из профиля, настил, ручка, 4 поворотных колеса
                        (площадка, поворотный подшипник, вилка, колесо на оси);
- nasos_aodd(...)     — насос пневматический мембранный (AODD) Ex на раме: камеры, коллекторы, пневмораспределитель;
- shtucer_klamp / shtucer_flanec / shtucer_kulachok — рукавные штуцеры (кламп K64 / фланец PN16 / кулачковая полумуфта);
- rukav(...)          — рукав одним гладким телом по сплайну между двумя портами 'hose' (sweep кольца, без «колбасы»):
                        vid='metall' — металлорукав в оплётке, 'pp' — вакуумный рукав PP армированный (К69), 'ptfe' — рукав PTFE;
- donnyy_klapan(...)  — клапан донного слива подробно: фланец к штуцеру, Y-корпус с выходом 45° и фланцем, крышка (бугель-фланец)
                        на 4 шпильках с прокладкой, сальник с нажимной втулкой на 2 шпильках, бугель на 2 стойках, ходовая гайка,
                        шток, маховик с рукояткой.

Соглашения lib3d: мм, Z вверх; порты 'hose' — конец хвостовика рукавного штуцера (рукав начинается на торце хвостовика).
Детали спроектированы без взаимных проникновений тел (касания, а не пересечения) — строгая проверка clash3d --strict.
"""
import math
import cadquery as cq
from cadquery import Vector as V
from .core import Part, Xf, cyl, tube, box, cbox, obox, hexagon, fuse_all, revolve_profile, unit, vec, perp_ref, torus
from .piping import bolt_holes, nut_clear_r
from . import std, export

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)
export.PALETTE.setdefault('ibc_tank', (0.94, 0.94, 0.91, 0.82))      # бак HDPE (молочно-белый, слегка прозрачный)
export.PALETTE.setdefault('braid', (0.66, 0.68, 0.70))               # оплётка металлорукава
export.PALETTE.setdefault('pp_hose', (0.90, 0.90, 0.86))             # рукав PP (если цвет потока не задан)
export.PALETTE.setdefault('trolley', (0.20, 0.36, 0.62))             # рама тележки (порошковая окраска)

# ------------------------------------------------------------------ вспомогательное


def _fuse(shapes):
    shapes = [s for s in shapes if s is not None]
    if len(shapes) == 1:
        return shapes[0]
    s = shapes[0].fuse(*shapes[1:])
    try:
        c = s.clean()
        if c.isValid() and abs(c.Volume() - s.Volume()) < 1e-4 * max(1.0, abs(s.Volume())):
            return c
    except Exception:
        pass
    return s


def place(parts, c, d=X, z0=0.0):
    """Перенести детали из локальной системы (начало — центр основания, «лицо» — +X) в точку c, «лицо» — по горизонтали d."""
    d = unit(V(d.x, d.y, 0) if hasattr(d, 'x') else V(d[0], d[1], 0))
    c = vec(c)
    x = Xf.basis([X, Z, X.cross(Z)], [d, Z, d.cross(Z)], V(0, 0, 0), V(c.x, c.y, c.z + z0))
    for p in parts:
        p.apply(x)
    return parts


_CACHE = {}


def _copy(key, build):
    """Геометрия типовой детали строится один раз (локально), дальше — копии (переносятся place())."""
    if key not in _CACHE:
        _CACHE[key] = build()
    return [(s.copy(), c, sub) for s, c, sub in _CACHE[key]]


# ------------------------------------------------------------------ еврокуб IBC 1000 л
IBC = dict(L=1200.0, W=1000.0, H=1160.0, pallet=130.0, tank_top=1110.0, valve_z=235.0, neck_d=160.0)


def _ibc_bodies():
    L2, W2 = IBC['L'] / 2, IBC['W'] / 2
    zp, zt = IBC['pallet'], IBC['tank_top']
    # поддон стальной оцинкованный: 3 нижние доски вдоль X, 9 бобышек, настил
    pal = [box(-L2, y - 50, 0, L2, y + 50, 20) for y in (-W2 + 50, 0, W2 - 50)]
    pal += [box(x - 75, y - 50, 20, x + 75, y + 50, 112) for x in (-L2 + 75, 0, L2 - 75) for y in (-W2 + 50, 0, W2 - 50)]
    pal += [box(-L2, -W2, 110, L2, W2, zp)]
    # бак HDPE: скруглённые рёбра, бобышка выпуска на +X, горловина DN150 сверху
    tk = cq.Workplane('XY').box(1140, 940, zt - zp - 1, centered=(True, True, False)).edges('|Z').fillet(70).edges('>Z').fillet(35) \
        .translate((0, 0, zp + 1)).val()
    boss = cyl((560, 0, IBC['valve_z']), (601, 0, IBC['valve_z']), 92)
    neck = cyl((0, 0, zt - 20), (0, 0, zt + 40), IBC['neck_d'])
    tank = _fuse([tk, boss, neck])
    # обрешётка: угловые стойки 30×30, пруток Ø16 — стойки по граням, пояса, верхняя рамка с двумя поперечинами
    r, xo, yo = 8.0, 591.0, 491.0
    zs = (zp + r, 380.0, 620.0, 860.0, zt + r + 2)
    cg = [cbox((sx * (xo - 7), sy * (yo - 7), (zp + zt + 2 * r + 2) / 2), 30, 30, zt + 2 * r + 2 - zp) for sx in (-1, 1) for sy in (-1, 1)]
    for z in zs:
        cg += [cyl((-xo, -yo, z), (xo, -yo, z), 2 * r), cyl((-xo, yo, z), (xo, yo, z), 2 * r),
               cyl((-xo, -yo, z), (-xo, yo, z), 2 * r), cyl((xo, -yo, z), (xo, yo, z), 2 * r)]
    for y in (-330.0, -165.0, 0.0, 165.0, 330.0):
        for sx in (-1, 1):
            z_lo = 380.0 if (sx > 0 and abs(y) < 120) else zs[0]          # у крана на +X — вырез обрешётки
            cg.append(cyl((sx * xo, y, z_lo), (sx * xo, y, zs[-1]), 2 * r))
    for x in (-394.0, -197.0, 0.0, 197.0, 394.0):
        for sy in (-1, 1):
            cg.append(cyl((x, sy * yo, zs[0]), (x, sy * yo, zs[-1]), 2 * r))
    for x in (-300.0, 300.0):
        cg.append(cyl((x, -yo, zs[-1]), (x, yo, zs[-1]), 2 * r))
    cage = _fuse(cg)
    # кран нижний DN50 (дисковый затвор, PP): корпус, фланцы, шток с рычагом, кулачковая полумуфта 2″
    zv = IBC['valve_z']
    vb = _fuse([cyl((601, 0, zv), (612, 0, zv), 120), cyl((612, 0, zv), (652, 0, zv), 100), cyl((652, 0, zv), (663, 0, zv), 120),
                cyl((632, 0, zv + 50), (632, 0, zv + 80), 26)])
    lev = _fuse([cyl((632, 0, zv + 80), (632, 0, zv + 92), 34), obox(V(632, 70, zv + 88), Y, X, 150, 24, 8)])
    cam = _fuse([cyl((663, 0, zv), (690, 0, zv), 78), cyl((690, 0, zv), (735, 0, zv), 70)]).cut(cyl((600, 0, zv), (736, 0, zv), 50))
    cam_ears = [obox(V(678, s_ * 46, zv), Y, X, 14, 18, 10) for s_ in (-1, 1)]
    return dict(pallet=[(_fuse(pal), 'sup_galv', 'поддон стальной оцинкованный')],
                cage=[(cage, 'zn', 'обрешётка из прутка Ø16 с угловыми стойками')],
                tank=[(tank, 'ibc_tank', 'бак HDPE 1000 л с горловиной DN150')],
                valve=[(vb, 'pph', 'корпус дискового затвора DN50'), (lev, 'lever', 'рычаг'),
                       (_fuse([cam] + cam_ears), 'pph', 'полумуфта кулачковая 2″ (тип A)')])


def ibc(c, lico=X, z0=0.0, name='Еврокуб IBC 1000 л', soderzhimoe='', verh='kryshka', niz='kran'):
    """Еврокуб IBC 1000 л (1200×1000×1160, тип Schütz MX): возвращает dict(parts=[поддон, обрешётка, бак, крышка, кран], out=порт
    кулачковой полумуфты нижнего крана (hose, DN50, смотрит по lico) или None, inn=порт крышки-налива (hose, DN50, вверх) или None, top=точка
    над горловиной). c — центр основания (на полу/площадке/тележке: z0 — отметка основания), lico — куда смотрит кран (горизонтально).
    verh: 'kryshka' — винтовая крышка DN150; 'naliv' — крышка с рукавным штуцером DN50 (налив сверху). niz: 'kran' (порт out) |
    'zaglushka' (кран закрыт, на полумуфте — кулачковая заглушка, порта нет)."""
    B = _CACHE.get('ibc') or _CACHE.setdefault('ibc', _ibc_bodies())
    what = f'{name}' + (f' — {soderzhimoe}' if soderzhimoe else '')
    ps = []
    for key, nm in (('pallet', 'поддон стальной (доски, 9 бобышек, настил)'), ('cage', 'обрешётка из прутка (угловые стойки, пояса, верхняя рамка)'),
                    ('tank', 'бак HDPE 1000 л, горловина DN150')):
        p = Part(f'{what}: {nm}', 'equipment')
        for s, col, sub in B[key]:
            p.add(s.copy(), col, sub)
        ps.append(p)
    zt = IBC['tank_top'] + 40
    cp = Part(f'{what}: ' + ('крышка винтовая DN150 с воздушником' if verh == 'kryshka' else 'крышка-налив DN150 со штуцером рукавным DN50'), 'cap', 50)
    cp.add(_fuse([tube((0, 0, zt), (0, 0, zt + 42), 205, IBC['neck_d'] + 0.4), cyl((0, 0, zt + 42), (0, 0, zt + 52), 205)] +
                 [obox(V(102.5 + 3, 0, zt + 21), X, Y, 6, 14, 42).rotate((0, 0, 0), (0, 0, 1), a) for a in range(0, 360, 30)]), 'lever_blue', 'крышка')
    if verh == 'naliv':
        cp.add(_fuse([cyl((0, 0, zt + 52), (0, 0, zt + 70), 90), cyl((0, 0, zt + 70), (0, 0, zt + 150), 58),
                      cyl((0, 0, zt + 100), (0, 0, zt + 112), 64), cyl((0, 0, zt + 125), (0, 0, zt + 137), 64)]).cut(cyl((0, 0, zt + 51), (0, 0, zt + 151), 46)),
               'ss', 'штуцер рукавный DN50')
        cp.port('in', (0, 0, zt + 150), Z, X, 50, 'hose')
    else:
        cp.add(cyl((120 - 102.5 + 40, 0, zt + 52), (120 - 102.5 + 40, 0, zt + 64), 26), 'lever_blue', 'пробка воздушника')
    ps.append(cp)
    v = Part(f'{what}: кран нижний DN50 (дисковый затвор PP/EPDM) с кулачковой полумуфтой 2″' + (' и заглушкой' if niz != 'kran' else ''), 'valve', 50)
    for s, col, sub in B['valve']:
        v.add(s.copy(), col, sub)
    zv = IBC['valve_z']
    if niz == 'kran':
        v.port('out', (735, 0, zv), X, Z, 50, 'hose')
    else:
        v.add(_fuse([cyl((735, 0, zv), (760, 0, zv), 78), cyl((760, 0, zv), (768, 0, zv), 40)]), 'pph', 'заглушка кулачковая 2″ (тип DC)')
    ps.append(v)
    v.anchor('top', (630, 0, zv + 100))
    ps[2].anchor('top', (0, 0, zt + 160))
    ps[2].anchor('mid', (0, 0, 650))
    place(ps, c, lico, z0)
    return dict(parts=ps, out=v.ports.get('out'), inn=cp.ports.get('in'), top=ps[2].meta['anchors']['top'], kran=v, bak=ps[2])


# ------------------------------------------------------------------ тележка платформенная под еврокуб
TEL = dict(L=1300.0, W=1100.0, H=300.0, wheel=200.0)


def _tel_bodies():
    L2, W2, H = TEL['L'] / 2, TEL['W'] / 2, TEL['H']
    zf = H - 4.0                                     # верх рамы = низ настила
    fr = [box(-L2, -W2, zf - 50, L2, -W2 + 40, zf), box(-L2, W2 - 40, zf - 50, L2, W2, zf),
          box(-L2, -W2 + 40, zf - 50, -L2 + 40, W2 - 40, zf), box(L2 - 40, -W2 + 40, zf - 50, L2, W2 - 40, zf)]
    fr += [box(x - 20, -W2 + 40, zf - 50, x + 20, W2 - 40, zf) for x in (-200.0, 200.0)]
    fr += [box(-L2, -W2, zf, L2, W2, H)]                                            # настил 4 мм (рифлёный лист)
    xs, ys = L2 - 110, W2 - 100
    for sx in (-1, 1):
        for sy in (-1, 1):
            fr.append(box(sx * xs - 60, sy * ys - 55, zf - 58, sx * xs + 60, sy * ys + 55, zf - 50))   # площадка колеса
    fr += [box(-L2 + 40, s_ * ys - 20, zf - 50, L2 - 40, s_ * ys + 20, zf) for s_ in (-1, 1)]       # продольные балки над колёсами
    # ручка: две стойки Ø32 и поперечина на 900 мм над настилом, с торца −X
    xh = -L2 + 16
    hd = [cyl((xh, s_ * 420, H), (xh, s_ * 420, H + 896), 32) for s_ in (-1, 1)] + [cyl((xh, -436, H + 896), (xh, 436, H + 896), 32)]
    frame = _fuse(fr + hd)
    grip = _fuse([tube((xh, -300, H + 896), (xh, 300, H + 896), 42, 32.2)])
    forks, wheels = [], []
    R = TEL['wheel'] / 2
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = sx * xs, sy * ys
            zb = zf - 58
            brg = cyl((cx, cy, zb - 14), (cx, cy, zb), 100)
            top = box(cx - 45, cy - 40, zb - 22, cx + 45, cy + 40, zb - 14)
            pl = [box(cx - 45, cy + s_ * 29, R - 10, cx + 45, cy + s_ * 29 + s_ * 6, zb - 22) for s_ in (-1, 1)]
            ax = cyl((cx, cy - 41, R), (cx, cy + 41, R), 19.0)
            nuts = [hexagon((cx, cy + s_ * 35, R), Y * s_, 30, 6) for s_ in (-1, 1)]
            forks.append(_fuse([brg, top] + pl + [ax] + nuts))
            wh = revolve_profile([(10.0, -25), (R - 12, -25), (R, -18), (R, 18), (R - 12, 25), (10.0, 25)], (cx, cy, R), Y, Z)
            wheels.append(wh)
    return dict(frame=[(frame, 'trolley', 'рама из профиля 60×40, настил 4 мм, ручка Ø32')], grip=[(grip, 'rubber', 'накладка ручки')],
                forks=[(f, 'ss_dark', 'вилка поворотная с подшипником и осью') for f in forks],
                wheels=[(w, 'rubber', 'колесо Ø200 полиуретан') for w in wheels])


def telezhka(c, lico=X, z0=0.0, name='Тележка платформенная под еврокуб', gp=1500):
    """Тележка платформенная 1300×1100, г/п gp кг: рама из профиля, настил, ручка (на −lico), 4 поворотных колеса Ø200 с тормозом.
    Возвращает dict(parts=[рама, колёса], z_top=отметка настила (ставить еврокуб: ibc(..., z0=z_top)))."""
    B = _CACHE.get('tel') or _CACHE.setdefault('tel', _tel_bodies())
    p = Part(f'{name}, г/п {gp} кг: рама, настил, ручка', 'equipment')
    for k in ('frame', 'grip'):
        for s, col, sub in B[k]:
            p.add(s.copy(), col, sub)
    w = Part(f'{name}: колёса поворотные Ø200 (4 шт., 2 с тормозом) — вилки, подшипники, оси', 'equipment')
    for k in ('forks', 'wheels'):
        for s, col, sub in B[k]:
            w.add(s.copy(), col, sub)
    p.anchor('ruchka', (-TEL['L'] / 2 + 16, 0, TEL['H'] + 896))
    place([p, w], c, lico, z0)
    return dict(parts=[p, w], z_top=vec(c).z + z0 + TEL['H'])


# ------------------------------------------------------------------ насос пневматический мембранный (AODD), Ex
def nasos_aodd(c, name, lico=Y * -1, dn_in=50, dn_out=40, z0=0.0):
    """Насос пневматический мембранный 1½″ (AODD) на раме: две камеры по оси X, коллекторы всаса (снизу, порт 'in' — по lico)
    и напора (сверху, порт 'out' — вверх), пневмораспределитель с подводом воздуха. c — центр рамы на полу/площадке."""
    p = Part(name, 'pump', dn_out)
    p.add(box(-220, -160, 0, 220, 160, 40), 'ss_dark', 'рама')
    p.add(_fuse([cyl((-210, 0, 300), (-90, 0, 300), 300), cyl((90, 0, 300), (210, 0, 300), 300), box(-90, -110, 170, 90, 110, 430)]), 'pph',
          'камеры и центральный блок')
    # стояки и патрубки Ø56, горизонтальные коллекторы Ø60: пересечение цилиндров одного Ø (вырожденный случай) после STEP невалидно
    # (исправление узла X-600 obv_proekt.fix_aodd перенесено в библиотеку 26.10; fix_aodd() узла остаётся совместимым — тело то же)
    p.add(_fuse([cyl((-150, 0, 40), (-150, 0, 150), 56), cyl((150, 0, 40), (150, 0, 150), 56), cyl((-175, 0, 95), (175, 0, 95), 60),
                 cyl((0, 0, 95), (0, -230, 95), 56), cyl((-150, 0, 450), (-150, 0, 520), 56), cyl((150, 0, 450), (150, 0, 520), 56),
                 cyl((-175, 0, 520), (175, 0, 520), 60), cyl((0, 0, 520), (0, 0, 640), 56)]), 'pph', 'коллекторы всаса и напора')
    p.add(_fuse([box(-50, 110, 260, 50, 170, 340), cyl((0, 170, 300), (0, 230, 300), 20)]), 'alu', 'пневмораспределитель, подвод воздуха')
    p.port('in', (0, -230, 95), -Y, Z, dn_in, 'hose')
    p.port('out', (0, 0, 640), Z, Y, dn_out, 'hose')
    p.anchor('top', (0, 0, 700))
    # «лицо» насоса — сторона всаса (−Y локально) → lico
    d = unit(V(lico.x, lico.y, 0))
    cc = vec(c)
    x = Xf.basis([-Y, Z, (-Y).cross(Z)], [d, Z, d.cross(Z)], V(0, 0, 0), V(cc.x, cc.y, cc.z + z0))
    p.apply(x)
    return p


# ------------------------------------------------------------------ рукавные штуцеры
def shtucer_klamp(dn=50, size=64.0, name=None):
    """Штуцер рукавный: ферула под кламп (DIN 32676) + хвостовик с двумя обжимными буртами. 'a' — кламп (−X), 'b' — конец хвостовика (hose)."""
    rf = size / 2
    rt = {25: 17.0, 40: 22.5, 50: 25.5, 100: 52.0}.get(dn, 0.51 * dn)
    p = Part(name or f'штуцер рукавный кламп Ø{size:g} DN{dn} (AISI 316L): ферула + хвостовик', 'fitting', dn)
    fe = revolve_profile([(0, 0), (rf, 0), (rf, 3), (rt, 7), (rt, 20), (0, 20)], V(0, 0, 0), X)
    tl = _fuse([cyl((19, 0, 0), (110, 0, 0), 2 * rt), cyl((40, 0, 0), (52, 0, 0), 2 * rt + 7), cyl((70, 0, 0), (82, 0, 0), 2 * rt + 7)])
    p.add(_fuse([fe, tl]).cut(cyl((-1, 0, 0), (111, 0, 0), 2 * rt - 7)), 'ss')
    p.port('a', (0, 0, 0), -X, Z, dn, 'clamp', od=size)
    p.port('b', (110, 0, 0), X, Z, dn, 'hose')
    return p


def shtucer_flanec(dn=50, pn='PN16', name=None):
    """Штуцер рукавный фланцевый: фланец + хвостовик с буртами. 'a' — фланец (−X), 'b' — конец хвостовика (hose)."""
    fl = std.flange(dn, pn)
    o = std.pipe('SS', dn)[0]
    p = Part(name or f'штуцер рукавный фланцевый DN{dn} {pn} (AISI 316L)', 'fitting', dn)
    f_ = cyl((0, 0, 0), (fl['C'], 0, 0), fl['D']).cut(cyl((-1, 0, 0), (fl['C'] + 1, 0, 0), o - 8))
    for h in bolt_holes(fl, -1, fl['C'] + 1):
        f_ = f_.cut(h)
    tl = _fuse([cyl((fl['C'] - 1, 0, 0), (fl['C'] + 110, 0, 0), o - 3), cyl((fl['C'] + 40, 0, 0), (fl['C'] + 52, 0, 0), o + 4),
                cyl((fl['C'] + 70, 0, 0), (fl['C'] + 82, 0, 0), o + 4)])
    p.add(_fuse([f_, tl]).cut(cyl((-2, 0, 0), (fl['C'] + 111, 0, 0), o - 10)), 'ss')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (fl['C'] + 110, 0, 0), X, Z, dn, 'hose')
    return p


def shtucer_kulachok(dn=50, name=None):
    """Полумуфта кулачковая (Camlock, тип C — «мама» с рычагами) с хвостовиком: 'a' — на ответную полумуфту (hose-hose), 'b' — хвостовик."""
    p = Part(name or f'полумуфта кулачковая DN{dn} тип C (AISI 316 / PP) с хвостовиком', 'fitting', dn)
    p.add(_fuse([cyl((0, 0, 0), (45, 0, 0), 88), cyl((45, 0, 0), (130, 0, 0), 58), cyl((75, 0, 0), (87, 0, 0), 65), cyl((100, 0, 0), (112, 0, 0), 65)])
          .cut(cyl((-1, 0, 0), (131, 0, 0), 46)), 'ss', 'корпус')
    p.add([obox(V(22, s_ * 52, 0), Y, X, 12, 30, 14).fuse(obox(V(62, s_ * 56, 0), X, Y, 86, 10, 10)) for s_ in (-1, 1)], 'ss_dark', 'рычаги')   # рычаги сложены вдоль корпуса к хвостовику
    p.port('a', (0, 0, 0), -X, Z, dn, 'hose')
    p.port('b', (130, 0, 0), X, Z, dn, 'hose')
    return p


# ------------------------------------------------------------------ рукав одним телом по сплайну
RUKAV = {   # vid: (наименование, цвет по умолчанию, od по DN, стенка)
    'metall': ('металлорукав нержавеющий гофрированный в оплётке AISI 321/304', 'braid', {25: 44.0, 40: 62.0, 50: 74.0, 100: 132.0}, 6.0),
    'pp': ('рукав вакуумный полипропиленовый армированный спиралью PP (К69)', 'pp_hose', {25: 40.0, 40: 56.0, 50: 66.0, 100: 124.0}, 5.0),
    'ptfe': ('рукав PTFE гофрированный в оплётке AISI 304, антистатический', 'braid', {25: 42.0, 40: 58.0, 50: 72.0, 100: 128.0}, 5.0),
}


def hose_points(pa, pb, via=(), k=None, sag=0.0, n=14):
    """Ось рукава — точки естественного изгиба: от pa (выходит по pa.dir) к pb (входит против pb.dir) через via; sag — провис середины
    вниз, мм. Кубические Эрмитовы сплайны по опорным точкам (касательные на концах — по портам), n точек на участок."""
    p0, d0, p1, d1 = pa.pos, unit(pa.dir), pb.pos, unit(pb.dir)
    L = (p1 - p0).Length
    k = k or max(80.0, min(0.3 * L, 450.0))
    key = [p0, p0 + d0 * k] + [vec(q) for q in via]
    if sag and not via:
        m = (p0 + d0 * k + p1 + d1 * k) * 0.5
        key.append(m - Z * sag)
    key += [p1 + d1 * k, p1]
    # касательные: на концах — по портам; внутри — Катмулл-Ром
    T = []
    for i_, q in enumerate(key):
        if i_ == 0:
            T.append(d0 * k)
        elif i_ == len(key) - 1:
            T.append(-d1 * k)
        else:
            T.append((key[i_ + 1] - key[i_ - 1]) * 0.5)
    T[1] = d0 * ((key[2] - key[0]).Length * 0.5)            # у штуцеров — прямые хвосты, касательная — по оси штуцера
    T[-2] = -d1 * ((key[-1] - key[-3]).Length * 0.5)
    pts = [key[0]]
    for i_ in range(len(key) - 1):
        a, b, ta, tb = key[i_], key[i_ + 1], T[i_], T[i_ + 1]
        if i_ in (0, len(key) - 2):                         # прямой хвост
            pts.append(b)
            continue
        m = n
        for j_ in range(1, m + 1):
            t = j_ / m
            h00, h10, h01, h11 = 2 * t ** 3 - 3 * t ** 2 + 1, t ** 3 - 2 * t ** 2 + t, -2 * t ** 3 + 3 * t ** 2, t ** 3 - t ** 2
            pts.append(a * h00 + ta * h10 + b * h01 + tb * h11)
    out = [pts[0]]
    for q in pts[1:]:
        if (q - out[-1]).Length > 2.0:
            out.append(q)
    out[-1] = p1
    return out


def hose_path(pa, pb, via=(), k=None, sag=0.0):
    """Ось рукава одним ребром-сплайном (для подписей и длины); тело строится по hose_points() — см. rukav()."""
    return cq.Edge.makeSpline(hose_points(pa, pb, via, k, sag))


def _sweep_ring(pts, od, di, R):
    """Кольцо od/di по оси: прямой хвост — сплайн C1 — прямой хвост (cq.Solid.sweep, без Френе); если тело невалидно —
    по ломаной из опорных точек со скруглениями R (lib3d.mashiny.hose_path_solid)."""
    from OCP.BRepCheck import BRepCheck_Analyzer
    p0, p1, q0, q1 = pts[0], pts[1], pts[-2], pts[-1]
    d0, d1 = unit(p1 - p0), unit(q1 - q0)
    try:
        ed = [cq.Edge.makeLine(p0, p1)]
        mid = pts[1:-1]
        if len(mid) >= 2:
            ed.append(cq.Edge.makeSpline(mid, tangents=[d0, d1], scale=True))
        ed.append(cq.Edge.makeLine(q0, q1))
        path = cq.Wire.assembleEdges(ed)
        sol = cq.Solid.sweep(cq.Wire.makeCircle(od / 2, p0, d0), [cq.Wire.makeCircle(di / 2, p0, d0)], path, makeSolid=True, isFrenet=False,
                             transitionMode='right')
        if BRepCheck_Analyzer(sol.wrapped).IsValid() and sol.Volume() > 0:
            return sol, path.Length()
    except Exception:
        pass
    from .mashiny import hose_path_solid
    step = max(1, len(pts) // 6)
    sel = pts[:2] + pts[2:-2:step] + pts[-2:]
    return hose_path_solid(sel, od, di, R)


def rukav(pa, pb, name=None, vid='metall', dn=50, od=None, via=(), sag=0.0, k=None, color=None, R=None):
    """Рукав между двумя портами 'hose': одно гладкое тело (кольцо по оси естественного изгиба), порты 'a' (у pa) и 'b' (у pb).
    Ось — hose_points() (Эрмитов сплайн с касательными по портам, провис sag), тело — заметание кольца по ломаной с дугами (устойчиво,
    без «колбасы» и без падений по памяти на сложных сплайнах; исправлено 26.10). R — наименьший радиус гиба (по умолчанию 4·od).
    Возвращает Part (kind 'hose', meta L — длина по оси, мм; R_min). Связи: rukav_v_scenu() или sc.link() в узле."""
    nm, col, ods, w = RUKAV[vid]
    od = od or ods.get(dn, 1.3 * dn + 10)
    pts = hose_points(pa, pb, via, k, sag)
    R = R or 4.0 * od
    sol, L = _sweep_ring(pts, od, od - 2 * w, R)
    from OCP.BRepCheck import BRepCheck_Analyzer
    if not BRepCheck_Analyzer(sol.wrapped).IsValid():
        sol = sol.fix()
    rmin = 1e9
    for i_ in range(1, len(pts) - 1):
        a_, b_ = unit(pts[i_] - pts[i_ - 1]), unit(pts[i_ + 1] - pts[i_])
        th = math.acos(max(-1.0, min(1.0, a_.dot(b_))))
        if th > 1e-4:
            rmin = min(rmin, min((pts[i_] - pts[i_ - 1]).Length, (pts[i_ + 1] - pts[i_]).Length) / (2 * math.tan(th / 2)))
    h = Part(name or f'{nm} DN{dn}, L ≈ {L / 1000:.1f} м', 'hose', dn)
    h.add(sol, color or col, 'рукав')
    h.port('a', pa.pos, -pa.dir, perp_ref(pa.dir), dn, 'hose')
    h.port('b', pb.pos, -pb.dir, perp_ref(pb.dir), dn, 'hose')
    h.meta.update(L=L, R_min=rmin, vid=vid, od=od, pts=pts)
    h.anchor('mid', pts[len(pts) // 2])
    return h


def rukav_v_scenu(sc, pa, pb, name=None, group=None, line=None, **kw):
    """rukav() + sc.put + связи порт-в-порт (pa ↔ 'a', 'b' ↔ pb)."""
    h = rukav(pa, pb, name, **kw)
    sc.put(h, group, line)
    sc.link(pa, h.ports['a'], 'hose')
    sc.link(h.ports['b'], pb, 'hose')
    return h


# ------------------------------------------------------------------ клапан донного слива — подробно
def donnyy_klapan(dn=100, pn='PN25', name=None, tag='', Dw=250.0):
    """Клапан донного слива (тип F41W, выдвижной вверх, корпус CF3M) по чертежу поставщика реактора, подробно:
    верхний фланец к штуцеру B; Y-корпус с выходом 45° и фланцем; крышка-бугель на фланце корпуса (4 шпильки с гайками, прокладка PTFE);
    сальник: нажимная втулка на 2 шпильках; бугель на 2 стойках с перемычкой и ходовой гайкой (бронза); шток; маховик с рукояткой.
    Локально (как equipment.bottom_valve_f41): 'a' — верхний фланец (смотрит в −X, к аппарату), корпус — в +X (вниз), выход 'b' — 45° между +X и +Y."""
    fl = std.flange(dn, pn)
    T = fl['f1'] + fl['C']
    D = fl['D']
    o_ = std.pipe('SS', dn)[0]
    p = Part(name or (f'клапан донного слива F41W DN{dn} {pn}, корпус CF3M (316L), крышка на 4 шпильках, сальник, бугель, маховик' + (f' {tag}' if tag else '')),
             'valve', dn)
    plate = revolve_profile([(0, 0), (fl['d1'] / 2, 0), (fl['d1'] / 2, fl['f1']), (D / 2, fl['f1']), (D / 2, T), (0, T)], (0, 0, 0), X, Z)
    for h in bolt_holes(fl, -1, T + 1):
        plate = plate.cut(h)
    rn = nut_clear_r(fl)
    neck = revolve_profile([(0, T), (rn, T), (rn, T + 35), (72, T + 120), (54, T + 170), (0, T + 170)], (0, 0, 0), X, Z)
    u = V(math.cos(math.radians(45)), math.sin(math.radians(45)), 0)
    Lb, x0 = 300.0, T + 60
    c0 = V(x0, 0, 0)
    br = cyl(c0, c0 + u * (Lb - T - 35), 2 * rn)
    fo = revolve_profile([(rn, 0), (D / 2, 0), (D / 2, fl['C']), (fl['d1'] / 2, fl['C']), (fl['d1'] / 2, T), (rn - 20, T)], c0 + u * (Lb - T), u, Z)
    for kk in range(fl['n']):
        a = math.radians((kk + 0.5) * 360 / fl['n'])
        w_ = Z * math.cos(a) + u.cross(Z) * math.sin(a)
        q = c0 + u * (Lb - T) + w_ * (fl['K'] / 2)
        fo = fo.cut(cyl(q - u * 1, q + u * (T + 1), fl['L']))
    xs0 = T + 170                                   # низ горловины штока
    xbf = xs0 + 110                                 # фланец корпуса под крышку
    stemh = cyl((xs0 - 1, 0, 0), (xbf, 0, 0), 86)
    bfl = cyl((xbf, 0, 0), (xbf + 20, 0, 0), 180)
    body = _fuse([plate, neck, br, fo, stemh, bfl])
    body = body.cut(cyl((-1, 0, 0), (T + 160, 0, 0), o_ - 12)).cut(cyl(c0, c0 + u * (Lb + 1), o_ - 12)).cut(cyl((T + 150, 0, 0), (xbf + 21, 0, 0), 38))
    rb = 72.0                                        # шпильки крышки — 4 шт. на Ø144, вразбежку 45°
    bang = [math.radians(45 + 90 * k_) for k_ in range(4)]
    for a in bang:
        q = V(0, rb * math.cos(a), rb * math.sin(a))
        body = body.cut(cyl(q + X * (xbf - 1), q + X * (xbf + 21), 15))
    p.add(body, 'ss_cast', 'корпус Y-образный с фланцами')
    g = xbf + 20
    p.add(tube((g, 0, 0), (g + 2, 0, 0), 128, 40), 'ptfe', 'прокладка крышки')
    xb2 = g + 2                                       # крышка-бугель: фланец, горловина сальника, верхний фланец под стойки
    bon = _fuse([cyl((xb2, 0, 0), (xb2 + 20, 0, 0), 180), cyl((xb2 + 20, 0, 0), (xb2 + 90, 0, 0), 92), cyl((xb2 + 90, 0, 0), (xb2 + 104, 0, 0), 180)])
    bon = bon.cut(cyl((xb2 - 1, 0, 0), (xb2 + 105, 0, 0), 38)).cut(cyl((xb2 + 70, 0, 0), (xb2 + 105, 0, 0), 56))     # камера сальника
    for a in bang:
        q = V(0, rb * math.cos(a), rb * math.sin(a))
        bon = bon.cut(cyl(q + X * (xb2 - 1), q + X * (xb2 + 21), 15))
    for s_ in (-1, 1):                                # отверстия под шпильки сальника (по Z) и под стойки бугеля (по Y)
        bon = bon.cut(cyl((xb2 + 89, 0, s_ * 58), (xb2 + 105, 0, s_ * 58), 13))
    p.add(bon, 'ss_cast', 'крышка-бугель с камерой сальника')
    studs = []
    for a in bang:
        q = V(0, rb * math.cos(a), rb * math.sin(a))
        studs.append(_fuse([cyl(q + X * (xbf - 12), q + X * (xb2 + 32), 12.0), hexagon(q + X * xbf, -X, 19, 10), hexagon(q + X * (xb2 + 20), X, 19, 10)]))
    p.add(studs, 'bolt', 'шпильки M12 крышки с гайками (4 шт.)')
    pk = tube((xb2 + 70, 0, 0), (xb2 + 92, 0, 0), 55.6, 38.4)
    p.add(pk, 'black', 'набивка сальника (графит)')
    xg = xb2 + 104                                    # нажимная втулка
    gf = _fuse([obox(V(xg + 9, 0, 0), X, Z, 14, 150, 60), tube((xg - 12, 0, 0), (xg + 2, 0, 0), 55, 36)]).cut(cyl((xg - 13, 0, 0), (xg + 17, 0, 0), 36))
    for s_ in (-1, 1):
        gf = gf.cut(cyl((xg + 1, 0, s_ * 58), (xg + 17, 0, s_ * 58), 13))
    p.add(gf, 'ss', 'втулка нажимная сальника')
    p.add([_fuse([cyl((xb2 + 81, 0, s_ * 58), (xg + 28, 0, s_ * 58), 11.0), hexagon((xg + 16, 0, s_ * 58), X, 17, 9),
                  hexagon((xb2 + 90, 0, s_ * 58), -X, 17, 9)]) for s_ in (-1, 1)], 'bolt', 'шпильки M10 сальника с гайками')
    xy = xg + 130                                     # бугель: 2 стойки по Y на Ø150, перемычка с ходовой гайкой
    cols = [cyl((xb2 + 104, s_ * 75, 0), (xy, s_ * 75, 0), 22) for s_ in (-1, 1)]
    bridge = obox(V(xy + 11, 0, 0), X, Y, 22, 190, 46).cut(cyl((xy - 1, 0, 0), (xy + 23, 0, 0), 38))
    p.add(_fuse(cols + [bridge]), 'ss_cast', 'бугель (2 стойки, перемычка)')
    p.add(tube((xy + 22, 0, 0), (xy + 52, 0, 0), 56, 34.4), 'brass', 'гайка ходовая (бронза)')
    xs1 = xy + 52 + 20
    p.add(cyl((T + 155, 0, 0), (xs1, 0, 0), 34), 'ss_polish', 'шток с трапецеидальной резьбой')
    rim = max(6, Dw * 0.045)
    xw = xs1 + rim * 1.6 + 0.2
    from .valves import handwheel
    side = Y
    q = V(xw, 0, 0) + side * (Dw / 2 - rim)
    p.add(handwheel(V(xw, 0, 0), X, Dw), 'wheel', f'маховик Ø{Dw:g}')
    p.add(_fuse([cyl(q + X * (rim + 0.2), q + X * (rim + 12), 14), cyl(q + X * (rim + 12), q + X * (rim + 75), 24)]), 'black', 'рукоятка маховика')
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', c0 + u * Lb, u, Z, dn, 'flange', fl=fl)
    p.anchor('top', (xw + 20, 0, 0))
    p.anchor('mid', (T + 100, 0, 0))
    p.meta['L_stem'] = xw
    return p
