"""lib3d.checks — быстрые проверки сцены в памяти (до экспорта): пересечения тел, висящие порты, касания опор."""
import itertools
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS


def solids(shape):
    ex = TopExp_Explorer(shape.wrapped, TopAbs_SOLID)
    out = []
    while ex.More():
        out.append(TopoDS.Solid_s(ex.Current()))
        ex.Next()
    return out


def _vol(s):
    p = GProp_GProps()
    BRepGProp.VolumeProperties_s(s, p)
    return p.Mass()


def _box(s):
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    b = Bnd_Box()
    BRepBndLib.Add_s(s, b)
    return b


def overlaps(parts, min_vol=50.0, allow=None, skip=None, verbose=False):
    """Все пары тел (в том числе внутри одной детали) с объёмом пересечения > min_vol мм³."""
    items = []
    for p in parts:
        if skip and skip(p):
            continue
        for k, (s, c, sub) in enumerate(p.bodies):
            for j, so in enumerate(solids(s)):
                items.append((p, sub or c, so, _box(so)))
    hits = []
    for (pa, sa, a, ba), (pb, sb, b, bb) in itertools.combinations(items, 2):
        if ba.IsOut(bb):
            continue
        if allow and allow(pa, sa, pb, sb):
            continue
        c = BRepAlgoAPI_Common(a, b)
        if not c.IsDone():
            continue
        v = _vol(c.Shape())
        if v > min_vol:
            hits.append((v, f'{pa.name[:40]} [{sa}]', f'{pb.name[:40]} [{sb}]'))
    hits.sort(reverse=True)
    return hits


def dist(a, b):
    d = BRepExtrema_DistShapeShape(a.wrapped if hasattr(a, 'wrapped') else a, b.wrapped if hasattr(b, 'wrapped') else b)
    d.Perform()
    return d.Value()


def dangling(sc):
    out = []
    for p in sc.parts:
        for k, q in p.ports.items():
            if q.kind in ('contact', 'info'):
                continue
            if q.link is None:
                out.append((p, k, q))
    return out
