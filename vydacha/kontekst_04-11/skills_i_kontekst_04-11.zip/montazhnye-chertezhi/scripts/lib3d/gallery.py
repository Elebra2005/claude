"""Галерея библиотеки lib3d: каждая деталь — отдельно (и в типовом соединении), рендер PNG в gallery/.

Запуск: python3 -m lib3d.gallery [фильтр]   (из папки scripts)
Каждый экспонат проверяется на взаимные пересечения тел (в том числе внутри одной детали) — отчёт gallery/overlaps.txt.
"""
import os, sys, json, math, subprocess
from cadquery import Vector as V
from .core import Scene, Port, Xf, unit
from . import export, checks

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'gallery')
THREE = '/home/user/claude/skills/montazhnye-chertezhi/scripts/render3d/node_modules/three'

EXHIBITS = []      # (код, заголовок, функция(sc) -> None, вид: (азимут°, возвышение°))


def exhibit(code, title, view=(35, 25)):
    def deco(f):
        EXHIBITS.append((code, title, f, view))
        return f
    return deco


def build(filter_=None):
    from . import gallery_items, gallery_items2  # noqa: F401  (регистрируют экспонаты)
    from . import gallery as _g
    sc = Scene('Галерея lib3d')
    shots, report = [], []
    col = 0
    for i, (code, title, f, view) in enumerate(_g.EXHIBITS):
        if filter_ and not any(x in code for x in filter_):
            continue
        n0 = len(sc.parts)
        g = f'{code} {title}'
        sc.group = g
        f(sc)
        new = sc.parts[n0:]
        for p in new:
            p.group = g
        # сдвиг экспоната в свою клетку сетки
        off = V((col % 6) * 3000.0, (col // 6) * 3000.0, 0)
        col += 1
        x = Xf.move(off)
        for p in new:
            p.apply(x)
        bb = None
        for p in new:
            b = p.bbox()
            bb = b if bb is None else bb.add(b)
        hits = checks.overlaps(new, 20.0)
        report.append(f'{code} {title}: пересечений {len(hits)}' + ''.join(f'\n   {v:.0f} мм³ | {a} ⟷ {b}' for v, a, b in hits[:20]))
        c = V((bb.xmin + bb.xmax) / 2, (bb.ymin + bb.ymax) / 2, (bb.zmin + bb.zmax) / 2)
        size = max(bb.xlen, bb.ylen, bb.zlen)
        az, el = view
        d = V(math.cos(math.radians(el)) * math.sin(math.radians(az)), -math.cos(math.radians(el)) * math.cos(math.radians(az)), math.sin(math.radians(el)))
        dist = size * 2.4
        eye = c + d * dist
        shots.append({'name': code, 'eye': list(eye.toTuple()), 'target': list(c.toTuple()), 'fov': 30,
                      'only': [code + '[ _]'], 'title': f'{code}  {title}', 'lfs': 18})
    os.makedirs(OUT, exist_ok=True)
    export.export(sc, OUT, 'gallery', step=False, viewer_title='Галерея библиотеки деталей lib3d')
    json.dump(shots, open(os.path.join(OUT, 'shots.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    open(os.path.join(OUT, 'overlaps.txt'), 'w', encoding='utf-8').write('\n'.join(report) + '\n')
    print('\n'.join(report))
    return shots


def _re_escape(s):
    import re
    return re.escape(s.replace('_', ' ')).replace('\\ ', '[ _]')


def render(W=1600, H=1200):
    env = dict(os.environ, NODE_PATH='/opt/node22/lib/node_modules', THREE_DIR=THREE)
    subprocess.run(['node', os.path.join(HERE, 'render.js'), OUT, os.path.join(OUT, 'shots.json'), OUT, str(W), str(H)], env=env, check=True)


if __name__ == '__main__':
    flt = sys.argv[1:] or None
    build(flt)
    render()
