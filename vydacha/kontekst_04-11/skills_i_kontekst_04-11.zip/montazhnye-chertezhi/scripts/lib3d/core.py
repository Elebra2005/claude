"""lib3d.core — геометрия, порты, детали, сборка «порт-в-порт».

Соглашения:
- миллиметры, ось Z вверх;
- у каждой детали (Part) — тела (cq.Shape + цвет) и порты (Port);
- порт: точка, направление НАРУЖУ из детали (куда «смотрит» присоединение), опорный вектор ref
  (перпендикулярен dir; отверстия фланца — вразбежку относительно ref), DN, тип соединения;
- mate(деталь, порт, целевой_порт) — переносит деталь так, чтобы её порт совпал с целевым:
  точки совпадают (с зазором на прокладку для фланцев), направления встречные, ref совпадают
  (для фланцев — с доворотом кратно шагу болтов, чтобы отверстия совпали);
- соединённые порты запоминаются (Scene.links) — по ним проверка «висящих концов».
Детали проектируются без взаимных проникновений: труба торцом к торцу, шпилька в отверстии с зазором,
гайка на торце фланца — касания, а не пересечения (строгая проверка clash3d.py --strict).
"""
import math
import cadquery as cq
from cadquery import Vector as V

EPS = 1e-6


def vec(p):
    return p if isinstance(p, V) else V(*p)


def unit(p):
    v = vec(p)
    return v.normalized()


def perp_ref(d):
    """Канонический опорный вектор для направления d: проекция Z (для вертикали — X)."""
    d = unit(d)
    z = V(0, 0, 1)
    if abs(d.dot(z)) > 0.999:
        r = V(1, 0, 0)
    else:
        r = z
    r = r - d * r.dot(d)
    return r.normalized()


def rotate_vec(v, axis, ang_deg):
    """Поворот вектора v вокруг оси axis (через начало) на угол (правая рука)."""
    a = math.radians(ang_deg)
    k = unit(axis)
    v = vec(v)
    return v * math.cos(a) + k.cross(v) * math.sin(a) + k * (k.dot(v) * (1 - math.cos(a)))


def _orth(b):
    a0 = unit(b[0])
    a1 = vec(b[1]) - a0 * vec(b[1]).dot(a0)
    a1 = a1.normalized()
    return [a0, a1, a0.cross(a1).normalized()]


class Xf:
    """Жёсткое преобразование x -> R x + t (R — 3×3 списком строк)."""

    def __init__(self, R=None, t=(0, 0, 0)):
        self.R = R or [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        self.t = vec(t)

    def p(self, x):
        x = vec(x)
        R = self.R
        return V(R[0][0] * x.x + R[0][1] * x.y + R[0][2] * x.z + self.t.x,
                 R[1][0] * x.x + R[1][1] * x.y + R[1][2] * x.z + self.t.y,
                 R[2][0] * x.x + R[2][1] * x.y + R[2][2] * x.z + self.t.z)

    def d(self, x):
        x = vec(x)
        R = self.R
        return V(R[0][0] * x.x + R[0][1] * x.y + R[0][2] * x.z,
                 R[1][0] * x.x + R[1][1] * x.y + R[1][2] * x.z,
                 R[2][0] * x.x + R[2][1] * x.y + R[2][2] * x.z)

    def trsf(self):
        from OCP.gp import gp_Trsf
        R, t = self.R, self.t
        tr = gp_Trsf()
        tr.SetValues(R[0][0], R[0][1], R[0][2], t.x, R[1][0], R[1][1], R[1][2], t.y, R[2][0], R[2][1], R[2][2], t.z)
        return tr

    def shape(self, s):
        from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
        return cq.Shape.cast(BRepBuilderAPI_Transform(s.wrapped, self.trsf(), True).Shape())

    @staticmethod
    def basis(e, f, p_from, p_to):
        """Поворот, переводящий ортонормированный базис e[0..2] в f[0..2], и перенос p_from -> p_to."""
        e, f = _orth(e), _orth(f)
        R = [[sum(f[k].toTuple()[i] * e[k].toTuple()[j] for k in range(3)) for j in range(3)] for i in range(3)]
        x = Xf(R)
        t = vec(p_to) - x.d(p_from)
        return Xf(R, t)

    @staticmethod
    def rot(axis_p, axis_d, ang_deg):
        a = math.radians(ang_deg)
        k = unit(axis_d)
        c, s = math.cos(a), math.sin(a)
        kx, ky, kz = k.x, k.y, k.z
        R = [[c + kx * kx * (1 - c), kx * ky * (1 - c) - kz * s, kx * kz * (1 - c) + ky * s],
             [ky * kx * (1 - c) + kz * s, c + ky * ky * (1 - c), ky * kz * (1 - c) - kx * s],
             [kz * kx * (1 - c) - ky * s, kz * ky * (1 - c) + kx * s, c + kz * kz * (1 - c)]]
        x = Xf(R)
        p = vec(axis_p)
        return Xf(R, p - x.d(p))

    @staticmethod
    def move(t):
        return Xf(None, t)

    def __mul__(self, o):          # (self ∘ o)(x) = self(o(x))
        R = [[sum(self.R[i][k] * o.R[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
        return Xf(R, self.p(o.t))


# ------------------------------------------------------------------ примитивы (всё — cq.Solid)
def cyl(p0, p1, d):
    p0, p1 = vec(p0), vec(p1)
    v = p1 - p0
    return cq.Solid.makeCylinder(d / 2, v.Length, p0, v.normalized())


def tube(p0, p1, do, di):
    """Полый цилиндр (труба) — от p0 до p1, наружный do, внутренний di."""
    p0, p1 = vec(p0), vec(p1)
    v = p1 - p0
    if di <= 0:
        return cyl(p0, p1, do)
    return revolve_profile([(di / 2, 0), (do / 2, 0), (do / 2, v.Length), (di / 2, v.Length)], p0, v)


def cone(p0, p1, d0, d1):
    p0, p1 = vec(p0), vec(p1)
    v = p1 - p0
    return cq.Solid.makeCone(d0 / 2, d1 / 2, v.Length, p0, v.normalized())


def box(x0, y0, z0, x1, y1, z1):
    x0, x1 = min(x0, x1), max(x0, x1)
    y0, y1 = min(y0, y1), max(y0, y1)
    z0, z1 = min(z0, z1), max(z0, z1)
    return cq.Solid.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))


def cbox(c, sx, sy, sz):
    c = vec(c)
    return box(c.x - sx / 2, c.y - sy / 2, c.z - sz / 2, c.x + sx / 2, c.y + sy / 2, c.z + sz / 2)


def obox(c, ax, ay, sx, sy, sz):
    """Коробка с центром c, ребро sx вдоль ax, sy вдоль ay, sz вдоль ax×ay."""
    ax, ay = unit(ax), unit(ay)
    az = ax.cross(ay).normalized()
    ay = az.cross(ax).normalized()
    b = cq.Solid.makeBox(sx, sy, sz, V(-sx / 2, -sy / 2, -sz / 2))
    x = Xf.basis([V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)], [ax, ay, az], V(0, 0, 0), vec(c))
    return x.shape(b)


def sph(c, d):
    return cq.Solid.makeSphere(d / 2, vec(c), angleDegrees1=-90, angleDegrees2=90)


def torus(c, axis, R, r):
    axis = unit(axis)
    ref = perp_ref(axis)
    wp = cq.Workplane(cq.Plane(origin=(0, 0, 0), xDir=(1, 0, 0), normal=(0, -1, 0)))
    s = wp.center(R, 0).circle(r).revolve(360, (-R, 0, 0), (-R, 1, 0)).val()
    x = Xf.basis([V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)], [ref, axis.cross(ref), axis], V(0, 0, 0), vec(c))
    return x.shape(s)


def revolve_profile(pts, origin, axis, ref=None, angle=360):
    """Тело вращения: профиль [(r, h), ...] (r — от оси, h — вдоль оси) вокруг оси origin+axis."""
    axis = unit(axis)
    ref = unit(ref) if ref is not None else perp_ref(axis)
    wp = cq.Workplane(cq.Plane(origin=(0, 0, 0), xDir=(1, 0, 0), normal=(0, -1, 0)))
    q = []
    for r, h in pts:
        if not q or abs(q[-1][0] - r) > 1e-4 or abs(q[-1][1] - h) > 1e-4:
            q.append((r, h))
    if len(q) > 2 and abs(q[0][0] - q[-1][0]) < 1e-4 and abs(q[0][1] - q[-1][1]) < 1e-4:
        q.pop()
    pts = q
    w = wp.polyline([(r, h) for r, h in pts]).close().revolve(angle, (0, 0, 0), (0, 1, 0))
    s = w.val()
    # локально: ось вращения — Z (h), r — вдоль X; переводим в мировые
    x = Xf.basis([V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)], [ref, axis.cross(ref), axis], V(0, 0, 0), vec(origin))
    return x.shape(s)


def extrude_poly(pts2d, origin, xdir, normal, h):
    """Плоский многоугольник (в плоскости origin, xdir, normal) выдавить на h вдоль normal."""
    wp = cq.Workplane(cq.Plane(origin=vec(origin).toTuple(), xDir=unit(xdir).toTuple(), normal=unit(normal).toTuple()))
    return wp.polyline(pts2d).close().extrude(h).val()


def hexagon(c, axis, s, h, hole=0.0, ref=None):
    """Шестигранник (гайка) «под ключ» s, высотой h, от c вдоль axis, с отверстием hole."""
    axis = unit(axis)
    ref = unit(ref) if ref is not None else perp_ref(axis)
    R = s / math.sqrt(3)
    pts = [(R * math.cos(math.radians(30 + 60 * k)), R * math.sin(math.radians(30 + 60 * k))) for k in range(6)]
    wp = cq.Workplane(cq.Plane(origin=vec(c).toTuple(), xDir=ref.toTuple(), normal=axis.toTuple()))
    w = wp.polyline(pts).close().extrude(h)
    if hole > 0:
        w = w.faces('>Z').workplane().hole(hole)
    sol = w.val()
    return sol


def fuse_all(shapes):
    shapes = [s for s in shapes if s is not None]
    if not shapes:
        return None
    s = shapes[0]
    for o in shapes[1:]:
        s = s.fuse(o)
    return safe_clean(s)


def safe_clean(s):
    """clean() иногда теряет тела (тор + цилиндры) — проверяем объём."""
    try:
        v0 = s.Volume()
        c = cq.Shape.cast(s.wrapped).copy().clean()
        v1 = c.Volume()
        if abs(v0 - v1) <= 1e-4 * max(abs(v0), 1.0) and c.isValid():
            return c
    except Exception:
        pass
    return s


def compound(shapes):
    return cq.Compound.makeCompound([s for s in shapes if s is not None])


# ------------------------------------------------------------------ порты, детали
class Port:
    def __init__(self, name, pos, d, ref=None, dn=None, kind='butt', od=None, fl=None, part=None, note=''):
        self.name = name
        self.pos = vec(pos)
        self.dir = unit(d)
        self.ref = unit(ref) if ref is not None else perp_ref(self.dir)
        self.dn = dn
        self.kind = kind          # flange | butt | thread | clamp | contact | free
        self.od = od              # наружный диаметр (для butt)
        self.fl = fl              # описание фланца (для flange) — dict из std.flange()
        self.part = part
        self.link = None          # (Part, имя порта) или ('terminal', текст)
        self.note = note

    def moved(self, x):
        p = Port(self.name, x.p(self.pos), x.d(self.dir), x.d(self.ref), self.dn, self.kind, self.od, self.fl, self.part, self.note)
        p.link = self.link
        return p

    def __repr__(self):
        return f'Port({self.name} {tuple(round(c, 1) for c in self.pos.toTuple())} → {tuple(round(c, 3) for c in self.dir.toTuple())} DN{self.dn} {self.kind})'


class Part:
    """Деталь/изделие: тела + порты. name — русское наименование с позицией."""
    _n = 0

    def __init__(self, name, kind='', dn=None, line=None, group=None, material=''):
        Part._n += 1
        self.id = Part._n
        self.name = name
        self.kind = kind
        self.dn = dn
        self.line = line
        self.group = group
        self.material = material
        self.bodies = []          # (shape, color, sub)
        self.ports = {}
        self.contacts = []        # (имя другой детали/шаблон, пояснение) — для проверки опор
        self.meta = {}

    def add(self, shape, color, sub=''):
        if shape is None:
            return self
        if isinstance(shape, (list, tuple)):
            for s in shape:
                self.add(s, color, sub)
            return self
        self.bodies.append((shape, color, sub))
        return self

    def port(self, name, pos, d, ref=None, dn=None, kind='butt', od=None, fl=None, note=''):
        p = Port(name, pos, d, ref, dn if dn is not None else self.dn, kind, od, fl, self, note)
        self.ports[name] = p
        return p

    def apply(self, x):
        self.bodies = [(x.shape(s), c, sub) for s, c, sub in self.bodies]
        for k, p in list(self.ports.items()):
            q = p.moved(x)
            q.part = self
            self.ports[k] = q
        if 'anchors' in self.meta:
            self.meta['anchors'] = {k: x.p(v) for k, v in self.meta['anchors'].items()}
        return self

    def anchor(self, name, p):
        self.meta.setdefault('anchors', {})[name] = vec(p)

    def bbox(self):
        bb = None
        for s, _, _ in self.bodies:
            b = s.BoundingBox()
            bb = b if bb is None else bb.add(b)
        return bb

    def __repr__(self):
        return f'Part#{self.id}({self.name})'


def align_xf(p_local, target, gap=0.0, roll=0.0):
    """Преобразование, ставящее порт p_local детали на целевой порт target."""
    d_t = target.dir
    r_t = rotate_vec(target.ref, d_t, roll)
    e = [p_local.dir, p_local.ref, p_local.dir.cross(p_local.ref).normalized()]
    f1 = d_t * -1
    f = [f1, r_t, f1.cross(r_t).normalized()]
    return Xf.basis(e, f, p_local.pos, target.pos + d_t * gap)


class Scene:
    """Реестр деталей и связей. Группы — узлы (аппараты, линии)."""

    def __init__(self, name):
        self.name = name
        self.parts = []
        self.links = []           # (PartA, portA, PartB, portB, тип)
        self.terminals = []       # (Part, порт, тип, текст)
        self.group = None
        self.line = None
        self.notes = {}

    def put(self, part, group=None, line=None):
        part.group = group or part.group or self.group
        if line is not None:
            part.line = line
        elif part.line is None:
            part.line = self.line
        self.parts.append(part)
        return part

    def link(self, pa, pb, kind=''):
        pa.link = (pb.part, pb.name)
        pb.link = (pa.part, pa.name)
        self.links.append((pa.part, pa.name, pb.part, pb.name, kind))

    def terminal(self, port, kind, text):
        """Свободный порт с назначением: tochka (точка стыка с трассой), plug (заглушка), vent (воздушник), drain, boundary."""
        port.link = ('terminal', kind, text)
        self.terminals.append((port.part, port.name, kind, text))

    def find(self, sub):
        return [p for p in self.parts if sub in p.name]
