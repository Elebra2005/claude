# lib3d — библиотека деталей 3D (CadQuery) и сборка «порт-в-порт»

Общая для всех узлов проекта. Детали — параметрические, размеры по стандартам (`std.py`: EN 1092-1 / ГОСТ 33259, ASME B16.9 / ГОСТ 17375–17378, EN 558, ISO 4032). Каждая деталь — `Part` с телами и **портами**; трубы и арматура соединяются порт-в-порт, координаты вручную не подгоняются. Детали спроектированы без взаимных проникновений (касания, а не пересечения) — модель проходит строгую проверку `clash3d.py --strict`.

Подключение (из папки узла):
```python
import sys; sys.path.insert(0, '<repo>/skills/montazhnye-chertezhi/scripts')
from lib3d.core import Scene, Part, Port, V, cyl, tube, box, revolve_profile
from lib3d.piping import Run, wn_flange, pipe_seg, elbow, tee, reducer, blind_flange, reducing_flange, bolt_joint
from lib3d import valves as vv, instruments as ki, supports as sp, equipment as eq, export, checks
```

## Соглашения (стабильный API — не менять без записи здесь)
- мм, ось Z вверх; система координат цеха (X от оси 1, Y от ряда А, Z — отметка).
- `Port(name, pos, dir, ref, dn, kind, od, fl)`: `dir` — **наружу** из детали; `ref` ⟂ `dir` — опорный вектор (отверстия фланца вразбежку от него, угол (i+0,5)·360/n); `kind`: `flange` | `butt` (под сварку/стыковую сварку PP) | `thread` | `clamp` | `insert` (держатель между фланцами) | `contact` (опоры).
- Деталь в локальной системе: вход `'a'` в начале координат смотрит в −X, выход `'b'` — в +X, шток/привод — вверх (+Z), боковой отвод `'c'` — в +Y.
- `Part.anchor(имя, точка)` — точки для выносок (`top`, `mid`, `tag`…); переносятся вместе с деталью.
- `Scene.terminal(port, kind, text)` — свободный порт с назначением: `tochka` (точка стыка с трассой), `plug` (заглушка), `vent` (воздушник), `drain`, `boundary` (граница поставки/узла). Порт без связи и без терминала — «висящий конец» (ошибка проверки).

## Сборка линии — `Run`
```python
sc = Scene('Узел')
sc.group = 'Линия 101'                       # группа в дереве STEP/GLB
r = Run(sc, nozzle_port, line='101-300-L', mat='SS', dn=300, pn='PN25', gasket='PTFE')
r.flange()                                   # ответный воротниковый фланец + болтовое соединение (шпильки насквозь, прокладка)
r.pipe(500); r.elbow((0, -1, 0))             # отвод 3D на новое направление (любой угол)
r.turn_at(corner, newdir)                    # труба до угла (пересечение осей) + отвод
r.path([c1, c2, end])                        # ломаная по углам
c = r.tee(branch_dir, dnb=50)                # тройник; c — свободный порт отвода
r.add(vv.ball_valve(50), up=(0, 0, 1))       # арматура: фланцы совпадают, доворот кратно шагу болтов
r.reducer(25); r.to(point); r.until('z', 4200)
b = r.branch(c, dn=50, line='107-50-L')      # новая линия от порта
r.end('tochka', '125-50-CS — точка трассы')  # конец линии с назначением
```
`Run.put(part, a, b, up, local_up)` — общий механизм: ставит порт `a` детали на текущий порт, проверяет тип и диаметр, для пары фланцев создаёт `bolt_joint` (прокладка + шпильки с гайками, длина шпилек по толщинам тарелок).

## Детали
| Модуль | Функции |
|---|---|
| `piping` | `pipe_seg`, `elbow(mat, dn, ang, R)`, `tee(mat, dn, dnb)`, `reducer`, `cap`, `wn_flange(dn, pn, mat)`, `lap_flange` (PP: втулка + свободный фланец), `blind_flange`, `reducing_flange(dn, pn, dn2)`, `bolt_joint(pa, pb, gasket)` |
| `valves` | `ball_valve(dn, pn, lever_dir, gear)`, `globe_valve(dn)` (вентиль с маховиком), `check_valve(dn)`, `threeway_valve(dn)` (порт `c`), `bellows(dn, n_rods)` (сильфон с проушинами и стяжками), `sight_glass(dn)` (фонарь), `flame_arrester(dn)`, `rupture_disc(dn, fl_in)` (держатель, мембрана, бирка, датчик разрыва), `needle_valve`, `ferrule_end`, `clamp_joint`, `clamp_cap`, `handwheel`, `lever` |
| `instruments` | датчик давления на мембранном разделителе / вентильном блоке, термопреобразователь с головкой и гильзой, манометр с сифонной трубкой и краном, радарный уровнемер |
| `supports` | хомут + тяга + крепление к балке/настилу (подвеска), опора-башмак, стойка, консоль на стену, хомут стояка, седловая опора, лапа с косынками |
| `equipment` | люк быстрооткрываемый, смотровое окно со светильником, мотор-редуктор со стойкой и муфтой, торцевое уплотнение с бачком |

Галерея — `python3 -m lib3d.gallery [коды]` → `lib3d/gallery/G*.png` и `overlaps.txt` (каждая деталь проверена на взаимные пересечения тел).

## Выход и проверки
- `export.export(sc, outdir, name, groups_order, viewer_title, labels)` → `name.step` (cp1251) + `name-utf8.step` + `name-step.zip`, `name.glb`, `name.gltf.json`, `name-parts.json` (детали, порты, связи, терминалы), `viewer.html`.
- `checks.overlaps(parts, min_vol)` — пересечения в памяти; `checks.dangling(sc)` — висящие порты.
- `clash/clash3d.py model-utf8.step --strict --parts name-parts.json` — строгая проверка (все пары тел, в т.ч. внутри линии и прибора); `clash/check_ports.py name-parts.json --tochki tochki.csv` — висящие концы и опоры.
- Рендер: `NODE_PATH=/opt/node22/lib/node_modules THREE_DIR=<.../render3d/node_modules/three> node lib3d/render.js <папка модели> shots.json <out> 2400 1600` — точная камера (`eye`, `target`, `fov`), `hide`/`only`/`ghost` (регулярные выражения по именам), `section`, выноски `labels`.
