"""Экспонаты галереи lib3d — изделия модуля mashiny.py (добавлены для X-600; регистрируются декоратором exhibit)."""
from cadquery import Vector as V
from .core import Port
from .gallery import exhibit
from .piping import Run, wn_flange
from . import mashiny as mm
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def start(sc, dn, mat='SS', pn='PN16', d=X, line='Г', pos=(0, 0, 0)):
    o = std.pipe(mat, dn)[0]
    p = Port('start', pos, d, dn=dn, kind='butt', od=o)
    sc.terminal(p, 'demo', 'начало')
    return Run(sc, p, line, mat, dn, pn, color='ss' if mat == 'SSB' else None)


def inline(sc, dn, item, pn='PN16', pipe=150, up=None, mat='SS'):
    r = start(sc, dn, mat=mat, pn=pn)
    r.pipe(pipe); r.flange()
    r.add(item, up=up)
    r.put(wn_flange(dn, pn, mat if mat in ('SS', 'CS') else 'SS', od=std.pipe(mat, dn)[0]), 'b', 'a')
    r.pipe(pipe)
    r.end('demo', 'конец')
    return r


@exhibit('G26', 'Фланцы плоские приварные PL (HG/T 20592 B) DN50 на трубе 57×3, прокладка PTFE, 4 шпильки M16')
def g26(sc):
    r = start(sc, 50, 'SSB')
    r.pipe(150)
    r.put(mm.pl_flange(50), up=Z, local_up=Z)
    r.put(mm.pl_flange(50), 'b', 'a')
    r.pipe(150); r.end('demo', 'конец')


@exhibit('G27', 'Кран шаровой DN40 с пневмоприводом (KV): кронштейн, привод, соленоид NAMUR, концевики с указателем', view=(40, 20))
def g27(sc):
    inline(sc, 40, mm.ball_valve_pneumatic(40), up=Z)


@exhibit('G28', 'Клапан регулирующий DN25 с мембранным приводом и позиционером (TV)', view=(40, 15))
def g28(sc):
    inline(sc, 25, mm.control_valve(25), up=Z)


@exhibit('G29', 'Затвор дисковый межфланцевый DN65 с рукояткой (две болтовые пары)')
def g29(sc):
    r = start(sc, 65, mat='CS')
    r.pipe(150); r.flange()
    mm.wafer(r, mm.butterfly_valve(65), up=Z)
    r.pipe(150); r.end('demo', 'конец')


@exhibit('G30', 'Фильтр сетчатый Y-образный DN50 и клапан балансировочный DN50')
def g30(sc):
    r = start(sc, 50)
    r.pipe(150); r.flange()
    r.add(mm.y_strainer(50), up=Z)
    r.add(mm.balancing_valve(50, mat='SS'), up=Z)
    r.put(wn_flange(50, 'PN16'), 'b', 'a'); r.pipe(150); r.end('demo', 'конец')


@exhibit('G31', 'Ротаметр с металлической трубкой DN25 (FT), поток снизу вверх', view=(50, 20))
def g31(sc):
    r = start(sc, 25, d=Z)
    r.pipe(150); r.flange()
    r.add(mm.rotameter(25), up=Y)
    r.put(wn_flange(25, 'PN16'), 'b', 'a'); r.pipe(150); r.end('demo', 'конец')


@exhibit('G32', 'Термометр биметаллический на бобышке и указатель уровня магнитный DN20 (межосевое 700)', view=(50, 15))
def g32(sc):
    from .instruments import boss
    from .core import Part, cyl
    r = start(sc, 50)
    pp = r.pipe(400)
    b = boss(60.3)
    from .core import align_xf
    b.apply(align_xf(b.ports['a'], Port('t', (200, 0, 60.3 / 2), Z, X)))
    sc.put(b)
    hole = cyl((200, 0, -5), (200, 0, 100), 9.0)
    for q in (b, pp):
        q.bodies = [(s_.cut(hole), c_, n_) for s_, c_, n_ in q.bodies]
    sc.terminal(b.ports['a'], 'weld', 'приварена')
    t = mm.bimetal_thermometer('TI')
    t.apply(align_xf(t.ports['a'], b.ports['b']))
    sc.put(t)
    sc.link(b.ports['b'], t.ports['a'], 'thread')
    r.end('demo', 'конец')
    lg = mm.level_gauge(700, 20)
    from .core import Xf
    lg.apply(Xf.move((0, 600, 900)))
    sc.put(lg)
    for k in ('a', 'b'):
        sc.terminal(lg.ports[k], 'demo', 'к аппарату')


@exhibit('G33', 'Насос центробежный вертикальный многоступенчатый in-line DN25, 1,5 кВт', view=(35, 15))
def g33(sc):
    p = mm.vertical_pump(25, 25, kw=1.5)
    sc.put(p)
    for k in ('s', 'd'):
        sc.terminal(p.ports[k], 'demo', 'патрубок')


@exhibit('G34', 'Двигатель вертикальный 7,5 кВт на салазках, клиноремённая передача 3 ремня, кожух', view=(30, 25))
def g34(sc):
    parts, _ = mm.belt_drive((0, 0), (660, 0), 1700, kw=7.5)
    for p in parts:
        sc.put(p)


@exhibit('G35', 'Фильтр-регулятор сжатого воздуха DN20 с манометром')
def g35(sc):
    r = start(sc, 20, mat='ZN')
    r.pipe(100)
    r.add(mm.air_regulator(20))
    r.pipe(100); r.end('demo', 'конец')
