"""lib3d.export — сцена -> STEP (zip: Windows-1251 для КОМПАС + UTF-8), GLB, glTF-JSON, parts.json (порты и связи), viewer.html."""
import os, json, struct, base64, zipfile, shutil
import cadquery as cq
from cadquery import Color

PALETTE = {
    'ss': (0.72, 0.74, 0.77), 'ss_dark': (0.55, 0.57, 0.60), 'ss_cast': (0.62, 0.63, 0.65), 'ss_polish': (0.88, 0.89, 0.90),
    'cs': (0.33, 0.35, 0.38), 'cs_paint': (0.42, 0.46, 0.50), 'ppr': (0.48, 0.60, 0.50), 'pph': (0.80, 0.80, 0.76), 'zn': (0.70, 0.73, 0.75),
    'bolt': (0.45, 0.46, 0.48), 'ptfe': (0.96, 0.96, 0.94), 'paronite': (0.45, 0.55, 0.45), 'rubber': (0.12, 0.12, 0.12), 'ffkm': (0.20, 0.20, 0.22),
    'lever': (0.80, 0.12, 0.10), 'lever_blue': (0.12, 0.30, 0.65), 'wheel': (0.70, 0.10, 0.10), 'glass': (0.55, 0.75, 0.90, 0.45),
    'motor': (0.25, 0.38, 0.55), 'gear': (0.32, 0.40, 0.50), 'alu': (0.74, 0.76, 0.78), 'instr': (0.20, 0.38, 0.62), 'instr_grey': (0.55, 0.58, 0.60),
    'dial': (0.97, 0.97, 0.95), 'black': (0.10, 0.10, 0.11), 'red': (0.80, 0.10, 0.08), 'yellow': (0.95, 0.75, 0.10), 'brass': (0.78, 0.62, 0.25),
    'insul': (0.82, 0.84, 0.86, 0.55), 'insul_solid': (0.80, 0.82, 0.85), 'sup': (0.40, 0.42, 0.45), 'sup_galv': (0.62, 0.64, 0.66),
    'struct': (0.55, 0.57, 0.60), 'deck': (0.66, 0.68, 0.70, 0.55), 'concrete': (0.78, 0.76, 0.72, 0.5), 'wall': (0.75, 0.80, 0.86, 0.30),
    'beam': (0.42, 0.45, 0.50), 'paint_green': (0.38, 0.52, 0.42), 'paint_grey': (0.60, 0.62, 0.62), 'flag': (0.95, 0.76, 0.18),
    'zone': (0.95, 0.80, 0.20, 0.08), 'cable': (0.12, 0.12, 0.12), 'nameplate': (0.85, 0.85, 0.80), 'hose': (0.30, 0.32, 0.35),
    'ibc': (0.93, 0.93, 0.90, 0.75), 'white': (0.95, 0.95, 0.95), 'orange': (0.92, 0.45, 0.10),
}
from . import std as _std
PALETTE.update({'s_' + k: v[1] for k, v in _std.STREAM_COLORS.items()})       # цвета потоков (std.STREAM_COLORS)


def color(key):
    c = PALETTE.get(key, (0.7, 0.7, 0.7))
    return Color(*c) if len(c) == 4 else Color(c[0], c[1], c[2], 1.0)


ASCII_FIX = {'…': '...', '−': '-', '–': '-', '—': '-', '≈': '~', '‰': ' promille', '³': '3', '²': '2', '°': ' grad', '«': '"', '»': '"',
             '×': 'x', '·': '.', '→': '->', '←': '<-', '⟷': '<->', 'Ø': 'D', 'ø': 'D', '±': '+-', '≤': '<=', '≥': '>=',
             '①': '(1)', '②': '(2)', '③': '(3)', '④': '(4)', '⑤': '(5)', '⑥': '(6)', '⑦': '(7)', '⑧': '(8)', '⑨': '(9)', '⑩': '(10)',
             '⑪': '(11)', '⑫': '(12)', '⑬': '(13)', '⑭': '(14)', '⑮': '(15)', '⑯': '(16)', '⑰': '(17)', '⑱': '(18)', '⑲': '(19)', '⑳': '(20)'}


def clean_name(s):
    s = s.replace('/', '-').replace('\\', '-')
    return s


def to_assembly(sc, groups_order=None, skip=None):
    root = cq.Assembly(name=sc.name)
    groups = {}
    used = {}
    order = list(groups_order or [])
    for p in sc.parts:
        if skip and skip(p):
            continue
        g = p.group or 'Прочее'
        if g not in groups:
            groups[g] = cq.Assembly(name=clean_name(g))
            if g not in order:
                order.append(g)
        ga = groups[g]
        nm = clean_name(p.name)
        k = used.get((g, nm), 0)
        used[(g, nm)] = k + 1
        if k:
            nm = f'{nm} ({k + 1})'
        p.meta['step_name'] = nm
        p.meta['step_group'] = clean_name(g)
        bycol = {}
        for s_, c, sub in p.bodies:
            bycol.setdefault((c, sub), []).append(s_)
        # STEP теряет имена промежуточных сборок — поэтому деталь из нескольких цветов пишется листьями «деталь — элемент»
        if len(bycol) == 1:
            (c, sub), ss = next(iter(bycol.items()))
            ga.add(cq.Compound.makeCompound(ss) if len(ss) > 1 else ss[0], name=nm, color=color(c))
        else:
            used2 = {}
            for (c, sub), ss in bycol.items():
                sn = clean_name(sub or c)
                k2 = used2.get(sn, 0)
                used2[sn] = k2 + 1
                if k2:
                    sn = f'{sn} {k2 + 1}'
                ga.add(cq.Compound.makeCompound(ss) if len(ss) > 1 else ss[0], name=f'{nm} — {sn}', color=color(c))
    for g in order:
        if g in groups:
            root.add(groups[g], name=clean_name(g))
    return root, [g for g in order if g in groups]


def fix_step(path):
    b = open(path, 'rb').read()
    try:
        raw = b.decode('utf-8')
    except UnicodeDecodeError:              # OCC переносит длинные строки внутри имени и может разрезать многобайтный символ — склеить
        import re as _re
        b = _re.sub(rb"'[^']*'", lambda m: m.group(0).replace(b'\r', b'').replace(b'\n', b''), b)
        raw = b.decode('utf-8', errors='replace')
    try:
        txt = raw.encode('latin-1').decode('utf-8')
    except (UnicodeEncodeError, UnicodeDecodeError):
        txt = raw
    for k, v in ASCII_FIX.items():
        txt = txt.replace(k, v)
    base = path[:-5]
    open(path, 'w', encoding='cp1251', errors='replace', newline='\n').write(txt)
    open(base + '-utf8.step', 'w', encoding='utf-8', newline='\n').write(txt)
    with zipfile.ZipFile(base + '-step.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(path, os.path.basename(path))
        z.write(base + '-utf8.step', os.path.basename(base) + '-utf8.step')


def glb_fix(src, dst_json=None):
    b = open(src, 'rb').read()
    length, off, js, binary = struct.unpack('<III', b[:12])[2], 12, None, None
    while off < length:
        cl, ct = struct.unpack('<II', b[off:off + 8])
        d = b[off + 8:off + 8 + cl]
        off += 8 + cl
        if ct == 0x4E4F534A:
            js = json.loads(d)
        elif ct == 0x004E4942:
            binary = d
    for key in ('nodes', 'meshes', 'materials', 'scenes'):
        for item in js.get(key, []):
            if 'name' in item:
                try:
                    item['name'] = item['name'].encode('latin-1').decode('utf-8')
                except (UnicodeEncodeError, UnicodeDecodeError):
                    pass
    jb = json.dumps(js, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    jb += b' ' * (-len(jb) % 4)
    binary += b'\0' * (-len(binary) % 4)
    body = struct.pack('<II', len(jb), 0x4E4F534A) + jb + struct.pack('<II', len(binary), 0x004E4942) + binary
    open(src, 'wb').write(struct.pack('<III', 0x46546C67, 2, 12 + len(body)) + body)
    if dst_json:
        js['buffers'][0]['uri'] = 'data:application/octet-stream;base64,' + base64.b64encode(binary).decode()
        with open(dst_json, 'w', encoding='utf-8') as f:
            json.dump(js, f, ensure_ascii=False, separators=(',', ':'))


def parts_json(sc, path, extra=None):
    out = {'parts': [], 'terminals': [], 'links': []}
    for p in sc.parts:
        ports = []
        for k, q in p.ports.items():
            ln = None
            if q.link and q.link[0] == 'terminal':
                ln = {'terminal': q.link[1], 'text': q.link[2]}
            elif q.link:
                ln = {'part': q.link[0].id if q.link[0] is not None else None, 'port': q.link[1]}
            ports.append({'name': k, 'pos': [round(c, 2) for c in q.pos.toTuple()], 'dir': [round(c, 4) for c in q.dir.toTuple()],
                          'dn': q.dn, 'kind': q.kind, 'link': ln, 'note': q.note,
                          'fl': [q.fl['D'], q.fl['K'], q.fl['n'], q.fl['bolt']] if q.fl else None})
        out['parts'].append({'id': p.id, 'name': p.name, 'group': p.group, 'line': p.line, 'kind': p.kind, 'dn': p.dn,
                             'ports': ports, 'contacts': p.contacts, 'n_bodies': len(p.bodies), 'touch': p.meta.get('touch'),
                             'step_name': p.meta.get('step_name'), 'step_group': p.meta.get('step_group'),
                             'anchors': {k: [round(c, 1) for c in v.toTuple()] for k, v in p.meta.get('anchors', {}).items()}})
    for (pa, na, pb, nb, kind) in sc.links:
        out['links'].append([pa.id if pa else None, na, pb.id if pb else None, nb, kind])
    if extra:
        out.update(extra)
    json.dump(out, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=0)


VIEWER = os.path.join(os.path.dirname(__file__), 'viewer.html')


def export(sc, outdir, name, groups_order=None, step=True, glb=True, viewer_title=None, viewer_note='', labels=None, tol=1.0, atol=0.35, skip_glb=None):
    os.makedirs(outdir, exist_ok=True)
    asm, groups = to_assembly(sc, groups_order)
    if step:
        sp = os.path.join(outdir, name + '.step')
        from cadquery.occ_impl.exporters.assembly import exportStepMeta
        exportStepMeta(asm, sp)                 # сохраняет имена групп (узлов) в дереве КОМПАС/FreeCAD
        fix_step(sp)
    if glb:
        asm2 = asm if skip_glb is None else to_assembly(sc, groups_order, skip=skip_glb)[0]
        gp = os.path.join(outdir, name + '.glb')
        asm2.save(gp, tolerance=tol, angularTolerance=atol)
        glb_fix(gp, os.path.join(outdir, name + '.gltf.json'))
    parts_json(sc, os.path.join(outdir, name + '-parts.json'))
    meta = {'name': name, 'title': viewer_title or name, 'note': viewer_note, 'groups': [clean_name(g) for g in groups], 'labels': labels or []}
    json.dump(meta, open(os.path.join(outdir, 'viewer-meta.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    html = open(VIEWER, encoding='utf-8').read().replace('__MODEL__', name + '.gltf.json').replace('__META__', json.dumps(meta, ensure_ascii=False))
    html = html.replace('__TITLE__', viewer_title or name)
    open(os.path.join(outdir, 'viewer.html'), 'w', encoding='utf-8').write(html)
    return groups
