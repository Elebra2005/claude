"""lib3d.piping — трубы, отводы, тройники, переходы, фланцы, болтовые соединения, трассировщик Run.

Все детали строятся в локальной системе: вход 'a' в начале координат смотрит в −X, выход 'b' — в +X, ref = +Z.
Отверстия фланцев — вразбежку относительно ref (угол (i+0,5)·360/n), поэтому две встречные детали с совпавшими ref
и доворотом кратно шагу болтов всегда имеют соосные отверстия.
"""
import math
from cadquery import Vector as V
from .core import (Part, Port, Xf, align_xf, cyl, tube, cone, revolve_profile, hexagon, fuse_all, unit, vec, perp_ref,
                   rotate_vec, torus, box)
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)

MAT_COLOR = {'SS': 'ss', 'CS': 'cs', 'PPR': 'ppr', 'PPH': 'pph', 'ZN': 'zn', 'SSB': 'ss', 'SSK': 'ss'}
MAT_NAME = {'SS': 'AISI 316L', 'CS': 'сталь 20', 'PPR': 'PPR', 'PPH': 'PP-H', 'ZN': 'сталь оцинк.', 'SSB': 'AISI 316L', 'SSK': 'AISI 316L'}


def pipe_dims(mat, dn, od=None, wall=None):
    o, w = std.pipe(mat, dn)
    return (od or o, wall or w)


# ------------------------------------------------------------------ простые элементы
def pipe_seg(mat, dn, L, name=None, od=None, wall=None, color=None):
    o, w = pipe_dims(mat, dn, od, wall)
    p = Part(name or f'труба {o:g}×{w:g} {MAT_NAME.get(mat, mat)}, L={L:.0f}', 'pipe', dn, material=mat)
    p.add(tube((0, 0, 0), (L, 0, 0), o, o - 2 * w), color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (L, 0, 0), X, Z, dn, 'butt', od=o)
    p.meta.update(L=L, od=o, wall=w)
    return p


_REV_SIGN = None


def elbow_solid(o, di, R, ang):
    """Отвод: начало в 0, вход вдоль +X, поворот к +Y на ang° радиусом R."""
    import cadquery as cq
    global _REV_SIGN

    def mk(a):
        w = cq.Workplane('YZ').circle(o / 2)
        if di > 0:
            w = w.circle(di / 2)
        return w.revolve(a, (R, 0, 0), (R, 1, 0)).val()
    if _REV_SIGN is None:
        t = mk(90.0).BoundingBox()
        _REV_SIGN = 1.0 if t.xmax > R * 0.5 else -1.0
    return mk(_REV_SIGN * ang)


def elbow(mat, dn, ang=90.0, R=None, name=None, od=None, wall=None, color=None):
    o, w = pipe_dims(mat, dn, od, wall)
    if R is None:
        R = std.PP_ELBOW_R.get(round(o)) if mat in ('PPR', 'PPH') else std.ELBOW_R[dn]
    s = elbow_solid(o, o - 2 * w, R, ang)
    a = math.radians(ang)
    end = V(R * math.sin(a), R * (1 - math.cos(a)), 0)
    dend = V(math.cos(a), math.sin(a), 0)
    nm = name or f'отвод {ang:.0f}° {o:g}×{w:g} R{R:.0f} {MAT_NAME.get(mat, mat)} ({"ГОСТ 17375" if mat in ("SS", "CS", "SSB", "SSK") else "фитинг PP"})'
    p = Part(nm, 'elbow', dn, material=mat)
    p.add(s, color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', end, dend, Z, dn, 'butt', od=o)
    p.meta.update(R=R, ang=ang, od=o)
    return p


TEE_BRANCH_K = 1.0   # множитель Ø отвода равнопроходного тройника; 0,996 — B-Rep без вырожденного пересечения равных цилиндров (валиден после STEP)


def tee(mat, dn, dnb=None, name=None, color=None, C=None, M=None):
    """Тройник: прогон a(−X)…b(+X), отвод c в +Y. Для PP — по d."""
    dnb = dnb or dn
    o, w = pipe_dims(mat, dn)
    ob, wb = pipe_dims(mat, dnb)
    ob_nom = ob                      # порт и имя — номинальный Ø (труба за отводом — номинальная)
    if dnb == dn and TEE_BRANCH_K != 1.0:
        ob = ob * TEE_BRANCH_K
    if mat in ('PPR', 'PPH'):
        C = C or std.PP_TEE_C[round(o)]
        M = M or max(C, o / 2 + ob * 0.6)
    else:
        C = C or std.TEE_C[dn]
        M = M or (std.TEE_C[dn] if dnb == dn else max(std.TEE_C[dn] * 0.92, o / 2 + 25))
    run = tube((0, 0, 0), (2 * C, 0, 0), o, 0)
    br = cyl((C, 0, 0), (C, M, 0), ob)
    outer = run.fuse(br)
    inner = cyl((-1, 0, 0), (2 * C + 1, 0, 0), o - 2 * w).fuse(cyl((C, 0, 0), (C, M + 1, 0), ob - 2 * wb))
    s = outer.cut(inner)
    nm = name or (f'тройник {o:g}×{w:g}' + (f'-{ob:g}×{wb:g}' if dnb != dn else '') + f' {MAT_NAME.get(mat, mat)} ({"ГОСТ 17376" if mat in ("SS", "CS", "SSB", "SSK") else "фитинг PP"})')
    p = Part(nm, 'tee', dn, material=mat)
    p.add(s, color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (2 * C, 0, 0), X, Z, dn, 'butt', od=o)
    p.port('c', (C, M, 0), Y, Z, dnb, 'butt', od=ob_nom)
    p.meta.update(C=C, M=M)
    return p


def reducer(mat, dn1, dn2, name=None, ecc=False, L=None, mat2=None, color=None):
    """Переход концентрический dn1 (a) -> dn2 (b)."""
    o1, w1 = pipe_dims(mat, dn1)
    o2, w2 = pipe_dims(mat2 or mat, dn2)
    L = L or (std.RED_H.get(dn1, 1.6 * o1) if mat in ('SS', 'CS', 'ZN', 'SSB', 'SSK') else max(1.4 * (o1 - o2), 60))
    l0 = min(0.15 * L, 15)
    prof_o = [(0, 0), (o1 / 2, 0), (o1 / 2, l0), (o2 / 2, L - l0), (o2 / 2, L), (0, L)]
    s = revolve_profile(prof_o, (0, 0, 0), X, Z)
    inn = revolve_profile([(0, -1), (o1 / 2 - w1, -1), (o1 / 2 - w1, l0), (o2 / 2 - w2, L - l0), (o2 / 2 - w2, L + 1), (0, L + 1)], (0, 0, 0), X, Z)
    s = s.cut(inn)
    nm = name or f'переход {o1:g}×{w1:g}–{o2:g}×{w2:g} {MAT_NAME.get(mat, mat)} ({"ГОСТ 17378" if mat in ("SS", "CS", "SSB", "SSK") else "фитинг"})'
    p = Part(nm, 'reducer', dn1, material=mat)
    p.add(s, color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn1, 'butt', od=o1)
    p.port('b', (L, 0, 0), X, Z, dn2, 'butt', od=o2)
    return p


def cap(mat, dn, name=None, color=None):
    o, w = pipe_dims(mat, dn)
    h = max(0.4 * o, 25)
    s = revolve_profile([(0, 0), (o / 2, 0)] + [(o / 2 * math.cos(math.radians(t)), h * math.sin(math.radians(t))) for t in range(10, 91, 10)], (0, 0, 0), X, Z)
    p = Part(name or f'заглушка эллиптическая {o:g} {MAT_NAME.get(mat, mat)}', 'cap', dn, material=mat)
    p.add(s, color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    return p


# ------------------------------------------------------------------ фланцы
def bolt_holes(fl, x0, x1, ref_ang=0.0):
    """Цилиндры отверстий фланца (по оси X, от x0 до x1) — для вычитания."""
    out = []
    for i in range(fl['n']):
        a = math.radians(ref_ang + (i + 0.5) * 360.0 / fl['n'])
        y, z = fl['K'] / 2 * math.sin(a), fl['K'] / 2 * math.cos(a)
        out.append(cyl((x0, y, z), (x1, y, z), fl['L']))
    return out


def nut_clear_r(fl):
    """Радиус, внутри которого корпус за тарелкой фланца может быть, не мешая гайкам."""
    d, s, m = std.BOLT[fl['bolt']]
    return fl['K'] / 2 - s / math.sqrt(3) - 3


def flange_plate(fl, x_face, inward=-1, bore=0.0):
    """Тарелка фланца с выступом: соединительная плоскость (верх выступа) — в x_face, тело — в сторону inward (−1: к −X).
    Возвращает тело (без воротника) с отверстиями."""
    C, f1, D, d1 = fl['C'], fl['f1'], fl['D'], fl['d1']
    xa = x_face + inward * f1
    xb = x_face + inward * (f1 + C)
    lo, hi = min(xb, xa), max(xb, xa)
    plate = cyl((lo, 0, 0), (hi, 0, 0), D)
    rf = cyl((min(xa, x_face), 0, 0), (max(xa, x_face), 0, 0), d1)
    s = plate.fuse(rf)
    for h in bolt_holes(fl, lo - 1, hi + 1):
        s = s.cut(h)
    if bore > 0:
        s = s.cut(cyl((min(lo, x_face) - 1, 0, 0), (max(hi, x_face) + 1, 0, 0), bore))
    return s


def wn_flange(dn, pn='PN16', mat='SS', name=None, od=None, wall=None, color=None, std_name='EN 1092-1 / ГОСТ 33259 тип 11'):
    """Фланец воротниковый: 'a' — торец воротника под сварку (−X), 'b' — соединительная плоскость (+X)."""
    o, w = pipe_dims(mat, dn, od, wall)
    fl = std.flange(dn, pn, od=o)
    H, C, f1, N = fl['H'], fl['C'], fl['f1'], fl['N']
    xp = H - f1 - C                       # начало тарелки
    neck = revolve_profile([(o / 2 - w, 0), (o / 2, 0), (N / 2, xp), (o / 2 - w, xp)], (0, 0, 0), X, Z)
    plate = flange_plate(fl, H, -1, bore=o - 2 * w)
    s = fuse_all([neck, plate])
    p = Part(name or f'фланец воротниковый {dn}-{pn[2:]}-11-B1 {MAT_NAME.get(mat, mat)} ({std_name})', 'flange', dn, material=mat)
    p.add(s, color or MAT_COLOR.get(mat, 'ss'))
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (H, 0, 0), X, Z, dn, 'flange', fl=fl)
    return p


def lap_flange(dn, pn='PN10', mat='PPR', name=None, color=None):
    """Для PP: втулка под фланец (бурт) + свободный стальной фланец. 'a' — торец втулки под сварку, 'b' — плоскость бурта."""
    o, w = pipe_dims(mat, dn)
    fl = std.flange(dn if dn in std._FL[pn] else 50, pn)
    fl = dict(fl)
    stub_L = max(60, 0.9 * o)
    collar_d = fl['d1'] + 4
    collar_t = 14 if o < 100 else 20
    # втулка (PP): труба + бурт
    stub = revolve_profile([(o / 2 - w, 0), (o / 2, 0), (o / 2, stub_L - collar_t), (collar_d / 2, stub_L - collar_t), (collar_d / 2, stub_L), (o / 2 - w, stub_L)],
                           (0, 0, 0), X, Z)
    # свободный фланец (сталь) за буртом: отверстие под втулку с зазором
    Cf = fl['C']
    xf1 = stub_L - collar_t
    loose = cyl((xf1 - Cf, 0, 0), (xf1, 0, 0), fl['D']).cut(cyl((xf1 - Cf - 1, 0, 0), (xf1 + 1, 0, 0), o + 3))
    for h in bolt_holes(fl, xf1 - Cf - 1, xf1 + 1):
        loose = loose.cut(h)
    nm = name or f'втулка под фланец {o:g} {MAT_NAME.get(mat, mat)} + фланец свободный DN{dn} {pn} (сталь оцинк.)'
    p = Part(nm, 'flange', dn, material=mat)
    p.add(stub, color or MAT_COLOR[mat], 'втулка')
    p.add(loose, 'zn', 'фланец свободный')
    # для расчёта шпилек: «тарелка» — бурт + свободный фланец
    fl.update(C=Cf + collar_t, f1=0.0, d1=collar_d, lap=True)
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (stub_L, 0, 0), X, Z, dn, 'flange', fl=fl)
    return p


def blind_flange(dn, pn='PN16', mat='SS', name=None, color=None, tapped=None):
    fl = std.flange(dn, pn)
    s = flange_plate(fl, 0.0, -1)                     # плоскость в 0, тарелка — в −X; порт смотрит в +X
    p = Part(name or f'заглушка фланцевая DN{dn} {pn} {MAT_NAME.get(mat, mat)} (EN 1092-1 тип 05)', 'blind', dn, material=mat)
    p.add(s, color or MAT_COLOR.get(mat, 'ss'))
    p.port('a', (0, 0, 0), X, Z, dn, 'flange', fl=fl)
    return p


def reducing_flange(dn, pn, dn2, mat='SS', neck_L=60, name=None, color=None, mat2=None):
    """Фланец переходный: глухой фланец DN с вваренным патрубком DN2. 'a' — плоскость (смотрит в −X), 'b' — торец патрубка (+X)."""
    fl = std.flange(dn, pn)
    o2, w2 = pipe_dims(mat2 or mat, dn2)
    plate = flange_plate(fl, 0.0, +1)                # плоскость в 0, тарелка в +X
    T = fl['C'] + fl['f1']
    nz = tube((T, 0, 0), (T + neck_L, 0, 0), o2, o2 - 2 * w2)
    s = plate.cut(cyl((-1, 0, 0), (T + 1, 0, 0), o2 - 2 * w2)).fuse(nz)
    p = Part(name or f'фланец переходный DN{dn}/DN{dn2} {pn} {MAT_NAME.get(mat, mat)}', 'flange', dn, material=mat)
    p.add(s, color or MAT_COLOR.get(mat, 'ss'))
    p.port('a', (0, 0, 0), -X, Z, dn, 'flange', fl=fl)
    p.port('b', (T + neck_L, 0, 0), X, Z, dn2, 'butt', od=o2)
    return p


# ------------------------------------------------------------------ болтовое соединение
GASKET = {'PTFE': ('ptfe', 'прокладка PTFE (фторопласт-4)', 2.0), 'PAR': ('paronite', 'прокладка паронитовая ПОН-Б', 2.0),
          'EPDM': ('rubber', 'прокладка EPDM', 3.0), 'FFKM': ('ffkm', 'прокладка FFKM', 2.0), 'SPW': ('ss_dark', 'прокладка спирально-навитая', 3.2)}


def gasket_t(kind):
    return GASKET[kind][2]


def bolt_joint(pa, pb, gasket='PTFE', name=None, extra=None):
    """Болтовое соединение двух встречных фланцевых портов (зазор между плоскостями — прокладка).
    Шпильки проходят насквозь через обе тарелки (и через то, что зажато между ними — extra: толщина),
    гайки — на тыльных сторонах. Возвращает Part (прокладка + шпильки с гайками)."""
    fa, fb = pa.fl, pb.fl
    assert fa['n'] == fb['n'] and abs(fa['K'] - fb['K']) < 0.1 and fa['bolt'] == fb['bolt'], f'фланцы не совпадают: {fa} / {fb}'
    d_ax = pa.dir
    gap = (pb.pos - pa.pos).dot(d_ax)
    assert gap > -0.01, f'фланцы перекрываются: зазор {gap:.2f}'
    d, s_, m = std.BOLT[fa['bolt']]
    ta = fa['C'] + fa['f1']
    tb = fb['C'] + fb['f1']
    # в локальной системе порта a: ось +X — из фланца a к фланцу b
    xa_back = -ta
    xb_back = gap + tb
    over = max(0.4 * d, 4)
    L = (xb_back + m + over) - (xa_back - m - over)
    parts = []
    for i in range(fa['n']):
        a = math.radians((i + 0.5) * 360.0 / fa['n'])
        y, z = fa['K'] / 2 * math.sin(a), fa['K'] / 2 * math.cos(a)
        rod = cyl((xa_back - m - over, y, z), (xb_back + m + over, y, z), d)
        n1 = hexagon((xa_back, y, z), -X, s_, m, ref=Z)
        n2 = hexagon((xb_back, y, z), X, s_, m, ref=Z)
        parts.append(rod.fuse(n1).fuse(n2))
    gk = None
    if gasket and gap > 0.05:
        gd, gname, gt = GASKET[gasket]
        go = fa['K'] - fa['L'] - 2
        gi = max(fa.get('od') or 0, fb.get('od') or 0)
        gi = gi - 6 if gi else fa['d1'] * 0.6
        gk = tube((0, 0, 0), (gap, 0, 0), go, gi)
    nm = name or f'соединение фланцевое DN{fa["dn"]} {fa["pn"]}: {fa["n"]} шпилек {fa["bolt"]}×{L:.0f} с гайками (А2-70)' + (f', {GASKET[gasket][1]}' if gk is not None else '')
    p = Part(nm, 'joint', fa['dn'])
    p.add(parts, 'bolt', 'шпильки с гайками')
    if gk is not None:
        p.add(gk, GASKET[gasket][0], 'прокладка')
    e = [X, Z, X.cross(Z)]
    f = [d_ax, pa.ref, d_ax.cross(pa.ref).normalized()]
    xf = Xf.basis(e, f, V(0, 0, 0), pa.pos)
    p.apply(xf)
    p.meta.update(stud_L=L, n=fa['n'], bolt=fa['bolt'])
    return p


# ------------------------------------------------------------------ трассировщик
class Run:
    """Линия: последовательная сборка порт-в-порт от стартового порта."""

    def __init__(self, sc, start, line, mat='SS', dn=None, pn='PN16', gasket='PTFE', group=None, color=None, insul=0.0):
        self.sc = sc
        self.cur = start
        self.line = line
        self.mat = mat
        self.dn = dn or start.dn
        self.pn = pn
        self.gasket = gasket
        self.group = group
        self.color = color
        self.items = []
        self.insul = insul

    # --- общий механизм
    def put(self, part, a='a', b='b', up=None, local_up=None, roll=None, gasket=None, name_joint=None):
        pa = part.ports[a]
        tgt = self.cur
        flg = (tgt.kind == 'flange' and pa.kind == 'flange')
        clp = (tgt.kind == 'clamp' and pa.kind == 'clamp')
        gap = gasket_t(gasket or self.gasket) if flg else (3.0 if clp else 0.0)
        if tgt.kind != pa.kind and not ({tgt.kind, pa.kind} <= {'butt', 'thread'}):
            raise ValueError(f'{self.line}: тип соединения не совпадает: {tgt} / {pa} ({part.name})')
        if tgt.kind == 'butt' and pa.kind == 'butt' and tgt.od and pa.od and abs(tgt.od - pa.od) > 0.6:
            raise ValueError(f'{self.line}: диаметры не совпадают {tgt.od} / {pa.od} ({part.name})')
        r = 0.0
        if up is not None:
            x0 = align_xf(pa, tgt, gap, 0.0)
            lu = x0.d(local_up if local_up is not None else Z)
            ax = tgt.dir
            u0 = (lu - ax * lu.dot(ax))
            u1 = (vec(up) - ax * vec(up).dot(ax))
            if u0.Length > 1e-6 and u1.Length > 1e-6:
                u0, u1 = u0.normalized(), u1.normalized()
                r = math.degrees(math.atan2(ax.dot(u0.cross(u1)), u0.dot(u1)))
        if roll is not None:
            r += roll
        if flg:
            assert tgt.fl and pa.fl and tgt.fl['K'] == pa.fl['K'] and tgt.fl['n'] == pa.fl['n'] and tgt.fl['bolt'] == pa.fl['bolt'], \
                f'{self.line}: ответные фланцы разного стандарта: {tgt.fl} / {pa.fl} ({part.name})'
            pt = std.pitch(tgt.fl)
            r = round(r / pt) * pt
        x = align_xf(pa, tgt, gap, r)
        part.apply(x)
        part.line = part.line or self.line
        self.sc.put(part, self.group, self.line)
        self.sc.link(tgt, part.ports[a], 'flange' if flg else pa.kind)
        if clp:
            from .valves import clamp_joint
            from .valves import clamp_tube_od
            j = clamp_joint(tgt.od, gasket or self.gasket, dn=pa.dn, od=clamp_tube_od(tgt.od))
            e = [X, Z, X.cross(Z)]
            f = [tgt.dir, perp_ref(tgt.dir), tgt.dir.cross(perp_ref(tgt.dir))]
            j.apply(Xf.basis(e, f, V(0, 0, 0), tgt.pos + tgt.dir * 1.5))
            j.meta.update(ax=tgt.dir, c=tgt.pos + tgt.dir * 1.5, ear=perp_ref(tgt.dir) * -1)   # К73: для поворота проушин (k73.ushi)
            self.sc.put(j, self.group, self.line)
            self.items.append(j)
        if flg:
            j = bolt_joint(tgt, part.ports[a], gasket or self.gasket, name=name_joint)
            self.sc.put(j, self.group, self.line)
            j.meta['between'] = (tgt.part.id if tgt.part else None, part.id)
            self.items.append(j)
        self.items.append(part)
        if b is not None:
            self.cur = part.ports[b]
        return part

    def here(self):
        return self.cur.pos

    def dirn(self):
        return self.cur.dir

    # --- трубы
    def pipe(self, L, name=None):
        if L < 0.5:
            if L < -0.5:
                raise ValueError(f'{self.line}: отрицательная длина трубы {L:.1f}')
            return None
        p = pipe_seg(self.mat, self.dn, L, name=name, color=self.color, od=self.cur.od if self.cur.kind == 'butt' else None)
        return self.put(p)

    def to(self, pt, tol=1.0):
        """Труба по текущему направлению до точки pt (pt должна лежать на оси)."""
        pt = vec(pt)
        v = pt - self.cur.pos
        L = v.dot(self.cur.dir)
        off = (v - self.cur.dir * L).Length
        if off > tol:
            raise ValueError(f'{self.line}: точка {pt.toTuple()} не на оси (смещение {off:.1f} мм) от {self.cur}')
        return self.pipe(L)

    def until(self, coord, value, reserve=0.0):
        """Труба по текущему направлению, пока координата ('x'|'y'|'z') не станет value − reserve·dir."""
        d = self.cur.dir
        k = 'xyz'.index(coord)
        dc = d.toTuple()[k]
        L = (value - self.cur.pos.toTuple()[k]) / dc - reserve
        return self.pipe(L)

    def elbow(self, newdir, R=None, name=None):
        nd = unit(newdir)
        cd = self.cur.dir
        ang = math.degrees(math.acos(max(-1, min(1, cd.dot(nd)))))
        if ang < 0.5:
            return None
        e = elbow(self.mat, self.dn, ang, R=R, name=name, color=self.color, od=self.cur.od if self.cur.kind == 'butt' else None)
        side = nd - cd * cd.dot(nd)
        return self.put(e, up=side, local_up=Y)

    def elbow_len(self, ang=90.0, R=None):
        o, w = pipe_dims(self.mat, self.dn)
        if R is None:
            R = std.PP_ELBOW_R.get(round(o)) if self.mat in ('PPR', 'PPH') else std.ELBOW_R[self.dn]
        return R * math.tan(math.radians(ang) / 2)

    def turn_at(self, corner, newdir, R=None):
        """Труба до угла corner (точка пересечения осей) и отвод на newdir."""
        nd = unit(newdir)
        ang = math.degrees(math.acos(max(-1, min(1, self.cur.dir.dot(nd)))))
        T = self.elbow_len(ang, R)
        v = vec(corner) - self.cur.pos
        L = v.dot(self.cur.dir) - T
        off = (v - self.cur.dir * v.dot(self.cur.dir)).Length
        if off > 1.0:
            raise ValueError(f'{self.line}: угол {vec(corner).toTuple()} не на оси (смещение {off:.1f}) от {self.cur}')
        self.pipe(L)
        return self.elbow(nd, R)

    def path(self, pts, R=None, end_pipe=True):
        """Ломаная по точкам-углам: из текущего порта через pts[0..n-2] к pts[-1] (последняя — конец трубы)."""
        for i, c in enumerate(pts[:-1]):
            nd = (vec(pts[i + 1]) - vec(c)).normalized()
            self.turn_at(c, nd, R)
        if end_pipe:
            self.to(pts[-1])

    def tee(self, branch_dir, dnb=None, name=None, C=None, M=None):
        """Тройник на прогоне; возвращает порт отвода (свободный)."""
        t = tee(self.mat, self.dn, dnb, name=name, color=self.color, C=C, M=M)
        self.put(t, up=branch_dir, local_up=Y)
        return t.ports['c']

    def tee_at(self, center, branch_dir, dnb=None, name=None):
        C = std.PP_TEE_C[round(pipe_dims(self.mat, self.dn)[0])] if self.mat in ('PPR', 'PPH') else std.TEE_C[self.dn]
        v = vec(center) - self.cur.pos
        self.pipe(v.dot(self.cur.dir) - C)
        return self.tee(branch_dir, dnb, name)

    def reducer(self, dn2, name=None, L=None, mat2=None):
        r = reducer(self.mat, self.dn, dn2, name=name, L=L, mat2=mat2, color=self.color)
        self.put(r)
        self.dn = dn2
        if mat2:
            self.mat = mat2
        return r

    def flange(self, pn=None, name=None, mat=None):
        pn = pn or self.pn
        m = mat or self.mat
        if m in ('PPR', 'PPH'):
            f = lap_flange(self.dn, pn, m, name=name)
        else:
            f = wn_flange(self.dn, pn, m, name=name, od=self.cur.od if self.cur.kind == 'butt' else None, color=self.color)
        self.put(f, up=perp_ref(self.cur.dir), local_up=Z)
        return f

    def blind(self, name=None, pn=None):
        b = blind_flange(self.dn, pn or self.cur.fl['pn'] if self.cur.fl else self.pn, self.mat if self.mat in MAT_COLOR else 'SS', name=name)
        self.put(b, b=None)
        return b

    def add(self, part, a='a', b='b', up=None, local_up=None, roll=None):
        p = self.put(part, a, b, up=up, local_up=local_up, roll=roll)
        if b and b in part.ports and part.ports[b].dn:
            self.dn = part.ports[b].dn
        return p

    def close(self, port, gasket=None):
        """Замкнуть линию на существующий порт (фланец к фланцу через прокладку, стык к стыку)."""
        tgt = self.cur
        d = (port.pos - tgt.pos)
        dot = tgt.dir.dot(port.dir)
        if dot > -0.9995:
            raise ValueError(f'{self.line}: замыкание — порты не встречные ({dot:.5f}): {tgt} / {port}')
        if tgt.kind == 'flange' and port.kind == 'flange':
            g = gasket_t(gasket or self.gasket)
            gap = d.dot(tgt.dir)
            off = (d - tgt.dir * gap).Length
            if abs(gap - g) > 0.6 or off > 0.6:
                raise ValueError(f'{self.line}: замыкание фланцев — зазор {gap:.2f} (нужно {g}), смещение {off:.2f}')
            assert tgt.fl['K'] == port.fl['K'] and tgt.fl['n'] == port.fl['n'], f'{self.line}: разные фланцы {tgt.fl} / {port.fl}'
            j = bolt_joint(tgt, port, gasket or self.gasket)
            self.sc.put(j, self.group, self.line)
            self.items.append(j)
            self.sc.link(tgt, port, 'flange')
        else:
            if d.Length > 0.6:
                raise ValueError(f'{self.line}: замыкание стыка — расстояние {d.Length:.2f} мм ({tgt} / {port})')
            self.sc.link(tgt, port, tgt.kind)
        self.cur = None
        return port

    def flange_back(self, pn=None, name=None):
        """Ответный воротниковый фланец к фланцевому порту (дальше — под сварку)."""
        pn = pn or (self.cur.fl['pn'] if self.cur.fl else self.pn)
        m = self.mat if self.mat in ('SS', 'CS') else 'SS'
        if self.mat in ('PPR', 'PPH'):
            f = lap_flange(self.cur.dn, pn, self.mat, name=name)
        else:
            f = wn_flange(self.cur.dn, pn, m, name=name, color=self.color)
        self.put(f, 'b', 'a')
        self.dn = f.ports['a'].dn
        return f

    def branch(self, port, dn=None, mat=None, line=None, pn=None, color=None):
        r = Run(self.sc, port, line or self.line, mat or self.mat, dn or port.dn, pn or self.pn, self.gasket, self.group, color or self.color)
        return r

    def end(self, kind, text):
        self.sc.terminal(self.cur, kind, text)
        return self.cur


def pipe_with_branches(mat, dn, L, branches, name=None, color=None, od=None, wall=None):
    """Труба L с приварными врезками/бобышками. branches: [(x вдоль трубы, направление (y,z в локальной), тип, параметры)]:
       ('flange', dnb, pn, ext) — штуцер DNb с воротниковым фланцем, ext — от оси трубы до плоскости фланца;
       ('boss', d, h) — бобышка Ø d, высота h над поверхностью (порт резьбовой).
    Порты: 'a', 'b' и 'c0', 'c1'… для врезок."""
    o, w = pipe_dims(mat, dn, od, wall)
    run = tube((0, 0, 0), (L, 0, 0), o, o - 2 * w)
    shapes = [run]
    bores = []
    p = Part(name or f'труба {o:g}×{w:g} {MAT_NAME.get(mat, mat)}, L={L:.0f}, с врезками', 'pipe', dn, material=mat)
    ports = []
    for i, br in enumerate(branches):
        xb, kind = br[0], br[2]
        d2 = unit(V(*br[1])) if len(br[1]) == 3 else unit(V(0, br[1][0], br[1][1]))
        c = V(xb, 0, 0)
        if kind == 'flange':
            dnb, pn, ext = br[3], br[4], br[5]
            ob, wb = std.pipe('SS', dnb)
            f = wn_flange(dnb, pn, 'SS')
            H = f.ports['b'].pos.x
            face = c + d2 * ext
            x = Xf.basis([X, Z, X.cross(Z)], [d2, perp_ref(d2) if abs(d2.dot(X)) < 0.99 else Z, d2.cross(perp_ref(d2))], V(H, 0, 0), face)
            f.apply(x)
            stub = cyl(c, face - d2 * H, ob)
            bores.append(cyl(c, face, ob - 2 * wb))
            shapes += [stub, f.bodies[0][0]]
            fl = std.flange(dnb, pn, od=ob)
            ports.append((f'c{i}', face, d2, dnb, 'flange', fl, None))
        else:
            dd, h = br[3], br[4]
            top = c + d2 * (o / 2 + h)
            shapes.append(cyl(c, top, dd))
            bores.append(cyl(c + d2 * (o / 2 - w - 1), top - d2 * 6, 10.0))
            ports.append((f'c{i}', top, d2, 15, 'thread', None, 27.0))
    s_ = fuse_all(shapes).cut(cyl((-1, 0, 0), (L + 1, 0, 0), o - 2 * w))
    for b in bores:
        s_ = s_.cut(b)
    p.add(s_, color or MAT_COLOR[mat])
    p.port('a', (0, 0, 0), -X, Z, dn, 'butt', od=o)
    p.port('b', (L, 0, 0), X, Z, dn, 'butt', od=o)
    for nm, pos, d2, dnb, kind, fl, odb in ports:
        p.port(nm, pos, d2, perp_ref(d2), dnb, kind, od=odb, fl=fl)
    p.meta.update(L=L, od=o)
    return p
