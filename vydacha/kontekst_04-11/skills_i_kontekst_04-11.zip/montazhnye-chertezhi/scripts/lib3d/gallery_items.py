"""Экспонаты галереи lib3d (регистрируются декоратором exhibit)."""
from cadquery import Vector as V
from .core import Port
from .gallery import exhibit
from .piping import Run, wn_flange, pipe_seg
from . import valves as vv
from . import std

X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)


def start(sc, dn, mat='SS', pn='PN16', d=X, line='Г'):
    o = std.pipe(mat, dn)[0]
    p = Port('start', (0, 0, 0), d, dn=dn, kind='butt', od=o)
    sc.terminal(p, 'demo', 'начало')
    return Run(sc, p, line, mat, dn, pn)


def inline(sc, dn, item, pn='PN16', pipe=150, up=None, **kw):
    r = start(sc, dn, pn=pn)
    r.pipe(pipe); r.flange()
    r.add(item, up=up)
    r.flange_back = True
    f = wn_flange(dn, pn)
    r.put(f, 'b', 'a')
    r.pipe(pipe)
    r.end('demo', 'конец')
    return r


@exhibit('G01', 'Фланцевое соединение DN100 PN16: воротниковые фланцы, прокладка PTFE, 8 шпилек M16 с гайками')
def g01(sc):
    r = start(sc, 100)
    r.pipe(200); r.flange()
    r.put(wn_flange(100, 'PN16'), 'b', 'a'); r.pipe(200); r.end('demo', 'конец')


@exhibit('G02', 'Отводы 90° и 45° (R = 1,5·DN), тройник, переход DN50–DN25')
def g02(sc):
    r = start(sc, 50)
    r.pipe(100); r.elbow(Z); r.pipe(150); r.elbow((1, 0, 1)); r.pipe(80); r.elbow(X); c = r.tee(Y); r.pipe(60); r.reducer(25); r.pipe(80); r.end('demo', 'конец')
    b = r.branch(c); b.pipe(80); b.end('demo', 'конец')


@exhibit('G03', 'Кран шаровой фланцевый DN50 PN16 с рукояткой')
def g03(sc):
    inline(sc, 50, vv.ball_valve(50), up=Z)


@exhibit('G04', 'Кран шаровой фланцевый DN25 PN16 с рукояткой')
def g04(sc):
    inline(sc, 25, vv.ball_valve(25), up=Z)


@exhibit('G05', 'Клапан запорный (вентиль) DN50 PN16 с маховиком и штоком')
def g05(sc):
    inline(sc, 50, vv.globe_valve(50), up=Z)


@exhibit('G06', 'Клапан обратный подъёмный DN25 PN16')
def g06(sc):
    inline(sc, 25, vv.check_valve(25), up=Z)


@exhibit('G07', 'Кран шаровой трёхходовой DN100 PN16, редуктор с маховиком')
def g07(sc):
    r = start(sc, 100)
    r.pipe(150); r.flange()
    t = vv.threeway_valve(100)
    r.add(t, up=Z)
    r.put(wn_flange(100, 'PN16'), 'b', 'a'); r.pipe(150); r.end('demo', 'конец')
    b = r.branch(t.ports['c'])
    b.put(wn_flange(100, 'PN16'), 'b', 'a'); b.pipe(150); b.end('demo', 'конец')


@exhibit('G08', 'Компенсатор сильфонный DN50 PN16: проушины, 2 стяжки, гайки с обеих сторон', view=(55, 20))
def g08(sc):
    inline(sc, 50, vv.bellows(50), up=Z)


@exhibit('G09', 'Компенсатор сильфонный DN100 PN16: проушины, 2 стяжки, гайки с обеих сторон', view=(55, 20))
def g09(sc):
    inline(sc, 100, vv.bellows(100), up=Z)


@exhibit('G10', 'Фонарь смотровой проточный DN100 PN16, два окна')
def g10(sc):
    inline(sc, 100, vv.sight_glass(100), up=Z)


@exhibit('G11', 'Огнепреградитель DN50 PN16')
def g11(sc):
    inline(sc, 50, vv.flame_arrester(50), up=Z)


# ------------------------------------------------------------------ КИП
from . import instruments as ki, supports as sp, equipment as eq
from .core import Part, tube, box, cyl, Xf
from .piping import tee as _tee


@exhibit('G12', 'Мембрана разрывная DN200 в держателе с датчиком разрыва между фланцами PN25', view=(40, 20))
def g12(sc):
    r = start(sc, 200, pn='PN25')
    r.pipe(150); f = r.flange()
    rd = vv.rupture_disc(200, r.cur.fl)
    from .core import align_xf
    x = align_xf(rd.ports['a'], r.cur, 0.0, 0.0)
    rd.apply(x); sc.put(rd); sc.link(r.cur, rd.ports['a'])
    f2 = wn_flange(200, 'PN25')
    x = align_xf(f2.ports['b'], rd.ports['b'], 0.0, 0.0)
    f2.apply(x); sc.put(f2); sc.link(rd.ports['b'], f2.ports['b'])
    from .piping import bolt_joint
    sc.put(bolt_joint(f.ports['b'], f2.ports['b'], gasket=None))
    r.cur = f2.ports['a']; r.pipe(150); r.end('demo', 'конец')


@exhibit('G13', 'Датчик давления на мембранном разделителе DN25 за краном DN25')
def g13(sc):
    r = start(sc, 25, d=Z)
    r.pipe(80); r.flange()
    r.add(vv.ball_valve(25), up=(1, 0, 0))
    r.add(ki.pressure_transmitter('PIR-101', conn='flange', dn_fl=25), b=None, up=(0, 0, 1) if False else (1, 0, 0))


@exhibit('G14', 'Датчик давления на 2-вентильном блоке')
def g14(sc):
    r = start(sc, 15, d=Z, mat='SS')
    r.cur.kind = 'thread'; r.cur.od = 20.0
    r.add(ki.valve_manifold(), up=(1, 0, 0))
    r.add(ki.pressure_transmitter('PT', conn='thread'), b=None, up=(1, 0, 0))


@exhibit('G15', 'Термопреобразователь с головкой в гильзе фланцевой DN100')
def g15(sc):
    p = Port('n', (0, 0, 0), Z, dn=100, kind='flange')
    from . import std as _s
    p.fl = _s.flange(100, 'PN25')
    sc.terminal(p, 'demo', 'штуцер')
    r = Run(sc, p, 'T', 'SS', 100, 'PN25')
    r.add(ki.thermowell_flange(100, 'PN25', 600), up=(1, 0, 0))
    r.add(ki.rtd('TIRA-101', L_neck=110), b=None, up=(1, 0, 0))


@exhibit('G16', 'Манометр с сифонной трубкой и трёхходовым краном')
def g16(sc):
    r = start(sc, 15, d=Z)
    r.cur.kind = 'thread'; r.cur.od = 14.0
    r.add(ki.siphon(), up=(1, 0, 0))
    r.add(ki.gauge_cock(), up=(0, 1, 0))
    r.add(ki.gauge('PI-101'), b=None, up=(1, 0, 0))


@exhibit('G17', 'Уровнемер радарный DN50')
def g17(sc):
    p = Port('n', (0, 0, 0), Z, dn=50, kind='flange')
    from . import std as _s
    p.fl = _s.flange(50, 'PN16')
    sc.terminal(p, 'demo', 'штуцер')
    r = Run(sc, p, 'LT', 'SS', 50, 'PN16')
    r.add(ki.radar_level(50, tag='LIRA-103'), b=None, up=(1, 0, 0))


def _beam(sc, z):
    b = sp.ibeam((-600, 0, z + 100), (600, 0, z + 100), name='балка (условно)')
    sc.put(b)
    return b


@exhibit('G18', 'Подвеска: хомут двухболтовый, тяга с талрепом, пластина к балке', view=(30, 15))
def g18(sc):
    r = start(sc, 50)
    r.pipe(800); pp = r.items[-1]; r.end('demo', 'конец')
    b = sp.ibeam((400, -400, 900), (400, 400, 900), name='балка 20Б1 (условно)'); sc.put(b)
    sc.put(sp.hanger((400, 0, 0), 60.3, X, 800, pipe=pp, struct=b))


@exhibit('G19', 'Опора-башмак скользящая и опора-стойка с U-болтом', view=(30, 20))
def g19(sc):
    r = start(sc, 100)
    r.pipe(1200); pp = r.items[-1]; r.end('demo', 'конец')
    pl = Part('плита (условно)', 'struct'); pl.add(box(-100, -300, -500, 1300, 300, -480), 'deck'); sc.put(pl)
    sc.put(sp.shoe((300, 0, 0), 114.3, X, -480 + 280, pipe=pp, struct=pl) if False else sp.stanchion((300, 0, 0), 114.3, X, -480, pipe=pp, struct=pl))
    b = sp.ibeam((900, -300, -300), (900, 300, -300), name='балка (условно)'); sc.put(b)
    sc.put(sp.shoe((900, 0, 0), 114.3, X, -200, pipe=pp, struct=b))


@exhibit('G20', 'Хомут стояка на перекрытии и консоль на стену', view=(35, 20))
def g20(sc):
    r = start(sc, 100, d=Z)
    r.pipe(1200); pp = r.items[-1]; r.end('demo', 'конец')
    dk = Part('перекрытие (условно)', 'struct'); dk.add(box(-500, -500, 296, 500, 500, 300).cut(cyl((0, 0, 0), (0, 0, 400), 150)), 'deck'); sc.put(dk)
    sc.put(sp.riser_clamp((0, 0, 0), 114.3, 300, X, pipe=pp, struct=dk))
    w = Part('стена (условно)', 'struct'); w.add(box(-500, 300, 500, 500, 450, 1200), 'wall'); sc.put(w)
    sc.put(sp.wall_bracket((0, 0, 900), 114.3, (0, 300, 900), (0, -1, 0), Z, pipe=pp, struct=w))


@exhibit('G21', 'Люк DN450 с быстрооткрываемой крышкой: шарнир, откидные болты, смотровое окно', view=(40, 30))
def g21(sc):
    m = eq.quick_manhole()
    eq.place_axis(m, (0, 0, 0), Z, up=Y)
    sc.put(m); sc.terminal(m.ports['a'], 'demo', 'приварка')


@exhibit('G22', 'Смотровое окно DN100 со светильником Ex', view=(40, 25))
def g22(sc):
    w = eq.sight_window()
    eq.place_axis(w, (0, 0, 0), Z, up=Y)
    sc.put(w); sc.terminal(w.ports['a'], 'demo', 'приварка')


@exhibit('G23', 'Привод мешалки: стойка, муфта, редуктор, мотор 45 кВт Ex d; торцевое уплотнение и бачок', view=(35, 15))
def g23(sc):
    P, top = eq.agitator_drive((0, 0), 0.0)
    for p in P:
        sc.put(p)


@exhibit('G24', 'Лапа опорная с косынками и седловая опора', view=(35, 20))
def g24(sc):
    sh = Part('корпус (условно)', 'shell'); sh.add(tube((0, 0, 0), (0, 0, 900), 1792, 1760), 'ss'); sc.put(sh)
    sc.put(eq.vessel_lug((0, 0), 896, 45, 300))
    sh2 = Part('корпус горизонтальный (условно)', 'shell'); sh2.add(tube((1500, -600, 600), (1500, 600, 600), 616, 600), 'ss'); sc.put(sh2)
    sc.put(eq.saddle((1500, 0, 600), Y, 616, 0))


@exhibit('G25', 'Донный слив: фланец-переходник DN100 → кламп K64 FFKM → окно → кран → кламп → заглушка', view=(40, 20))
def g25(sc):
    from . import std as _s
    p = Port('n', (0, 0, 0), X, dn=100, kind='flange'); p.fl = _s.flange(100, 'PN25'); sc.terminal(p, 'demo', 'клапан')
    r = Run(sc, p, 'DR', 'SS', 100, 'PN25', gasket='PTFE')
    r.add(vv.reducing_flange_clamp(100, 'PN25'))
    r.gasket = 'FFKM'
    r.add(vv.clamp_sight_glass())
    r.add(vv.clamp_ball_valve(lever_dir=(1, 0, 0)), up=(0, 0, 1))
    r.add(vv.clamp_cap(50), b=None)
